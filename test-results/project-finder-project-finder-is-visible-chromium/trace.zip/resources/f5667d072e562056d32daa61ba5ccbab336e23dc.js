(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/aa3e7_@radix-ui_themes_dist_esm_d0154380._.js",
  "static/chunks/0d8a1_react-arborist_dist_module_d495e52d._.js",
  "static/chunks/069a8_react-dnd_dist_esm_93d6bfdb._.js",
  "static/chunks/4aed3_@radix-ui_react-icons_dist_react-icons_esm_c5594b42.js",
  "static/chunks/node_modules__pnpm_e11ea7fa._.js",
  "static/chunks/src_b8a98c62._.js",
  "static/chunks/_7c87a836._.css"
],
    source: "dynamic"
});
