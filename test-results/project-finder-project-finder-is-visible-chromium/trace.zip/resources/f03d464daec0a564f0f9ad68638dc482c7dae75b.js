(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "_": ()=>_define_property
});
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
;
}),
"[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, self, source, owner, props, debugStack, debugTask) {
        self = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== self ? self : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, source, self, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, self, source, getOwner(), maybeKey, debugStack, debugTask);
    }
    function validateChildKeys(node) {
        "object" === typeof node && null !== node && node.$$typeof === REACT_ELEMENT_TYPE && node._store && (node._store.validated = 1);
    }
    var React = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren, source, self) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, source, self, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}}),
"[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}}),
"[project]/node_modules/.pnpm/@radix-ui+react-visually-hidden@1.2.3_@types+react-dom@19.1.7_@types+react@19.1.9__@typ_3e00cf61a4977f9c0df2f5eed20e4061/node_modules/@radix-ui/react-visually-hidden/dist/index.mjs [app-client] (ecmascript) <export * as VisuallyHidden>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "VisuallyHidden": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$visually$2d$hidden$40$1$2e$2$2e$3_$40$types$2b$react$2d$dom$40$19$2e$1$2e$7_$40$types$2b$react$40$19$2e$1$2e$9_$5f40$typ_3e00cf61a4977f9c0df2f5eed20e4061$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$visually$2d$hidden$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$visually$2d$hidden$40$1$2e$2$2e$3_$40$types$2b$react$2d$dom$40$19$2e$1$2e$7_$40$types$2b$react$40$19$2e$1$2e$9_$5f40$typ_3e00cf61a4977f9c0df2f5eed20e4061$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$visually$2d$hidden$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-visually-hidden@1.2.3_@types+react-dom@19.1.7_@types+react@19.1.9__@typ_3e00cf61a4977f9c0df2f5eed20e4061/node_modules/@radix-ui/react-visually-hidden/dist/index.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/allotment@1.20.4_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/allotment/dist/modern.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "Allotment": ()=>xe,
    "LayoutPriority": ()=>fe,
    "setSashSize": ()=>Ie
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", _extends.apply(null, arguments);
}
;
var h = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : ("TURBOPACK compile-time truthy", 1) ? ("TURBOPACK ident replacement", globalThis) : "TURBOPACK unreachable";
function c(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var l, f = {
    exports: {}
};
/*!
  Copyright (c) 2018 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/ var m, d, p, v = (l || (l = 1, m = f, function() {
    var e = {}.hasOwnProperty;
    function t() {
        for(var i = [], n = 0; n < arguments.length; n++){
            var r = arguments[n];
            if (r) {
                var s = typeof r;
                if ("string" === s || "number" === s) i.push(r);
                else if (Array.isArray(r)) {
                    if (r.length) {
                        var o = t.apply(null, r);
                        o && i.push(o);
                    }
                } else if ("object" === s) if (r.toString === Object.prototype.toString) for(var a in r)e.call(r, a) && r[a] && i.push(a);
                else i.push(r.toString());
            }
        }
        return i.join(" ");
    }
    m.exports ? (t.default = t, m.exports = t) : window.classNames = t;
}()), f.exports), y = c(v);
var b, g = c(function() {
    if (p) return d;
    p = 1;
    var e = /^\s+|\s+$/g, t = /^[-+]0x[0-9a-f]+$/i, i = /^0b[01]+$/i, n = /^0o[0-7]+$/i, r = parseInt, s = Object.prototype.toString;
    function o(e) {
        var t = typeof e;
        return !!e && ("object" == t || "function" == t);
    }
    function a(a) {
        if ("number" == typeof a) return a;
        if (function(e) {
            return "symbol" == typeof e || function(e) {
                return !!e && "object" == typeof e;
            }(e) && "[object Symbol]" == s.call(e);
        }(a)) return NaN;
        if (o(a)) {
            var u = "function" == typeof a.valueOf ? a.valueOf() : a;
            a = o(u) ? u + "" : u;
        }
        if ("string" != typeof a) return 0 === a ? a : +a;
        a = a.replace(e, "");
        var h = i.test(a);
        return h || n.test(a) ? r(a.slice(2), h ? 2 : 8) : t.test(a) ? NaN : +a;
    }
    return d = function(e, t, i) {
        return void 0 === i && (i = t, t = void 0), void 0 !== i && (i = (i = a(i)) == i ? i : 0), void 0 !== t && (t = (t = a(t)) == t ? t : 0), function(e, t, i) {
            return e == e && (void 0 !== i && (e = e <= i ? e : i), void 0 !== t && (e = e >= t ? e : t)), e;
        }(a(e), t, i);
    };
}()), z = {
    exports: {}
};
var w = (b || (b = 1, function(e, t) {
    var i = "__lodash_hash_undefined__", n = 9007199254740991, r = "[object Arguments]", s = "[object Array]", o = "[object Boolean]", a = "[object Date]", u = "[object Error]", c = "[object Function]", l = "[object Map]", f = "[object Number]", m = "[object Object]", d = "[object Promise]", p = "[object RegExp]", v = "[object Set]", y = "[object String]", b = "[object Symbol]", g = "[object WeakMap]", z = "[object ArrayBuffer]", w = "[object DataView]", S = /^\[object .+?Constructor\]$/, _ = /^(?:0|[1-9]\d*)$/, I = {};
    I["[object Float32Array]"] = I["[object Float64Array]"] = I["[object Int8Array]"] = I["[object Int16Array]"] = I["[object Int32Array]"] = I["[object Uint8Array]"] = I["[object Uint8ClampedArray]"] = I["[object Uint16Array]"] = I["[object Uint32Array]"] = !0, I[r] = I[s] = I[z] = I[o] = I[w] = I[a] = I[u] = I[c] = I[l] = I[f] = I[m] = I[p] = I[v] = I[y] = I[g] = !1;
    var x = "object" == typeof h && h && h.Object === Object && h, E = "object" == typeof self && self && self.Object === Object && self, V = x || E || Function("return this")(), j = t && !t.nodeType && t, N = j && e && !e.nodeType && e, L = N && N.exports === j, O = L && x.process, D = function() {
        try {
            return O && O.binding && O.binding("util");
        } catch (e) {}
    }(), M = D && D.isTypedArray;
    function P(e, t) {
        for(var i = -1, n = null == e ? 0 : e.length; ++i < n;)if (t(e[i], i, e)) return !0;
        return !1;
    }
    function A(e) {
        var t = -1, i = Array(e.size);
        return e.forEach(function(e, n) {
            i[++t] = [
                n,
                e
            ];
        }), i;
    }
    function T(e) {
        var t = -1, i = Array(e.size);
        return e.forEach(function(e) {
            i[++t] = e;
        }), i;
    }
    var C, F, k, H = Array.prototype, $ = Function.prototype, Y = Object.prototype, B = V["__core-js_shared__"], R = $.toString, W = Y.hasOwnProperty, G = (C = /[^.]+$/.exec(B && B.keys && B.keys.IE_PROTO || "")) ? "Symbol(src)_1." + C : "", U = Y.toString, X = RegExp("^" + R.call(W).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), J = L ? V.Buffer : void 0, K = V.Symbol, Z = V.Uint8Array, Q = Y.propertyIsEnumerable, q = H.splice, ee = K ? K.toStringTag : void 0, te = Object.getOwnPropertySymbols, ie = J ? J.isBuffer : void 0, ne = (F = Object.keys, k = Object, function(e) {
        return F(k(e));
    }), re = De(V, "DataView"), se = De(V, "Map"), oe = De(V, "Promise"), ae = De(V, "Set"), ue = De(V, "WeakMap"), he = De(Object, "create"), ce = Te(re), le = Te(se), fe = Te(oe), me = Te(ae), de = Te(ue), pe = K ? K.prototype : void 0, ve = pe ? pe.valueOf : void 0;
    function ye(e) {
        var t = -1, i = null == e ? 0 : e.length;
        for(this.clear(); ++t < i;){
            var n = e[t];
            this.set(n[0], n[1]);
        }
    }
    function be(e) {
        var t = -1, i = null == e ? 0 : e.length;
        for(this.clear(); ++t < i;){
            var n = e[t];
            this.set(n[0], n[1]);
        }
    }
    function ge(e) {
        var t = -1, i = null == e ? 0 : e.length;
        for(this.clear(); ++t < i;){
            var n = e[t];
            this.set(n[0], n[1]);
        }
    }
    function ze(e) {
        var t = -1, i = null == e ? 0 : e.length;
        for(this.__data__ = new ge(); ++t < i;)this.add(e[t]);
    }
    function we(e) {
        var t = this.__data__ = new be(e);
        this.size = t.size;
    }
    function Se(e, t) {
        var i = ke(e), n = !i && Fe(e), r = !i && !n && He(e), s = !i && !n && !r && We(e), o = i || n || r || s, a = o ? function(e, t) {
            for(var i = -1, n = Array(e); ++i < e;)n[i] = t(i);
            return n;
        }(e.length, String) : [], u = a.length;
        for(var h in e)!W.call(e, h) || o && ("length" == h || r && ("offset" == h || "parent" == h) || s && ("buffer" == h || "byteLength" == h || "byteOffset" == h) || Ae(h, u)) || a.push(h);
        return a;
    }
    function _e(e, t) {
        for(var i = e.length; i--;)if (Ce(e[i][0], t)) return i;
        return -1;
    }
    function Ie(e) {
        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : ee && ee in Object(e) ? function(e) {
            var t = W.call(e, ee), i = e[ee];
            try {
                e[ee] = void 0;
                var n = !0;
            } catch (e) {}
            var r = U.call(e);
            return n && (t ? e[ee] = i : delete e[ee]), r;
        }(e) : function(e) {
            return U.call(e);
        }(e);
    }
    function xe(e) {
        return Re(e) && Ie(e) == r;
    }
    function Ee(e, t, i, n, h) {
        return e === t || (null == e || null == t || !Re(e) && !Re(t) ? e != e && t != t : function(e, t, i, n, h, c) {
            var d = ke(e), g = ke(t), S = d ? s : Pe(e), _ = g ? s : Pe(t), I = (S = S == r ? m : S) == m, x = (_ = _ == r ? m : _) == m, E = S == _;
            if (E && He(e)) {
                if (!He(t)) return !1;
                d = !0, I = !1;
            }
            if (E && !I) return c || (c = new we()), d || We(e) ? Ne(e, t, i, n, h, c) : function(e, t, i, n, r, s, h) {
                switch(i){
                    case w:
                        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                        e = e.buffer, t = t.buffer;
                    case z:
                        return !(e.byteLength != t.byteLength || !s(new Z(e), new Z(t)));
                    case o:
                    case a:
                    case f:
                        return Ce(+e, +t);
                    case u:
                        return e.name == t.name && e.message == t.message;
                    case p:
                    case y:
                        return e == t + "";
                    case l:
                        var c = A;
                    case v:
                        var m = 1 & n;
                        if (c || (c = T), e.size != t.size && !m) return !1;
                        var d = h.get(e);
                        if (d) return d == t;
                        n |= 2, h.set(e, t);
                        var g = Ne(c(e), c(t), n, r, s, h);
                        return h.delete(e), g;
                    case b:
                        if (ve) return ve.call(e) == ve.call(t);
                }
                return !1;
            }(e, t, S, i, n, h, c);
            if (!(1 & i)) {
                var V = I && W.call(e, "__wrapped__"), j = x && W.call(t, "__wrapped__");
                if (V || j) {
                    var N = V ? e.value() : e, L = j ? t.value() : t;
                    return c || (c = new we()), h(N, L, i, n, c);
                }
            }
            return !!E && (c || (c = new we()), function(e, t, i, n, r, s) {
                var o = 1 & i, a = Le(e), u = a.length, h = Le(t), c = h.length;
                if (u != c && !o) return !1;
                for(var l = u; l--;){
                    var f = a[l];
                    if (!(o ? f in t : W.call(t, f))) return !1;
                }
                var m = s.get(e);
                if (m && s.get(t)) return m == t;
                var d = !0;
                s.set(e, t), s.set(t, e);
                for(var p = o; ++l < u;){
                    var v = e[f = a[l]], y = t[f];
                    if (n) var b = o ? n(y, v, f, t, e, s) : n(v, y, f, e, t, s);
                    if (!(void 0 === b ? v === y || r(v, y, i, n, s) : b)) {
                        d = !1;
                        break;
                    }
                    p || (p = "constructor" == f);
                }
                if (d && !p) {
                    var g = e.constructor, z = t.constructor;
                    g == z || !("constructor" in e) || !("constructor" in t) || "function" == typeof g && g instanceof g && "function" == typeof z && z instanceof z || (d = !1);
                }
                return s.delete(e), s.delete(t), d;
            }(e, t, i, n, h, c));
        }(e, t, i, n, Ee, h));
    }
    function Ve(e) {
        return !(!Be(e) || function(e) {
            return !!G && G in e;
        }(e)) && ($e(e) ? X : S).test(Te(e));
    }
    function je(e) {
        if (i = (t = e) && t.constructor, n = "function" == typeof i && i.prototype || Y, t !== n) return ne(e);
        var t, i, n, r = [];
        for(var s in Object(e))W.call(e, s) && "constructor" != s && r.push(s);
        return r;
    }
    function Ne(e, t, i, n, r, s) {
        var o = 1 & i, a = e.length, u = t.length;
        if (a != u && !(o && u > a)) return !1;
        var h = s.get(e);
        if (h && s.get(t)) return h == t;
        var c = -1, l = !0, f = 2 & i ? new ze() : void 0;
        for(s.set(e, t), s.set(t, e); ++c < a;){
            var m = e[c], d = t[c];
            if (n) var p = o ? n(d, m, c, t, e, s) : n(m, d, c, e, t, s);
            if (void 0 !== p) {
                if (p) continue;
                l = !1;
                break;
            }
            if (f) {
                if (!P(t, function(e, t) {
                    if (o = t, !f.has(o) && (m === e || r(m, e, i, n, s))) return f.push(t);
                    var o;
                })) {
                    l = !1;
                    break;
                }
            } else if (m !== d && !r(m, d, i, n, s)) {
                l = !1;
                break;
            }
        }
        return s.delete(e), s.delete(t), l;
    }
    function Le(e) {
        return function(e, t, i) {
            var n = t(e);
            return ke(e) ? n : function(e, t) {
                for(var i = -1, n = t.length, r = e.length; ++i < n;)e[r + i] = t[i];
                return e;
            }(n, i(e));
        }(e, Ge, Me);
    }
    function Oe(e, t) {
        var i, n, r = e.__data__;
        return ("string" == (n = typeof (i = t)) || "number" == n || "symbol" == n || "boolean" == n ? "__proto__" !== i : null === i) ? r["string" == typeof t ? "string" : "hash"] : r.map;
    }
    function De(e, t) {
        var i = function(e, t) {
            return null == e ? void 0 : e[t];
        }(e, t);
        return Ve(i) ? i : void 0;
    }
    ye.prototype.clear = function() {
        this.__data__ = he ? he(null) : {}, this.size = 0;
    }, ye.prototype.delete = function(e) {
        var t = this.has(e) && delete this.__data__[e];
        return this.size -= t ? 1 : 0, t;
    }, ye.prototype.get = function(e) {
        var t = this.__data__;
        if (he) {
            var n = t[e];
            return n === i ? void 0 : n;
        }
        return W.call(t, e) ? t[e] : void 0;
    }, ye.prototype.has = function(e) {
        var t = this.__data__;
        return he ? void 0 !== t[e] : W.call(t, e);
    }, ye.prototype.set = function(e, t) {
        var n = this.__data__;
        return this.size += this.has(e) ? 0 : 1, n[e] = he && void 0 === t ? i : t, this;
    }, be.prototype.clear = function() {
        this.__data__ = [], this.size = 0;
    }, be.prototype.delete = function(e) {
        var t = this.__data__, i = _e(t, e);
        return !(i < 0 || (i == t.length - 1 ? t.pop() : q.call(t, i, 1), --this.size, 0));
    }, be.prototype.get = function(e) {
        var t = this.__data__, i = _e(t, e);
        return i < 0 ? void 0 : t[i][1];
    }, be.prototype.has = function(e) {
        return _e(this.__data__, e) > -1;
    }, be.prototype.set = function(e, t) {
        var i = this.__data__, n = _e(i, e);
        return n < 0 ? (++this.size, i.push([
            e,
            t
        ])) : i[n][1] = t, this;
    }, ge.prototype.clear = function() {
        this.size = 0, this.__data__ = {
            hash: new ye(),
            map: new (se || be)(),
            string: new ye()
        };
    }, ge.prototype.delete = function(e) {
        var t = Oe(this, e).delete(e);
        return this.size -= t ? 1 : 0, t;
    }, ge.prototype.get = function(e) {
        return Oe(this, e).get(e);
    }, ge.prototype.has = function(e) {
        return Oe(this, e).has(e);
    }, ge.prototype.set = function(e, t) {
        var i = Oe(this, e), n = i.size;
        return i.set(e, t), this.size += i.size == n ? 0 : 1, this;
    }, ze.prototype.add = ze.prototype.push = function(e) {
        return this.__data__.set(e, i), this;
    }, ze.prototype.has = function(e) {
        return this.__data__.has(e);
    }, we.prototype.clear = function() {
        this.__data__ = new be(), this.size = 0;
    }, we.prototype.delete = function(e) {
        var t = this.__data__, i = t.delete(e);
        return this.size = t.size, i;
    }, we.prototype.get = function(e) {
        return this.__data__.get(e);
    }, we.prototype.has = function(e) {
        return this.__data__.has(e);
    }, we.prototype.set = function(e, t) {
        var i = this.__data__;
        if (i instanceof be) {
            var n = i.__data__;
            if (!se || n.length < 199) return n.push([
                e,
                t
            ]), this.size = ++i.size, this;
            i = this.__data__ = new ge(n);
        }
        return i.set(e, t), this.size = i.size, this;
    };
    var Me = te ? function(e) {
        return null == e ? [] : (e = Object(e), function(e, t) {
            for(var i = -1, n = null == e ? 0 : e.length, r = 0, s = []; ++i < n;){
                var o = e[i];
                t(o, i, e) && (s[r++] = o);
            }
            return s;
        }(te(e), function(t) {
            return Q.call(e, t);
        }));
    } : function() {
        return [];
    }, Pe = Ie;
    function Ae(e, t) {
        return !!(t = null == t ? n : t) && ("number" == typeof e || _.test(e)) && e > -1 && e % 1 == 0 && e < t;
    }
    function Te(e) {
        if (null != e) {
            try {
                return R.call(e);
            } catch (e) {}
            try {
                return e + "";
            } catch (e) {}
        }
        return "";
    }
    function Ce(e, t) {
        return e === t || e != e && t != t;
    }
    (re && Pe(new re(new ArrayBuffer(1))) != w || se && Pe(new se()) != l || oe && Pe(oe.resolve()) != d || ae && Pe(new ae()) != v || ue && Pe(new ue()) != g) && (Pe = function(e) {
        var t = Ie(e), i = t == m ? e.constructor : void 0, n = i ? Te(i) : "";
        if (n) switch(n){
            case ce:
                return w;
            case le:
                return l;
            case fe:
                return d;
            case me:
                return v;
            case de:
                return g;
        }
        return t;
    });
    var Fe = xe(function() {
        return arguments;
    }()) ? xe : function(e) {
        return Re(e) && W.call(e, "callee") && !Q.call(e, "callee");
    }, ke = Array.isArray, He = ie || function() {
        return !1;
    };
    function $e(e) {
        if (!Be(e)) return !1;
        var t = Ie(e);
        return t == c || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t;
    }
    function Ye(e) {
        return "number" == typeof e && e > -1 && e % 1 == 0 && e <= n;
    }
    function Be(e) {
        var t = typeof e;
        return null != e && ("object" == t || "function" == t);
    }
    function Re(e) {
        return null != e && "object" == typeof e;
    }
    var We = M ? function(e) {
        return function(t) {
            return e(t);
        };
    }(M) : function(e) {
        return Re(e) && Ye(e.length) && !!I[Ie(e)];
    };
    function Ge(e) {
        return null != (t = e) && Ye(t.length) && !$e(t) ? Se(e) : je(e);
        //TURBOPACK unreachable
        ;
        var t;
    }
    e.exports = function(e, t) {
        return Ee(e, t);
    };
}(z, z.exports)), z.exports), S = c(w);
function _(e, t, i) {
    return e[t] ? e[t][0] ? e[t][0][i] : e[t][i] : "contentBoxSize" === t ? e.contentRect["inlineSize" === i ? "width" : "height"] : void 0;
}
function I(e) {
    void 0 === e && (e = {});
    var o = e.onResize, a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0);
    a.current = o;
    var u = e.round || Math.round, h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: void 0,
        height: void 0
    }), l = c[0], f = c[1], m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        return m.current = !1, function() {
            m.current = !0;
        };
    }, []);
    var d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        width: void 0,
        height: void 0
    }), p = function(e, i) {
        var s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
        o.current = i;
        var a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
            u();
        });
        var u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function() {
            var t = a.current, i = o.current, n = t || (i ? i instanceof Element ? i : i.current : null);
            s.current && s.current.element === n && s.current.subscriber === e || (s.current && s.current.cleanup && s.current.cleanup(), s.current = {
                element: n,
                subscriber: e,
                cleanup: n ? e(n) : void 0
            });
        }, [
            e
        ]);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
            return function() {
                s.current && s.current.cleanup && (s.current.cleanup(), s.current = null);
            };
        }, []), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function(e) {
            a.current = e, u();
        }, [
            u
        ]);
    }((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function(t) {
        return h.current && h.current.box === e.box && h.current.round === u || (h.current = {
            box: e.box,
            round: u,
            instance: new ResizeObserver(function(t) {
                var i = t[0], n = "border-box" === e.box ? "borderBoxSize" : "device-pixel-content-box" === e.box ? "devicePixelContentBoxSize" : "contentBoxSize", r = _(i, n, "inlineSize"), s = _(i, n, "blockSize"), o = r ? u(r) : void 0, h = s ? u(s) : void 0;
                if (d.current.width !== o || d.current.height !== h) {
                    var c = {
                        width: o,
                        height: h
                    };
                    d.current.width = o, d.current.height = h, a.current ? a.current(c) : m.current || f(c);
                }
            })
        }), h.current.instance.observe(t, {
            box: e.box
        }), function() {
            h.current && h.current.instance.unobserve(t);
        };
    }, [
        e.box,
        u
    ]), e.ref);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(function() {
        return {
            ref: p,
            width: l.width,
            height: l.height
        };
    }, [
        p,
        l.width,
        l.height
    ]);
}
var x = "allotment-module_splitView__L-yRc", E = "allotment-module_sashContainer__fzwJF", V = "allotment-module_splitViewContainer__rQnVa", j = "allotment-module_splitViewView__MGZ6O", N = "allotment-module_vertical__WSwwa", L = "allotment-module_horizontal__7doS8", O = "allotment-module_separatorBorder__x-rDS";
let D, M = !1, P = !1;
"object" == typeof navigator && (D = navigator.userAgent, P = D.indexOf("Macintosh") >= 0, M = (D.indexOf("Macintosh") >= 0 || D.indexOf("iPad") >= 0 || D.indexOf("iPhone") >= 0) && !!navigator.maxTouchPoints && navigator.maxTouchPoints > 0);
const A = M, T = P, C = "undefined" != typeof window && void 0 !== window.document && void 0 !== window.document.createElement ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
class F {
    getSize() {
        return this._size;
    }
    setSize(e) {
        this._size = e;
    }
    constructor(){
        this._size = void 0;
    }
}
function k(e, t) {
    const i = e.length, n = i - t.length;
    return n >= 0 && e.slice(n, i) === t;
}
var H, $ = {
    exports: {}
};
var Y, B, R = (H || (H = 1, function(e) {
    var t = Object.prototype.hasOwnProperty, i = "~";
    function n() {}
    function r(e, t, i) {
        this.fn = e, this.context = t, this.once = i || !1;
    }
    function s(e, t, n, s, o) {
        if ("function" != typeof n) throw new TypeError("The listener must be a function");
        var a = new r(n, s || e, o), u = i ? i + t : t;
        return e._events[u] ? e._events[u].fn ? e._events[u] = [
            e._events[u],
            a
        ] : e._events[u].push(a) : (e._events[u] = a, e._eventsCount++), e;
    }
    function o(e, t) {
        0 == --e._eventsCount ? e._events = new n() : delete e._events[t];
    }
    function a() {
        this._events = new n(), this._eventsCount = 0;
    }
    Object.create && (n.prototype = Object.create(null), new n().__proto__ || (i = !1)), a.prototype.eventNames = function() {
        var e, n, r = [];
        if (0 === this._eventsCount) return r;
        for(n in e = this._events)t.call(e, n) && r.push(i ? n.slice(1) : n);
        return Object.getOwnPropertySymbols ? r.concat(Object.getOwnPropertySymbols(e)) : r;
    }, a.prototype.listeners = function(e) {
        var t = i ? i + e : e, n = this._events[t];
        if (!n) return [];
        if (n.fn) return [
            n.fn
        ];
        for(var r = 0, s = n.length, o = new Array(s); r < s; r++)o[r] = n[r].fn;
        return o;
    }, a.prototype.listenerCount = function(e) {
        var t = i ? i + e : e, n = this._events[t];
        return n ? n.fn ? 1 : n.length : 0;
    }, a.prototype.emit = function(e, t, n, r, s, o) {
        var a = i ? i + e : e;
        if (!this._events[a]) return !1;
        var u, h, c = this._events[a], l = arguments.length;
        if (c.fn) {
            switch(c.once && this.removeListener(e, c.fn, void 0, !0), l){
                case 1:
                    return c.fn.call(c.context), !0;
                case 2:
                    return c.fn.call(c.context, t), !0;
                case 3:
                    return c.fn.call(c.context, t, n), !0;
                case 4:
                    return c.fn.call(c.context, t, n, r), !0;
                case 5:
                    return c.fn.call(c.context, t, n, r, s), !0;
                case 6:
                    return c.fn.call(c.context, t, n, r, s, o), !0;
            }
            for(h = 1, u = new Array(l - 1); h < l; h++)u[h - 1] = arguments[h];
            c.fn.apply(c.context, u);
        } else {
            var f, m = c.length;
            for(h = 0; h < m; h++)switch(c[h].once && this.removeListener(e, c[h].fn, void 0, !0), l){
                case 1:
                    c[h].fn.call(c[h].context);
                    break;
                case 2:
                    c[h].fn.call(c[h].context, t);
                    break;
                case 3:
                    c[h].fn.call(c[h].context, t, n);
                    break;
                case 4:
                    c[h].fn.call(c[h].context, t, n, r);
                    break;
                default:
                    if (!u) for(f = 1, u = new Array(l - 1); f < l; f++)u[f - 1] = arguments[f];
                    c[h].fn.apply(c[h].context, u);
            }
        }
        return !0;
    }, a.prototype.on = function(e, t, i) {
        return s(this, e, t, i, !1);
    }, a.prototype.once = function(e, t, i) {
        return s(this, e, t, i, !0);
    }, a.prototype.removeListener = function(e, t, n, r) {
        var s = i ? i + e : e;
        if (!this._events[s]) return this;
        if (!t) return o(this, s), this;
        var a = this._events[s];
        if (a.fn) a.fn !== t || r && !a.once || n && a.context !== n || o(this, s);
        else {
            for(var u = 0, h = [], c = a.length; u < c; u++)(a[u].fn !== t || r && !a[u].once || n && a[u].context !== n) && h.push(a[u]);
            h.length ? this._events[s] = 1 === h.length ? h[0] : h : o(this, s);
        }
        return this;
    }, a.prototype.removeAllListeners = function(e) {
        var t;
        return e ? (t = i ? i + e : e, this._events[t] && o(this, t)) : (this._events = new n(), this._eventsCount = 0), this;
    }, a.prototype.off = a.prototype.removeListener, a.prototype.addListener = a.prototype.on, a.prefixed = i, a.EventEmitter = a, e.exports = a;
}($)), $.exports), W = c(R);
function G(e, t) {
    const i = e.indexOf(t);
    i > -1 && (e.splice(i, 1), e.unshift(t));
}
function U(e, t) {
    const i = e.indexOf(t);
    i > -1 && (e.splice(i, 1), e.push(t));
}
function X(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
    const n = Math.max(0, Math.ceil((t - e) / i)), r = new Array(n);
    let s = -1;
    for(; ++s < n;)r[s] = e + s * i;
    return r;
}
var J = c(function() {
    if (B) return Y;
    B = 1;
    var e = /^\s+|\s+$/g, t = /^[-+]0x[0-9a-f]+$/i, i = /^0b[01]+$/i, n = /^0o[0-7]+$/i, r = parseInt, s = "object" == typeof h && h && h.Object === Object && h, o = "object" == typeof self && self && self.Object === Object && self, a = s || o || Function("return this")(), u = Object.prototype.toString, c = Math.max, l = Math.min, f = function f() {
        return a.Date.now();
    };
    function m(e) {
        var t = typeof e;
        return !!e && ("object" == t || "function" == t);
    }
    function d(s) {
        if ("number" == typeof s) return s;
        if (function(e) {
            return "symbol" == typeof e || function(e) {
                return !!e && "object" == typeof e;
            }(e) && "[object Symbol]" == u.call(e);
        }(s)) return NaN;
        if (m(s)) {
            var o = "function" == typeof s.valueOf ? s.valueOf() : s;
            s = m(o) ? o + "" : o;
        }
        if ("string" != typeof s) return 0 === s ? s : +s;
        s = s.replace(e, "");
        var a = i.test(s);
        return a || n.test(s) ? r(s.slice(2), a ? 2 : 8) : t.test(s) ? NaN : +s;
    }
    return Y = function(e, t, i) {
        var n, r, s, o, a, u, h = 0, p = !1, v = !1, y = !0;
        if ("function" != typeof e) throw new TypeError("Expected a function");
        function b(t) {
            var i = n, s = r;
            return n = r = void 0, h = t, o = e.apply(s, i);
        }
        function g(e) {
            var i = e - u;
            return void 0 === u || i >= t || i < 0 || v && e - h >= s;
        }
        function z() {
            var e = f();
            if (g(e)) return w(e);
            a = setTimeout(z, function(e) {
                var i = t - (e - u);
                return v ? l(i, s - (e - h)) : i;
            }(e));
        }
        function w(e) {
            return a = void 0, y && n ? b(e) : (n = r = void 0, o);
        }
        function S() {
            var e = f(), i = g(e);
            if (n = arguments, r = this, u = e, i) {
                if (void 0 === a) return function(e) {
                    return h = e, a = setTimeout(z, t), p ? b(e) : o;
                }(u);
                if (v) return a = setTimeout(z, t), b(u);
            }
            return void 0 === a && (a = setTimeout(z, t)), o;
        }
        return t = d(t) || 0, m(i) && (p = !!i.leading, s = (v = "maxWait" in i) ? c(d(i.maxWait) || 0, t) : s, y = "trailing" in i ? !!i.trailing : y), S.cancel = function() {
            void 0 !== a && clearTimeout(a), h = 0, n = u = r = a = void 0;
        }, S.flush = function() {
            return void 0 === a ? o : w(f());
        }, S;
    };
}()), K = "sash-module_sash__K-9lB", Z = "sash-module_disabled__Hm-wx", Q = "sash-module_mac__Jf6OJ", q = "sash-module_vertical__pB-rs", ee = "sash-module_minimum__-UKxp", te = "sash-module_maximum__TCWxD", ie = "sash-module_horizontal__kFbiw", ne = "sash-module_hover__80W6I", re = "sash-module_active__bJspD";
let se = function(e) {
    return e.Vertical = "VERTICAL", e.Horizontal = "HORIZONTAL", e;
}({}), oe = function(e) {
    return e.Disabled = "DISABLED", e.Minimum = "MINIMUM", e.Maximum = "MAXIMUM", e.Enabled = "ENABLED", e;
}({}), ae = A ? 20 : 8;
const ue = new W();
class he extends W {
    get state() {
        return this._state;
    }
    set state(e) {
        this._state !== e && (this.el.classList.toggle(Z, e === oe.Disabled), this.el.classList.toggle("sash-disabled", e === oe.Disabled), this.el.classList.toggle(ee, e === oe.Minimum), this.el.classList.toggle("sash-minimum", e === oe.Minimum), this.el.classList.toggle(te, e === oe.Maximum), this.el.classList.toggle("sash-maximum", e === oe.Maximum), this._state = e, this.emit("enablementChange", e));
    }
    layout() {
        if (this.orientation === se.Vertical) {
            const e = this.layoutProvider;
            this.el.style.left = e.getVerticalSashLeft(this) - this.size / 2 + "px", e.getVerticalSashTop && (this.el.style.top = e.getVerticalSashTop(this) + "px"), e.getVerticalSashHeight && (this.el.style.height = e.getVerticalSashHeight(this) + "px");
        } else {
            const e = this.layoutProvider;
            this.el.style.top = e.getHorizontalSashTop(this) - this.size / 2 + "px", e.getHorizontalSashLeft && (this.el.style.left = e.getHorizontalSashLeft(this) + "px"), e.getHorizontalSashWidth && (this.el.style.width = e.getHorizontalSashWidth(this) + "px");
        }
    }
    dispose() {
        this.el.removeEventListener("pointerdown", this.onPointerStart), this.el.removeEventListener("dblclick", this.onPointerDoublePress), this.el.removeEventListener("mouseenter", this.onMouseEnter), this.el.removeEventListener("mouseleave", ()=>this.onMouseLeave), this.el.remove();
    }
    constructor(e, t, i){
        var _i$orientation;
        super(), this.el = void 0, this.layoutProvider = void 0, this.orientation = void 0, this.size = void 0, this.hoverDelay = 300, this.hoverDelayer = J((e)=>e.classList.add("sash-hover", ne), this.hoverDelay), this._state = oe.Enabled, this.onPointerStart = (e)=>{
            const t = e.pageX, i = e.pageY, n = {
                startX: t,
                currentX: t,
                startY: i,
                currentY: i
            };
            this.el.classList.add("sash-active", re), this.emit("start", n), this.el.setPointerCapture(e.pointerId);
            const r = (e)=>{
                e.preventDefault();
                const n = {
                    startX: t,
                    currentX: e.pageX,
                    startY: i,
                    currentY: e.pageY
                };
                this.emit("change", n);
            }, s = (e)=>{
                e.preventDefault(), this.el.classList.remove("sash-active", re), this.hoverDelayer.cancel(), this.emit("end"), this.el.releasePointerCapture(e.pointerId), window.removeEventListener("pointermove", r), window.removeEventListener("pointerup", s);
            };
            window.addEventListener("pointermove", r), window.addEventListener("pointerup", s);
        }, this.onPointerDoublePress = ()=>{
            this.emit("reset");
        }, this.onMouseEnter = ()=>{
            this.el.classList.contains(re) ? (this.hoverDelayer.cancel(), this.el.classList.add("sash-hover", ne)) : this.hoverDelayer(this.el);
        }, this.onMouseLeave = ()=>{
            this.hoverDelayer.cancel(), this.el.classList.remove("sash-hover", ne);
        }, this.el = document.createElement("div"), this.el.classList.add("sash", K), this.el.dataset.testid = "sash", e.append(this.el), T && this.el.classList.add("sash-mac", Q), this.el.addEventListener("pointerdown", this.onPointerStart), this.el.addEventListener("dblclick", this.onPointerDoublePress), this.el.addEventListener("mouseenter", this.onMouseEnter), this.el.addEventListener("mouseleave", this.onMouseLeave), "number" == typeof i.size ? (this.size = i.size, i.orientation === se.Vertical ? this.el.style.width = "".concat(this.size, "px") : this.el.style.height = "".concat(this.size, "px")) : (this.size = ae, ue.on("onDidChangeGlobalSize", (e)=>{
            this.size = e, this.layout();
        })), this.layoutProvider = t, this.orientation = (_i$orientation = i.orientation) != null ? _i$orientation : se.Vertical, this.orientation === se.Horizontal ? (this.el.classList.add("sash-horizontal", ie), this.el.classList.remove("sash-vertical", q)) : (this.el.classList.remove("sash-horizontal", ie), this.el.classList.add("sash-vertical", q)), this.layout();
    }
}
let ce;
var le;
(le = ce || (ce = {})).Distribute = {
    type: "distribute"
}, le.Split = function(e) {
    return {
        type: "split",
        index: e
    };
}, le.Invisible = function(e) {
    return {
        type: "invisible",
        cachedVisibleSize: e
    };
};
let fe = function(e) {
    return e.Normal = "NORMAL", e.Low = "LOW", e.High = "HIGH", e;
}({});
class me {
    set size(e) {
        this._size = e;
    }
    get size() {
        return this._size;
    }
    get priority() {
        return this.view.priority;
    }
    get snap() {
        return !!this.view.snap;
    }
    get cachedVisibleSize() {
        return this._cachedVisibleSize;
    }
    get visible() {
        return void 0 === this._cachedVisibleSize;
    }
    setVisible(e, t) {
        e !== this.visible && (e ? (this.size = g(this._cachedVisibleSize, this.viewMinimumSize, this.viewMaximumSize), this._cachedVisibleSize = void 0) : (this._cachedVisibleSize = "number" == typeof t ? t : this.size, this.size = 0), this.container.classList.toggle("split-view-view-visible", e), this.view.setVisible && this.view.setVisible(e));
    }
    get minimumSize() {
        return this.visible ? this.view.minimumSize : 0;
    }
    get viewMinimumSize() {
        return this.view.minimumSize;
    }
    get maximumSize() {
        return this.visible ? this.view.maximumSize : 0;
    }
    get viewMaximumSize() {
        return this.view.maximumSize;
    }
    set enabled(e) {
        this.container.style.pointerEvents = e ? "" : "none";
    }
    layout(e) {
        this.layoutContainer(e), this.view.layout(this.size, e);
    }
    constructor(e, t, i){
        this.container = void 0, this.view = void 0, this._size = void 0, this._cachedVisibleSize = void 0, this.container = e, this.view = t, this.container.classList.add("split-view-view", j), this.container.dataset.testid = "split-view-view", "number" == typeof i ? (this._size = i, this._cachedVisibleSize = void 0, e.classList.add("split-view-view-visible")) : (this._size = 0, this._cachedVisibleSize = i.cachedVisibleSize);
    }
}
class de extends me {
    layoutContainer(e) {
        this.container.style.left = "".concat(e, "px"), this.container.style.width = "".concat(this.size, "px");
    }
}
class pe extends me {
    layoutContainer(e) {
        this.container.style.top = "".concat(e, "px"), this.container.style.height = "".concat(this.size, "px");
    }
}
class ve extends W {
    get startSnappingEnabled() {
        return this._startSnappingEnabled;
    }
    set startSnappingEnabled(e) {
        this._startSnappingEnabled !== e && (this._startSnappingEnabled = e, this.updateSashEnablement());
    }
    get endSnappingEnabled() {
        return this._endSnappingEnabled;
    }
    set endSnappingEnabled(e) {
        this._endSnappingEnabled !== e && (this._endSnappingEnabled = e, this.updateSashEnablement());
    }
    addView(e, t, i) {
        let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : this.viewItems.length, r = arguments.length > 4 ? arguments[4] : void 0;
        let s;
        s = "number" == typeof i ? i : "split" === i.type ? this.getViewSize(i.index) / 2 : "invisible" === i.type ? {
            cachedVisibleSize: i.cachedVisibleSize
        } : t.minimumSize;
        const o = this.orientation === se.Vertical ? new pe(e, t, s) : new de(e, t, s);
        if (this.viewItems.splice(n, 0, o), this.viewItems.length > 1) {
            const _e4 = this.orientation === se.Vertical ? new he(this.sashContainer, {
                getHorizontalSashTop: (e)=>this.getSashPosition(e),
                getHorizontalSashWidth: this.getSashOrthogonalSize
            }, {
                orientation: se.Horizontal
            }) : new he(this.sashContainer, {
                getVerticalSashLeft: (e)=>this.getSashPosition(e),
                getVerticalSashHeight: this.getSashOrthogonalSize
            }, {
                orientation: se.Vertical
            }), _t2 = this.orientation === se.Vertical ? (t)=>({
                    sash: _e4,
                    start: t.startY,
                    current: t.currentY
                }) : (t)=>({
                    sash: _e4,
                    start: t.startX,
                    current: t.currentX
                });
            _e4.on("start", (e)=>{
                var _this$onDidDragStart;
                this.emit("sashDragStart"), this.onSashStart(_t2(e));
                const i = this.viewItems.map((e)=>e.size);
                (_this$onDidDragStart = this.onDidDragStart) == null || _this$onDidDragStart.call(this, i);
            }), _e4.on("change", (e)=>this.onSashChange(_t2(e))), _e4.on("end", ()=>{
                var _this$onDidDragEnd;
                this.emit("sashDragEnd"), this.onSashEnd(this.sashItems.findIndex((t)=>t.sash === _e4));
                const t = this.viewItems.map((e)=>e.size);
                (_this$onDidDragEnd = this.onDidDragEnd) == null || _this$onDidDragEnd.call(this, t);
            }), _e4.on("reset", ()=>{
                const t = this.sashItems.findIndex((t)=>t.sash === _e4), i = X(t, -1, -1), n = X(t + 1, this.viewItems.length), r = this.findFirstSnapIndex(i), s = this.findFirstSnapIndex(n);
                ("number" != typeof r || this.viewItems[r].visible) && ("number" != typeof s || this.viewItems[s].visible) && this.emit("sashreset", t);
            });
            const _i2 = {
                sash: _e4
            };
            this.sashItems.splice(n - 1, 0, _i2);
        }
        r || this.relayout(), r || "number" == typeof i || "distribute" !== i.type || this.distributeViewSizes();
    }
    removeView(e, t) {
        if (e < 0 || e >= this.viewItems.length) throw new Error("Index out of bounds");
        const i = this.viewItems.splice(e, 1)[0].view;
        if (this.viewItems.length >= 1) {
            const _t3 = Math.max(e - 1, 0);
            this.sashItems.splice(_t3, 1)[0].sash.dispose();
        }
        return this.relayout(), t && "distribute" === t.type && this.distributeViewSizes(), i;
    }
    moveView(e, t, i) {
        const n = this.getViewCachedVisibleSize(t), r = void 0 === n ? this.getViewSize(t) : ce.Invisible(n), s = this.removeView(t);
        this.addView(e, s, r, i);
    }
    getViewCachedVisibleSize(e) {
        if (e < 0 || e >= this.viewItems.length) throw new Error("Index out of bounds");
        return this.viewItems[e].cachedVisibleSize;
    }
    layout() {
        let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.size;
        const t = Math.max(this.size, this.contentSize);
        if (this.size = e, this.proportions) for(let _t4 = 0; _t4 < this.viewItems.length; _t4++){
            const i = this.viewItems[_t4];
            i.size = g(Math.round(this.proportions[_t4] * e), i.minimumSize, i.maximumSize);
        }
        else {
            const i = X(0, this.viewItems.length), n = i.filter((e)=>this.viewItems[e].priority === fe.Low), r = i.filter((e)=>this.viewItems[e].priority === fe.High);
            this.resize(this.viewItems.length - 1, e - t, void 0, n, r);
        }
        this.distributeEmptySpace(), this.layoutViews();
    }
    resizeView(e, t) {
        if (e < 0 || e >= this.viewItems.length) return;
        const i = X(0, this.viewItems.length).filter((t)=>t !== e), n = [
            ...i.filter((e)=>this.viewItems[e].priority === fe.Low),
            e
        ], r = i.filter((e)=>this.viewItems[e].priority === fe.High), s = this.viewItems[e];
        t = Math.round(t), t = g(t, s.minimumSize, Math.min(s.maximumSize, this.size)), s.size = t, this.relayout(n, r);
    }
    resizeViews(e) {
        for(let t = 0; t < e.length; t++){
            const i = this.viewItems[t];
            let n = e[t];
            n = Math.round(n), n = g(n, i.minimumSize, Math.min(i.maximumSize, this.size)), i.size = n;
        }
        this.contentSize = this.viewItems.reduce((e, t)=>e + t.size, 0), this.saveProportions(), this.layout(this.size);
    }
    getViewSize(e) {
        return e < 0 || e >= this.viewItems.length ? -1 : this.viewItems[e].size;
    }
    isViewVisible(e) {
        if (e < 0 || e >= this.viewItems.length) throw new Error("Index out of bounds");
        return this.viewItems[e].visible;
    }
    setViewVisible(e, t) {
        if (e < 0 || e >= this.viewItems.length) throw new Error("Index out of bounds");
        this.viewItems[e].setVisible(t), this.distributeEmptySpace(e), this.layoutViews(), this.saveProportions();
    }
    distributeViewSizes() {
        const e = [];
        let t = 0;
        for (const _i3 of this.viewItems)_i3.maximumSize - _i3.minimumSize > 0 && (e.push(_i3), t += _i3.size);
        const i = Math.floor(t / e.length);
        for (const _t5 of e)_t5.size = g(i, _t5.minimumSize, _t5.maximumSize);
        const n = X(0, this.viewItems.length), r = n.filter((e)=>this.viewItems[e].priority === fe.Low), s = n.filter((e)=>this.viewItems[e].priority === fe.High);
        this.relayout(r, s);
    }
    dispose() {
        this.sashItems.forEach((e)=>e.sash.dispose()), this.sashItems = [], this.sashContainer.remove();
    }
    relayout(e, t) {
        const i = this.viewItems.reduce((e, t)=>e + t.size, 0);
        this.resize(this.viewItems.length - 1, this.size - i, void 0, e, t), this.distributeEmptySpace(), this.layoutViews(), this.saveProportions();
    }
    onSashStart(param) {
        let { sash: e, start: t } = param;
        const i = this.sashItems.findIndex((t)=>t.sash === e);
        ((e)=>{
            const t = this.viewItems.map((e)=>e.size);
            let n, r, s = Number.NEGATIVE_INFINITY, o = Number.POSITIVE_INFINITY;
            const a = X(i, -1, -1), u = X(i + 1, this.viewItems.length), h = a.reduce((e, i)=>e + (this.viewItems[i].minimumSize - t[i]), 0), c = a.reduce((e, i)=>e + (this.viewItems[i].viewMaximumSize - t[i]), 0), l = 0 === u.length ? Number.POSITIVE_INFINITY : u.reduce((e, i)=>e + (t[i] - this.viewItems[i].minimumSize), 0), f = 0 === u.length ? Number.NEGATIVE_INFINITY : u.reduce((e, i)=>e + (t[i] - this.viewItems[i].viewMaximumSize), 0);
            s = Math.max(h, f), o = Math.min(l, c);
            const m = this.findFirstSnapIndex(a), d = this.findFirstSnapIndex(u);
            if ("number" == typeof m) {
                const _e5 = this.viewItems[m], _t6 = Math.floor(_e5.viewMinimumSize / 2);
                n = {
                    index: m,
                    limitDelta: _e5.visible ? s - _t6 : s + _t6,
                    size: _e5.size
                };
            }
            if ("number" == typeof d) {
                const _e6 = this.viewItems[d], _t7 = Math.floor(_e6.viewMinimumSize / 2);
                r = {
                    index: d,
                    limitDelta: _e6.visible ? o + _t7 : o - _t7,
                    size: _e6.size
                };
            }
            this.sashDragState = {
                start: e,
                current: e,
                index: i,
                sizes: t,
                minDelta: s,
                maxDelta: o,
                snapBefore: n,
                snapAfter: r
            };
        })(t);
    }
    onSashChange(param) {
        let { current: e } = param;
        const { index: t, start: i, sizes: n, minDelta: r, maxDelta: s, snapBefore: o, snapAfter: a } = this.sashDragState;
        this.sashDragState.current = e;
        const u = e - i;
        this.resize(t, u, n, void 0, void 0, r, s, o, a), this.distributeEmptySpace(), this.layoutViews();
    }
    getSashPosition(e) {
        let t = 0;
        for(let i = 0; i < this.sashItems.length; i++)if (t += this.viewItems[i].size, this.sashItems[i].sash === e) return t;
        return 0;
    }
    resize(e, t) {
        let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.viewItems.map((e)=>e.size), n = arguments.length > 3 ? arguments[3] : void 0, r = arguments.length > 4 ? arguments[4] : void 0, s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : Number.NEGATIVE_INFINITY, o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : Number.POSITIVE_INFINITY, a = arguments.length > 7 ? arguments[7] : void 0, u = arguments.length > 8 ? arguments[8] : void 0;
        if (e < 0 || e >= this.viewItems.length) return 0;
        const h = X(e, -1, -1), c = X(e + 1, this.viewItems.length);
        if (r) for (const _e7 of r)G(h, _e7), G(c, _e7);
        if (n) for (const _e8 of n)U(h, _e8), U(c, _e8);
        const l = h.map((e)=>this.viewItems[e]), f = h.map((e)=>i[e]), m = c.map((e)=>this.viewItems[e]), d = c.map((e)=>i[e]), p = h.reduce((e, t)=>e + (this.viewItems[t].minimumSize - i[t]), 0), v = h.reduce((e, t)=>e + (this.viewItems[t].maximumSize - i[t]), 0), y = 0 === c.length ? Number.POSITIVE_INFINITY : c.reduce((e, t)=>e + (i[t] - this.viewItems[t].minimumSize), 0), b = 0 === c.length ? Number.NEGATIVE_INFINITY : c.reduce((e, t)=>e + (i[t] - this.viewItems[t].maximumSize), 0), z = Math.max(p, b, s), w = Math.min(y, v, o);
        let S = !1;
        if (a) {
            const _e9 = this.viewItems[a.index], _i4 = t >= a.limitDelta;
            S = _i4 !== _e9.visible, _e9.setVisible(_i4, a.size);
        }
        if (!S && u) {
            const _e0 = this.viewItems[u.index], _i5 = t < u.limitDelta;
            S = _i5 !== _e0.visible, _e0.setVisible(_i5, u.size);
        }
        if (S) return this.resize(e, t, i, n, r, s, o);
        for(let _e1 = 0, _i6 = t = g(t, z, w); _e1 < l.length; _e1++){
            const _t8 = l[_e1], _n2 = g(f[_e1] + _i6, _t8.minimumSize, _t8.maximumSize);
            _i6 -= _n2 - f[_e1], _t8.size = _n2;
        }
        for(let _e10 = 0, _i7 = t; _e10 < m.length; _e10++){
            const _t9 = m[_e10], _n3 = g(d[_e10] - _i7, _t9.minimumSize, _t9.maximumSize);
            _i7 += _n3 - d[_e10], _t9.size = _n3;
        }
        return t;
    }
    distributeEmptySpace(e) {
        const t = this.viewItems.reduce((e, t)=>e + t.size, 0);
        let i = this.size - t;
        const n = X(0, this.viewItems.length), r = [], s = n.filter((e)=>this.viewItems[e].priority === fe.Low), o = n.filter((e)=>this.viewItems[e].priority === fe.Normal), a = n.filter((e)=>this.viewItems[e].priority === fe.High);
        r.push(...a, ...o, ...s), "number" == typeof e && U(r, e);
        for(let _e11 = 0; 0 !== i && _e11 < r.length; _e11++){
            const _t0 = this.viewItems[r[_e11]], _n4 = g(_t0.size + i, _t0.minimumSize, _t0.maximumSize);
            i -= _n4 - _t0.size, _t0.size = _n4;
        }
    }
    layoutViews() {
        var _this$onDidChange;
        this.contentSize = this.viewItems.reduce((e, t)=>e + t.size, 0);
        let e = 0;
        for (const t of this.viewItems)t.layout(e), e += t.size;
        (_this$onDidChange = this.onDidChange) != null && _this$onDidChange.call(this, this.viewItems.map((e)=>e.size)), this.sashItems.forEach((e)=>e.sash.layout()), this.updateSashEnablement();
    }
    saveProportions() {
        this.proportionalLayout && this.contentSize > 0 && (this.proportions = this.viewItems.map((e)=>e.size / this.contentSize));
    }
    updateSashEnablement() {
        let e = !1;
        const t = this.viewItems.map((t)=>e = t.size - t.minimumSize > 0 || e);
        e = !1;
        const i = this.viewItems.map((t)=>e = t.maximumSize - t.size > 0 || e), n = [
            ...this.viewItems
        ].reverse();
        e = !1;
        const r = n.map((t)=>e = t.size - t.minimumSize > 0 || e).reverse();
        e = !1;
        const s = n.map((t)=>e = t.maximumSize - t.size > 0 || e).reverse();
        let o = 0;
        for(let _e12 = 0; _e12 < this.sashItems.length; _e12++){
            const { sash: _n5 } = this.sashItems[_e12];
            o += this.viewItems[_e12].size;
            const a = !(t[_e12] && s[_e12 + 1]), u = !(i[_e12] && r[_e12 + 1]);
            if (a && u) {
                const _i8 = X(_e12, -1, -1), _s = X(_e12 + 1, this.viewItems.length), _a = this.findFirstSnapIndex(_i8), _u = this.findFirstSnapIndex(_s), h = "number" == typeof _a && !this.viewItems[_a].visible, c = "number" == typeof _u && !this.viewItems[_u].visible;
                h && r[_e12] && (o > 0 || this.startSnappingEnabled) ? _n5.state = oe.Minimum : c && t[_e12] && (o < this.contentSize || this.endSnappingEnabled) ? _n5.state = oe.Maximum : _n5.state = oe.Disabled;
            } else _n5.state = a && !u ? oe.Minimum : !a && u ? oe.Maximum : oe.Enabled;
        }
    }
    findFirstSnapIndex(e) {
        for (const t of e){
            const _e13 = this.viewItems[t];
            if (_e13.visible && _e13.snap) return t;
        }
        for (const t of e){
            const _e14 = this.viewItems[t];
            if (_e14.visible && _e14.maximumSize - _e14.minimumSize > 0) return;
            if (!_e14.visible && _e14.snap) return t;
        }
    }
    constructor(e, t = {}, i, n, r){
        var _t$orientation, _t$proportionalLayout;
        if (super(), this.onDidChange = void 0, this.onDidDragStart = void 0, this.onDidDragEnd = void 0, this.orientation = void 0, this.sashContainer = void 0, this.size = 0, this.contentSize = 0, this.proportions = void 0, this.viewItems = [], this.sashItems = [], this.sashDragState = void 0, this.proportionalLayout = void 0, this.getSashOrthogonalSize = void 0, this._startSnappingEnabled = !0, this._endSnappingEnabled = !0, this.onSashEnd = (e)=>{
            this.emit("sashchange", e), this.saveProportions();
            for (const _e2 of this.viewItems)_e2.enabled = !0;
        }, this.orientation = (_t$orientation = t.orientation) != null ? _t$orientation : se.Vertical, this.proportionalLayout = (_t$proportionalLayout = t.proportionalLayout) != null ? _t$proportionalLayout : !0, this.getSashOrthogonalSize = t.getSashOrthogonalSize, i && (this.onDidChange = i), n && (this.onDidDragStart = n), r && (this.onDidDragEnd = r), this.sashContainer = document.createElement("div"), this.sashContainer.classList.add("sash-container", E), e.prepend(this.sashContainer), t.descriptor) {
            this.size = t.descriptor.size;
            for (const [_e3, _i] of t.descriptor.views.entries()){
                const _t = _i.size, _n = _i.container, _r = _i.view;
                this.addView(_n, _r, _t, _e3, !0);
            }
            this.contentSize = this.viewItems.reduce((e, t)=>e + t.size, 0), this.saveProportions();
        }
    }
}
class ye {
    getPreferredSize() {
        return this.size;
    }
    constructor(e){
        this.size = void 0, this.size = e;
    }
}
class be {
    getPreferredSize() {
        return this.proportion * this.layoutService.getSize();
    }
    constructor(e, t){
        this.proportion = void 0, this.layoutService = void 0, this.proportion = e, this.layoutService = t;
    }
}
class ge {
    getPreferredSize() {}
}
class ze {
    get preferredSize() {
        return this.layoutStrategy.getPreferredSize();
    }
    set preferredSize(e) {
        if ("number" == typeof e) this.layoutStrategy = new ye(e);
        else if ("string" == typeof e) {
            const t = e.trim();
            if (k(t, "%")) {
                const _e15 = Number(t.slice(0, -1)) / 100;
                this.layoutStrategy = new be(_e15, this.layoutService);
            } else if (k(t, "px")) {
                const _e16 = Number(t.slice(0, -2)) / 100;
                this.layoutStrategy = new ye(_e16);
            } else if ("number" == typeof Number.parseFloat(t)) {
                const _e17 = Number.parseFloat(t);
                this.layoutStrategy = new ye(_e17);
            } else this.layoutStrategy = new ge();
        } else this.layoutStrategy = new ge();
    }
    layout(e) {}
    constructor(e, t){
        var _t$priority;
        if (this.minimumSize = 0, this.maximumSize = Number.POSITIVE_INFINITY, this.element = void 0, this.priority = void 0, this.snap = void 0, this.layoutService = void 0, this.layoutStrategy = void 0, this.layoutService = e, this.element = t.element, this.minimumSize = "number" == typeof t.minimumSize ? t.minimumSize : 30, this.maximumSize = "number" == typeof t.maximumSize ? t.maximumSize : Number.POSITIVE_INFINITY, "number" == typeof t.preferredSize) this.layoutStrategy = new ye(t.preferredSize);
        else if ("string" == typeof t.preferredSize) {
            const _e18 = t.preferredSize.trim();
            if (k(_e18, "%")) {
                const _t1 = Number(_e18.slice(0, -1)) / 100;
                this.layoutStrategy = new be(_t1, this.layoutService);
            } else if (k(_e18, "px")) {
                const _t10 = Number(_e18.slice(0, -2));
                this.layoutStrategy = new ye(_t10);
            } else if ("number" == typeof Number.parseFloat(_e18)) {
                const _t11 = Number.parseFloat(_e18);
                this.layoutStrategy = new ye(_t11);
            } else this.layoutStrategy = new ge();
        } else this.layoutStrategy = new ge();
        this.priority = (_t$priority = t.priority) != null ? _t$priority : fe.Normal, this.snap = "boolean" == typeof t.snap && t.snap;
    }
}
function we(e) {
    return void 0 !== e.minSize || void 0 !== e.maxSize || void 0 !== e.preferredSize || void 0 !== e.priority || void 0 !== e.visible;
}
const Se = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])((param, n)=>{
    let { className: t, children: i } = param;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        ref: n,
        className: y("split-view-view", j, t)
    }, i);
});
Se.displayName = "Allotment.Pane";
const _e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])((param, j)=>{
    let { children: o, className: a, id: h, maxSize: c = 1 / 0, minSize: l = 30, proportionalLayout: f = !0, separator: m = !0, sizes: d, defaultSizes: p = d, snap: v = !1, vertical: b = !1, onChange: g, onReset: z, onVisibleChange: w, onDragStart: _, onDragEnd: E } = param;
    const D = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), P = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map()), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map()), H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new F()), $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), [Y, B] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1);
    "production" !== ("TURBOPACK compile-time value", "development") && d && console.warn("Prop sizes is deprecated. Please use defaultSizes instead.");
    const R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.toArray(o).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isValidElement), [
        o
    ]), W = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        var _$$current, _T$current;
        const t = (_$$current = $.current) == null ? void 0 : _$$current[e];
        return "number" == typeof (t == null ? void 0 : t.preferredSize) && ((_T$current = T.current) != null && _T$current.resizeView(e, Math.round(t.preferredSize)), !0);
    }, []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(j, ()=>({
            reset: ()=>{
                if (z) z();
                else {
                    var _T$current2;
                    (_T$current2 = T.current) == null || _T$current2.distributeViewSizes();
                    for(let e = 0; e < $.current.length; e++)W(e);
                }
            },
            resize: (e)=>{
                var _T$current3;
                (_T$current3 = T.current) == null || _T$current3.resizeViews(e);
            }
        })), C(()=>{
        let e = !0;
        p && k.current.size !== p.length && (e = !1, console.warn("Expected ".concat(p.length, " children based on defaultSizes but found ").concat(k.current.size))), e && p && (M.current = R.map((e)=>e.key));
        const t = _extends({
            orientation: b ? se.Vertical : se.Horizontal,
            proportionalLayout: f
        }, e && p && {
            descriptor: {
                size: p.reduce((e, t)=>e + t, 0),
                views: p.map((e, t)=>{
                    var _i$minSize, _i$maxSize, _i$priority, _i$snap;
                    const i = P.current.get(M.current[t]), n = new ze(H.current, _extends({
                        element: document.createElement("div"),
                        minimumSize: (_i$minSize = i == null ? void 0 : i.minSize) != null ? _i$minSize : l,
                        maximumSize: (_i$maxSize = i == null ? void 0 : i.maxSize) != null ? _i$maxSize : c,
                        priority: (_i$priority = i == null ? void 0 : i.priority) != null ? _i$priority : fe.Normal
                    }, (i == null ? void 0 : i.preferredSize) && {
                        preferredSize: i == null ? void 0 : i.preferredSize
                    }, {
                        snap: (_i$snap = i == null ? void 0 : i.snap) != null ? _i$snap : v
                    }));
                    return $.current.push(n), {
                        container: [
                            ...k.current.values()
                        ][t],
                        size: e,
                        view: n
                    };
                })
            }
        });
        T.current = new ve(D.current, t, g, _, E), T.current.on("sashDragStart", ()=>{
            var _D$current;
            (_D$current = D.current) == null || _D$current.classList.add("split-view-sash-dragging");
        }), T.current.on("sashDragEnd", ()=>{
            var _D$current2;
            (_D$current2 = D.current) == null || _D$current2.classList.remove("split-view-sash-dragging");
        }), T.current.on("sashchange", (e)=>{
            if (w && T.current) {
                const _e19 = R.map((e)=>e.key);
                for(let t = 0; t < _e19.length; t++){
                    const i = P.current.get(_e19[t]);
                    void 0 !== (i == null ? void 0 : i.visible) && i.visible !== T.current.isViewVisible(t) && w(t, T.current.isViewVisible(t));
                }
            }
        }), T.current.on("sashreset", (e)=>{
            if (z) z();
            else {
                var _T$current4;
                if (W(e)) return;
                if (W(e + 1)) return;
                (_T$current4 = T.current) == null || _T$current4.distributeViewSizes();
            }
        });
        const i = T.current;
        return ()=>{
            i.dispose();
        };
    }, []), C(()=>{
        if (Y) {
            const e = R.map((e)=>e.key), t = [
                ...M.current
            ], i = e.filter((e)=>!M.current.includes(e)), n = e.filter((e)=>M.current.includes(e)), r = M.current.map((t)=>!e.includes(t));
            for(let _e20 = r.length - 1; _e20 >= 0; _e20--){
                var _T$current5;
                r[_e20] && ((_T$current5 = T.current) != null && _T$current5.removeView(_e20), t.splice(_e20, 1), $.current.splice(_e20, 1));
            }
            for (const _n6 of i){
                var _i9$minSize, _i9$maxSize, _i9$priority, _i9$snap, _T$current6;
                const _i9 = P.current.get(_n6), _r2 = new ze(H.current, _extends({
                    element: document.createElement("div"),
                    minimumSize: (_i9$minSize = _i9 == null ? void 0 : _i9.minSize) != null ? _i9$minSize : l,
                    maximumSize: (_i9$maxSize = _i9 == null ? void 0 : _i9.maxSize) != null ? _i9$maxSize : c,
                    priority: (_i9$priority = _i9 == null ? void 0 : _i9.priority) != null ? _i9$priority : fe.Normal
                }, (_i9 == null ? void 0 : _i9.preferredSize) && {
                    preferredSize: _i9 == null ? void 0 : _i9.preferredSize
                }, {
                    snap: (_i9$snap = _i9 == null ? void 0 : _i9.snap) != null ? _i9$snap : v
                }));
                (_T$current6 = T.current) != null && _T$current6.addView(k.current.get(_n6), _r2, ce.Distribute, e.findIndex((e)=>e === _n6)), t.splice(e.findIndex((e)=>e === _n6), 0, _n6), $.current.splice(e.findIndex((e)=>e === _n6), 0, _r2);
            }
            for(; !S(e, t);)for (const [_i0, _n7] of e.entries()){
                const _e21 = t.findIndex((e)=>e === _n7);
                if (_e21 !== _i0) {
                    var _T$current7;
                    (_T$current7 = T.current) == null || _T$current7.moveView(k.current.get(_n7), _e21, _i0);
                    const _r3 = t[_e21];
                    t.splice(_e21, 1), t.splice(_i0, 0, _r3);
                    break;
                }
            }
            for (const _t12 of i){
                var _T$current8;
                const _i1 = e.findIndex((e)=>e === _t12), _n8 = $.current[_i1].preferredSize;
                void 0 !== _n8 && ((_T$current8 = T.current) == null ? void 0 : _T$current8.resizeView(_i1, _n8));
            }
            for (const _t13 of [
                ...i,
                ...n
            ]){
                var _T$current9, _T$current0;
                const _i10 = P.current.get(_t13), _n9 = e.findIndex((e)=>e === _t13);
                _i10 && we(_i10) && void 0 !== _i10.visible && ((_T$current9 = T.current) == null ? void 0 : _T$current9.isViewVisible(_n9)) !== _i10.visible && ((_T$current0 = T.current) == null ? void 0 : _T$current0.setViewVisible(_n9, _i10.visible));
            }
            for (const _t14 of n){
                const _i11 = P.current.get(_t14), _n0 = e.findIndex((e)=>e === _t14);
                if (_i11 && we(_i11)) {
                    var _T$current1;
                    void 0 !== _i11.preferredSize && $.current[_n0].preferredSize !== _i11.preferredSize && ($.current[_n0].preferredSize = _i11.preferredSize);
                    let _e22 = !1;
                    void 0 !== _i11.minSize && $.current[_n0].minimumSize !== _i11.minSize && ($.current[_n0].minimumSize = _i11.minSize, _e22 = !0), void 0 !== _i11.maxSize && $.current[_n0].maximumSize !== _i11.maxSize && ($.current[_n0].maximumSize = _i11.maxSize, _e22 = !0), _e22 && ((_T$current1 = T.current) == null ? void 0 : _T$current1.layout());
                }
            }
            (i.length > 0 || r.length > 0) && (M.current = e);
        }
    }, [
        R,
        Y,
        c,
        l,
        v
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        T.current && (T.current.onDidChange = g);
    }, [
        g
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        T.current && (T.current.onDidDragStart = _);
    }, [
        _
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        T.current && (T.current.onDidDragEnd = E);
    }, [
        E
    ]), I({
        ref: D,
        onResize: (param)=>{
            let { width: e, height: t } = param;
            var _T$current10;
            e && t && ((_T$current10 = T.current) != null && _T$current10.layout(b ? t : e), H.current.setSize(b ? t : e), B(!0));
        }
    }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        A && Ie(20);
    }, []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        ref: D,
        className: y("split-view", b ? "split-view-vertical" : "split-view-horizontal", {
            "split-view-separator-border": m
        }, x, b ? N : L, {
            [O]: m
        }, a),
        id: h
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        className: y("split-view-container", V)
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.toArray(o).map((t)=>{
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isValidElement(t)) return null;
        const i = t.key;
        return "Allotment.Pane" === t.type.displayName ? (P.current.set(i, t.props), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(t, {
            key: i,
            ref: (e)=>{
                const n = t.ref;
                n && (n.current = e), e ? k.current.set(i, e) : k.current.delete(i);
            }
        })) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Se, {
            key: i,
            ref: (e)=>{
                e ? k.current.set(i, e) : k.current.delete(i);
            }
        }, t);
    })));
});
function Ie(e) {
    const t = g(e, 4, 20), i = g(e, 1, 8);
    document.documentElement.style.setProperty("--sash-size", t + "px"), document.documentElement.style.setProperty("--sash-hover-size", i + "px"), function(e) {
        ae = e, ue.emit("onDidChangeGlobalSize", e);
    }(t);
}
_e.displayName = "Allotment";
var xe = Object.assign(_e, {
    Pane: Se
});
;
}),
"[project]/node_modules/.pnpm/use-sync-external-store@1.5.0_react@19.1.0/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
/**
 * @license React
 * use-sync-external-store-shim.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function is(x, y) {
        return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
    }
    function useSyncExternalStore$2(subscribe, getSnapshot) {
        didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
        var value = getSnapshot();
        if (!didWarnUncachedGetSnapshot) {
            var cachedValue = getSnapshot();
            objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
        }
        cachedValue = useState({
            inst: {
                value: value,
                getSnapshot: getSnapshot
            }
        });
        var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
        useLayoutEffect({
            "useSyncExternalStore$2.useLayoutEffect": function() {
                inst.value = value;
                inst.getSnapshot = getSnapshot;
                checkIfSnapshotChanged(inst) && forceUpdate({
                    inst: inst
                });
            }
        }["useSyncExternalStore$2.useLayoutEffect"], [
            subscribe,
            value,
            getSnapshot
        ]);
        useEffect({
            "useSyncExternalStore$2.useEffect": function() {
                checkIfSnapshotChanged(inst) && forceUpdate({
                    inst: inst
                });
                return subscribe({
                    "useSyncExternalStore$2.useEffect": function() {
                        checkIfSnapshotChanged(inst) && forceUpdate({
                            inst: inst
                        });
                    }
                }["useSyncExternalStore$2.useEffect"]);
            }
        }["useSyncExternalStore$2.useEffect"], [
            subscribe
        ]);
        useDebugValue(value);
        return value;
    }
    function checkIfSnapshotChanged(inst) {
        var latestGetSnapshot = inst.getSnapshot;
        inst = inst.value;
        try {
            var nextValue = latestGetSnapshot();
            return !objectIs(inst, nextValue);
        } catch (error) {
            return !0;
        }
    }
    function useSyncExternalStore$1(subscribe, getSnapshot) {
        return getSnapshot();
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var React = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
    exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
}();
}}),
"[project]/node_modules/.pnpm/use-sync-external-store@1.5.0_react@19.1.0/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/use-sync-external-store@1.5.0_react@19.1.0/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)");
}
}}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_extends
});
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", _extends.apply(null, arguments);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_assertThisInitialized
});
function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_setPrototypeOf
});
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/inheritsLoose.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_inheritsLoose
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$setPrototypeOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js [app-client] (ecmascript)");
;
function _inheritsLoose(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$setPrototypeOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t, o);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_objectWithoutPropertiesLoose
});
function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for(var n in r)if (({}).hasOwnProperty.call(r, n)) {
        if (-1 !== e.indexOf(n)) continue;
        t[n] = r[n];
    }
    return t;
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_typeof
});
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/toPrimitive.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>toPrimitive
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)");
;
function toPrimitive(t, r) {
    if ("object" != (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>toPropertyKey
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/typeof.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/toPrimitive.js [app-client] (ecmascript)");
;
;
function toPropertyKey(t) {
    var i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPrimitive$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(t, "string");
    return "symbol" == (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$typeof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(i) ? i : i + "";
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/defineProperty.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_defineProperty
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPropertyKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js [app-client] (ecmascript)");
;
function _defineProperty(e, r, t) {
    return (r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$toPropertyKey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/objectSpread2.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>_objectSpread2
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$defineProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/defineProperty.js [app-client] (ecmascript)");
;
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread2(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$defineProperty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
;
}),
"[project]/node_modules/.pnpm/memoize-one@5.2.1/node_modules/memoize-one/dist/memoize-one.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var safeIsNaN = Number.isNaN || function ponyfill(value) {
    return typeof value === 'number' && value !== value;
};
function isEqual(first, second) {
    if (first === second) {
        return true;
    }
    if (safeIsNaN(first) && safeIsNaN(second)) {
        return true;
    }
    return false;
}
function areInputsEqual(newInputs, lastInputs) {
    if (newInputs.length !== lastInputs.length) {
        return false;
    }
    for(var i = 0; i < newInputs.length; i++){
        if (!isEqual(newInputs[i], lastInputs[i])) {
            return false;
        }
    }
    return true;
}
function memoizeOne(resultFn, isEqual) {
    if (isEqual === void 0) {
        isEqual = areInputsEqual;
    }
    var lastThis;
    var lastArgs = [];
    var lastResult;
    var calledOnce = false;
    function memoized() {
        var newArgs = [];
        for(var _i = 0; _i < arguments.length; _i++){
            newArgs[_i] = arguments[_i];
        }
        if (calledOnce && lastThis === this && isEqual(newArgs, lastArgs)) {
            return lastResult;
        }
        lastResult = resultFn.apply(this, newArgs);
        calledOnce = true;
        lastThis = this;
        lastArgs = newArgs;
        return lastResult;
    }
    return memoized;
}
const __TURBOPACK__default__export__ = memoizeOne;
}),
"[project]/node_modules/.pnpm/react-window@1.8.11_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-window/dist/index.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "FixedSizeGrid": ()=>FixedSizeGrid,
    "FixedSizeList": ()=>FixedSizeList,
    "VariableSizeGrid": ()=>VariableSizeGrid,
    "VariableSizeList": ()=>VariableSizeList,
    "areEqual": ()=>areEqual,
    "shouldComponentUpdate": ()=>shouldComponentUpdate
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$assertThisInitialized$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/inheritsLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/memoize-one@5.2.1/node_modules/memoize-one/dist/memoize-one.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
;
;
;
;
;
;
// Animation frame based implementation of setTimeout.
// Inspired by Joe Lambert, https://gist.github.com/joelambert/1002116#file-requesttimeout-js
var hasNativePerformanceNow = typeof performance === 'object' && typeof performance.now === 'function';
var now = hasNativePerformanceNow ? function() {
    return performance.now();
} : function() {
    return Date.now();
};
function cancelTimeout(timeoutID) {
    cancelAnimationFrame(timeoutID.id);
}
function requestTimeout(callback, delay) {
    var start = now();
    function tick() {
        if (now() - start >= delay) {
            callback.call(null);
        } else {
            timeoutID.id = requestAnimationFrame(tick);
        }
    }
    var timeoutID = {
        id: requestAnimationFrame(tick)
    };
    return timeoutID;
}
var size = -1; // This utility copied from "dom-helpers" package.
function getScrollbarSize(recalculate) {
    if (recalculate === void 0) {
        recalculate = false;
    }
    if (size === -1 || recalculate) {
        var div = document.createElement('div');
        var style = div.style;
        style.width = '50px';
        style.height = '50px';
        style.overflow = 'scroll';
        document.body.appendChild(div);
        size = div.offsetWidth - div.clientWidth;
        document.body.removeChild(div);
    }
    return size;
}
var cachedRTLResult = null; // TRICKY According to the spec, scrollLeft should be negative for RTL aligned elements.
// Chrome does not seem to adhere; its scrollLeft values are positive (measured relative to the left).
// Safari's elastic bounce makes detecting this even more complicated wrt potential false positives.
// The safest way to check this is to intentionally set a negative offset,
// and then verify that the subsequent "scroll" event matches the negative offset.
// If it does not match, then we can assume a non-standard RTL scroll implementation.
function getRTLOffsetType(recalculate) {
    if (recalculate === void 0) {
        recalculate = false;
    }
    if (cachedRTLResult === null || recalculate) {
        var outerDiv = document.createElement('div');
        var outerStyle = outerDiv.style;
        outerStyle.width = '50px';
        outerStyle.height = '50px';
        outerStyle.overflow = 'scroll';
        outerStyle.direction = 'rtl';
        var innerDiv = document.createElement('div');
        var innerStyle = innerDiv.style;
        innerStyle.width = '100px';
        innerStyle.height = '100px';
        outerDiv.appendChild(innerDiv);
        document.body.appendChild(outerDiv);
        if (outerDiv.scrollLeft > 0) {
            cachedRTLResult = 'positive-descending';
        } else {
            outerDiv.scrollLeft = 1;
            if (outerDiv.scrollLeft === 0) {
                cachedRTLResult = 'negative';
            } else {
                cachedRTLResult = 'positive-ascending';
            }
        }
        document.body.removeChild(outerDiv);
        return cachedRTLResult;
    }
    return cachedRTLResult;
}
var IS_SCROLLING_DEBOUNCE_INTERVAL = 150;
var defaultItemKey = function defaultItemKey(_ref) {
    var columnIndex = _ref.columnIndex, data = _ref.data, rowIndex = _ref.rowIndex;
    return rowIndex + ":" + columnIndex;
}; // In DEV mode, this Set helps us only log a warning once per component instance.
// This avoids spamming the console every time a render happens.
var devWarningsOverscanCount = null;
var devWarningsOverscanRowsColumnsCount = null;
var devWarningsTagName = null;
if ("TURBOPACK compile-time truthy", 1) {
    if (typeof window !== 'undefined' && typeof window.WeakSet !== 'undefined') {
        devWarningsOverscanCount = /*#__PURE__*/ new WeakSet();
        devWarningsOverscanRowsColumnsCount = /*#__PURE__*/ new WeakSet();
        devWarningsTagName = /*#__PURE__*/ new WeakSet();
    }
}
function createGridComponent(_ref2) {
    var _class;
    var getColumnOffset = _ref2.getColumnOffset, getColumnStartIndexForOffset = _ref2.getColumnStartIndexForOffset, getColumnStopIndexForStartIndex = _ref2.getColumnStopIndexForStartIndex, getColumnWidth = _ref2.getColumnWidth, getEstimatedTotalHeight = _ref2.getEstimatedTotalHeight, getEstimatedTotalWidth = _ref2.getEstimatedTotalWidth, getOffsetForColumnAndAlignment = _ref2.getOffsetForColumnAndAlignment, getOffsetForRowAndAlignment = _ref2.getOffsetForRowAndAlignment, getRowHeight = _ref2.getRowHeight, getRowOffset = _ref2.getRowOffset, getRowStartIndexForOffset = _ref2.getRowStartIndexForOffset, getRowStopIndexForStartIndex = _ref2.getRowStopIndexForStartIndex, initInstanceProps = _ref2.initInstanceProps, shouldResetStyleCacheOnItemSizeChange = _ref2.shouldResetStyleCacheOnItemSizeChange, validateProps = _ref2.validateProps;
    return _class = /*#__PURE__*/ function(_PureComponent) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Grid, _PureComponent);
        // Always use explicit constructor for React components.
        // It produces less code after transpilation. (#26)
        // eslint-disable-next-line no-useless-constructor
        function Grid(props) {
            var _this;
            _this = _PureComponent.call(this, props) || this;
            _this._instanceProps = initInstanceProps(_this.props, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$assertThisInitialized$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this));
            _this._resetIsScrollingTimeoutId = null;
            _this._outerRef = void 0;
            _this.state = {
                instance: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$assertThisInitialized$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this),
                isScrolling: false,
                horizontalScrollDirection: 'forward',
                scrollLeft: typeof _this.props.initialScrollLeft === 'number' ? _this.props.initialScrollLeft : 0,
                scrollTop: typeof _this.props.initialScrollTop === 'number' ? _this.props.initialScrollTop : 0,
                scrollUpdateWasRequested: false,
                verticalScrollDirection: 'forward'
            };
            _this._callOnItemsRendered = void 0;
            _this._callOnItemsRendered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(overscanColumnStartIndex, overscanColumnStopIndex, overscanRowStartIndex, overscanRowStopIndex, visibleColumnStartIndex, visibleColumnStopIndex, visibleRowStartIndex, visibleRowStopIndex) {
                return _this.props.onItemsRendered({
                    overscanColumnStartIndex: overscanColumnStartIndex,
                    overscanColumnStopIndex: overscanColumnStopIndex,
                    overscanRowStartIndex: overscanRowStartIndex,
                    overscanRowStopIndex: overscanRowStopIndex,
                    visibleColumnStartIndex: visibleColumnStartIndex,
                    visibleColumnStopIndex: visibleColumnStopIndex,
                    visibleRowStartIndex: visibleRowStartIndex,
                    visibleRowStopIndex: visibleRowStopIndex
                });
            });
            _this._callOnScroll = void 0;
            _this._callOnScroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(scrollLeft, scrollTop, horizontalScrollDirection, verticalScrollDirection, scrollUpdateWasRequested) {
                return _this.props.onScroll({
                    horizontalScrollDirection: horizontalScrollDirection,
                    scrollLeft: scrollLeft,
                    scrollTop: scrollTop,
                    verticalScrollDirection: verticalScrollDirection,
                    scrollUpdateWasRequested: scrollUpdateWasRequested
                });
            });
            _this._getItemStyle = void 0;
            _this._getItemStyle = function(rowIndex, columnIndex) {
                var _this$props = _this.props, columnWidth = _this$props.columnWidth, direction = _this$props.direction, rowHeight = _this$props.rowHeight;
                var itemStyleCache = _this._getItemStyleCache(shouldResetStyleCacheOnItemSizeChange && columnWidth, shouldResetStyleCacheOnItemSizeChange && direction, shouldResetStyleCacheOnItemSizeChange && rowHeight);
                var key = rowIndex + ":" + columnIndex;
                var style;
                if (itemStyleCache.hasOwnProperty(key)) {
                    style = itemStyleCache[key];
                } else {
                    var _offset = getColumnOffset(_this.props, columnIndex, _this._instanceProps);
                    var isRtl = direction === 'rtl';
                    itemStyleCache[key] = style = {
                        position: 'absolute',
                        left: isRtl ? undefined : _offset,
                        right: isRtl ? _offset : undefined,
                        top: getRowOffset(_this.props, rowIndex, _this._instanceProps),
                        height: getRowHeight(_this.props, rowIndex, _this._instanceProps),
                        width: getColumnWidth(_this.props, columnIndex, _this._instanceProps)
                    };
                }
                return style;
            };
            _this._getItemStyleCache = void 0;
            _this._getItemStyleCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(_, __, ___) {
                return {};
            });
            _this._onScroll = function(event) {
                var _event$currentTarget = event.currentTarget, clientHeight = _event$currentTarget.clientHeight, clientWidth = _event$currentTarget.clientWidth, scrollLeft = _event$currentTarget.scrollLeft, scrollTop = _event$currentTarget.scrollTop, scrollHeight = _event$currentTarget.scrollHeight, scrollWidth = _event$currentTarget.scrollWidth;
                _this.setState(function(prevState) {
                    if (prevState.scrollLeft === scrollLeft && prevState.scrollTop === scrollTop) {
                        // Scroll position may have been updated by cDM/cDU,
                        // In which case we don't need to trigger another render,
                        // And we don't want to update state.isScrolling.
                        return null;
                    }
                    var direction = _this.props.direction; // TRICKY According to the spec, scrollLeft should be negative for RTL aligned elements.
                    // This is not the case for all browsers though (e.g. Chrome reports values as positive, measured relative to the left).
                    // It's also easier for this component if we convert offsets to the same format as they would be in for ltr.
                    // So the simplest solution is to determine which browser behavior we're dealing with, and convert based on it.
                    var calculatedScrollLeft = scrollLeft;
                    if (direction === 'rtl') {
                        switch(getRTLOffsetType()){
                            case 'negative':
                                calculatedScrollLeft = -scrollLeft;
                                break;
                            case 'positive-descending':
                                calculatedScrollLeft = scrollWidth - clientWidth - scrollLeft;
                                break;
                        }
                    } // Prevent Safari's elastic scrolling from causing visual shaking when scrolling past bounds.
                    calculatedScrollLeft = Math.max(0, Math.min(calculatedScrollLeft, scrollWidth - clientWidth));
                    var calculatedScrollTop = Math.max(0, Math.min(scrollTop, scrollHeight - clientHeight));
                    return {
                        isScrolling: true,
                        horizontalScrollDirection: prevState.scrollLeft < scrollLeft ? 'forward' : 'backward',
                        scrollLeft: calculatedScrollLeft,
                        scrollTop: calculatedScrollTop,
                        verticalScrollDirection: prevState.scrollTop < scrollTop ? 'forward' : 'backward',
                        scrollUpdateWasRequested: false
                    };
                }, _this._resetIsScrollingDebounced);
            };
            _this._outerRefSetter = function(ref) {
                var outerRef = _this.props.outerRef;
                _this._outerRef = ref;
                if (typeof outerRef === 'function') {
                    outerRef(ref);
                } else if (outerRef != null && typeof outerRef === 'object' && outerRef.hasOwnProperty('current')) {
                    outerRef.current = ref;
                }
            };
            _this._resetIsScrollingDebounced = function() {
                if (_this._resetIsScrollingTimeoutId !== null) {
                    cancelTimeout(_this._resetIsScrollingTimeoutId);
                }
                _this._resetIsScrollingTimeoutId = requestTimeout(_this._resetIsScrolling, IS_SCROLLING_DEBOUNCE_INTERVAL);
            };
            _this._resetIsScrolling = function() {
                _this._resetIsScrollingTimeoutId = null;
                _this.setState({
                    isScrolling: false
                }, function() {
                    // Clear style cache after state update has been committed.
                    // This way we don't break pure sCU for items that don't use isScrolling param.
                    _this._getItemStyleCache(-1);
                });
            };
            return _this;
        }
        Grid.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
            validateSharedProps(nextProps, prevState);
            validateProps(nextProps);
            return null;
        };
        var _proto = Grid.prototype;
        _proto.scrollTo = function scrollTo(_ref3) {
            var scrollLeft = _ref3.scrollLeft, scrollTop = _ref3.scrollTop;
            if (scrollLeft !== undefined) {
                scrollLeft = Math.max(0, scrollLeft);
            }
            if (scrollTop !== undefined) {
                scrollTop = Math.max(0, scrollTop);
            }
            this.setState(function(prevState) {
                if (scrollLeft === undefined) {
                    scrollLeft = prevState.scrollLeft;
                }
                if (scrollTop === undefined) {
                    scrollTop = prevState.scrollTop;
                }
                if (prevState.scrollLeft === scrollLeft && prevState.scrollTop === scrollTop) {
                    return null;
                }
                return {
                    horizontalScrollDirection: prevState.scrollLeft < scrollLeft ? 'forward' : 'backward',
                    scrollLeft: scrollLeft,
                    scrollTop: scrollTop,
                    scrollUpdateWasRequested: true,
                    verticalScrollDirection: prevState.scrollTop < scrollTop ? 'forward' : 'backward'
                };
            }, this._resetIsScrollingDebounced);
        };
        _proto.scrollToItem = function scrollToItem(_ref4) {
            var _ref4$align = _ref4.align, align = _ref4$align === void 0 ? 'auto' : _ref4$align, columnIndex = _ref4.columnIndex, rowIndex = _ref4.rowIndex;
            var _this$props2 = this.props, columnCount = _this$props2.columnCount, height = _this$props2.height, rowCount = _this$props2.rowCount, width = _this$props2.width;
            var _this$state = this.state, scrollLeft = _this$state.scrollLeft, scrollTop = _this$state.scrollTop;
            var scrollbarSize = getScrollbarSize();
            if (columnIndex !== undefined) {
                columnIndex = Math.max(0, Math.min(columnIndex, columnCount - 1));
            }
            if (rowIndex !== undefined) {
                rowIndex = Math.max(0, Math.min(rowIndex, rowCount - 1));
            }
            var estimatedTotalHeight = getEstimatedTotalHeight(this.props, this._instanceProps);
            var estimatedTotalWidth = getEstimatedTotalWidth(this.props, this._instanceProps); // The scrollbar size should be considered when scrolling an item into view,
            // to ensure it's fully visible.
            // But we only need to account for its size when it's actually visible.
            var horizontalScrollbarSize = estimatedTotalWidth > width ? scrollbarSize : 0;
            var verticalScrollbarSize = estimatedTotalHeight > height ? scrollbarSize : 0;
            this.scrollTo({
                scrollLeft: columnIndex !== undefined ? getOffsetForColumnAndAlignment(this.props, columnIndex, align, scrollLeft, this._instanceProps, verticalScrollbarSize) : scrollLeft,
                scrollTop: rowIndex !== undefined ? getOffsetForRowAndAlignment(this.props, rowIndex, align, scrollTop, this._instanceProps, horizontalScrollbarSize) : scrollTop
            });
        };
        _proto.componentDidMount = function componentDidMount() {
            var _this$props3 = this.props, initialScrollLeft = _this$props3.initialScrollLeft, initialScrollTop = _this$props3.initialScrollTop;
            if (this._outerRef != null) {
                var outerRef = this._outerRef;
                if (typeof initialScrollLeft === 'number') {
                    outerRef.scrollLeft = initialScrollLeft;
                }
                if (typeof initialScrollTop === 'number') {
                    outerRef.scrollTop = initialScrollTop;
                }
            }
            this._callPropsCallbacks();
        };
        _proto.componentDidUpdate = function componentDidUpdate() {
            var direction = this.props.direction;
            var _this$state2 = this.state, scrollLeft = _this$state2.scrollLeft, scrollTop = _this$state2.scrollTop, scrollUpdateWasRequested = _this$state2.scrollUpdateWasRequested;
            if (scrollUpdateWasRequested && this._outerRef != null) {
                // TRICKY According to the spec, scrollLeft should be negative for RTL aligned elements.
                // This is not the case for all browsers though (e.g. Chrome reports values as positive, measured relative to the left).
                // So we need to determine which browser behavior we're dealing with, and mimic it.
                var outerRef = this._outerRef;
                if (direction === 'rtl') {
                    switch(getRTLOffsetType()){
                        case 'negative':
                            outerRef.scrollLeft = -scrollLeft;
                            break;
                        case 'positive-ascending':
                            outerRef.scrollLeft = scrollLeft;
                            break;
                        default:
                            var clientWidth = outerRef.clientWidth, scrollWidth = outerRef.scrollWidth;
                            outerRef.scrollLeft = scrollWidth - clientWidth - scrollLeft;
                            break;
                    }
                } else {
                    outerRef.scrollLeft = Math.max(0, scrollLeft);
                }
                outerRef.scrollTop = Math.max(0, scrollTop);
            }
            this._callPropsCallbacks();
        };
        _proto.componentWillUnmount = function componentWillUnmount() {
            if (this._resetIsScrollingTimeoutId !== null) {
                cancelTimeout(this._resetIsScrollingTimeoutId);
            }
        };
        _proto.render = function render() {
            var _this$props4 = this.props, children = _this$props4.children, className = _this$props4.className, columnCount = _this$props4.columnCount, direction = _this$props4.direction, height = _this$props4.height, innerRef = _this$props4.innerRef, innerElementType = _this$props4.innerElementType, innerTagName = _this$props4.innerTagName, itemData = _this$props4.itemData, _this$props4$itemKey = _this$props4.itemKey, itemKey = _this$props4$itemKey === void 0 ? defaultItemKey : _this$props4$itemKey, outerElementType = _this$props4.outerElementType, outerTagName = _this$props4.outerTagName, rowCount = _this$props4.rowCount, style = _this$props4.style, useIsScrolling = _this$props4.useIsScrolling, width = _this$props4.width;
            var isScrolling = this.state.isScrolling;
            var _this$_getHorizontalR = this._getHorizontalRangeToRender(), columnStartIndex = _this$_getHorizontalR[0], columnStopIndex = _this$_getHorizontalR[1];
            var _this$_getVerticalRan = this._getVerticalRangeToRender(), rowStartIndex = _this$_getVerticalRan[0], rowStopIndex = _this$_getVerticalRan[1];
            var items = [];
            if (columnCount > 0 && rowCount) {
                for(var _rowIndex = rowStartIndex; _rowIndex <= rowStopIndex; _rowIndex++){
                    for(var _columnIndex = columnStartIndex; _columnIndex <= columnStopIndex; _columnIndex++){
                        items.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(children, {
                            columnIndex: _columnIndex,
                            data: itemData,
                            isScrolling: useIsScrolling ? isScrolling : undefined,
                            key: itemKey({
                                columnIndex: _columnIndex,
                                data: itemData,
                                rowIndex: _rowIndex
                            }),
                            rowIndex: _rowIndex,
                            style: this._getItemStyle(_rowIndex, _columnIndex)
                        }));
                    }
                }
            } // Read this value AFTER items have been created,
            // So their actual sizes (if variable) are taken into consideration.
            var estimatedTotalHeight = getEstimatedTotalHeight(this.props, this._instanceProps);
            var estimatedTotalWidth = getEstimatedTotalWidth(this.props, this._instanceProps);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(outerElementType || outerTagName || 'div', {
                className: className,
                onScroll: this._onScroll,
                ref: this._outerRefSetter,
                style: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    position: 'relative',
                    height: height,
                    width: width,
                    overflow: 'auto',
                    WebkitOverflowScrolling: 'touch',
                    willChange: 'transform',
                    direction: direction
                }, style)
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(innerElementType || innerTagName || 'div', {
                children: items,
                ref: innerRef,
                style: {
                    height: estimatedTotalHeight,
                    pointerEvents: isScrolling ? 'none' : undefined,
                    width: estimatedTotalWidth
                }
            }));
        };
        _proto._callPropsCallbacks = function _callPropsCallbacks() {
            var _this$props5 = this.props, columnCount = _this$props5.columnCount, onItemsRendered = _this$props5.onItemsRendered, onScroll = _this$props5.onScroll, rowCount = _this$props5.rowCount;
            if (typeof onItemsRendered === 'function') {
                if (columnCount > 0 && rowCount > 0) {
                    var _this$_getHorizontalR2 = this._getHorizontalRangeToRender(), _overscanColumnStartIndex = _this$_getHorizontalR2[0], _overscanColumnStopIndex = _this$_getHorizontalR2[1], _visibleColumnStartIndex = _this$_getHorizontalR2[2], _visibleColumnStopIndex = _this$_getHorizontalR2[3];
                    var _this$_getVerticalRan2 = this._getVerticalRangeToRender(), _overscanRowStartIndex = _this$_getVerticalRan2[0], _overscanRowStopIndex = _this$_getVerticalRan2[1], _visibleRowStartIndex = _this$_getVerticalRan2[2], _visibleRowStopIndex = _this$_getVerticalRan2[3];
                    this._callOnItemsRendered(_overscanColumnStartIndex, _overscanColumnStopIndex, _overscanRowStartIndex, _overscanRowStopIndex, _visibleColumnStartIndex, _visibleColumnStopIndex, _visibleRowStartIndex, _visibleRowStopIndex);
                }
            }
            if (typeof onScroll === 'function') {
                var _this$state3 = this.state, _horizontalScrollDirection = _this$state3.horizontalScrollDirection, _scrollLeft = _this$state3.scrollLeft, _scrollTop = _this$state3.scrollTop, _scrollUpdateWasRequested = _this$state3.scrollUpdateWasRequested, _verticalScrollDirection = _this$state3.verticalScrollDirection;
                this._callOnScroll(_scrollLeft, _scrollTop, _horizontalScrollDirection, _verticalScrollDirection, _scrollUpdateWasRequested);
            }
        } // Lazily create and cache item styles while scrolling,
        ;
        _proto._getHorizontalRangeToRender = function _getHorizontalRangeToRender() {
            var _this$props6 = this.props, columnCount = _this$props6.columnCount, overscanColumnCount = _this$props6.overscanColumnCount, overscanColumnsCount = _this$props6.overscanColumnsCount, overscanCount = _this$props6.overscanCount, rowCount = _this$props6.rowCount;
            var _this$state4 = this.state, horizontalScrollDirection = _this$state4.horizontalScrollDirection, isScrolling = _this$state4.isScrolling, scrollLeft = _this$state4.scrollLeft;
            var overscanCountResolved = overscanColumnCount || overscanColumnsCount || overscanCount || 1;
            if (columnCount === 0 || rowCount === 0) {
                return [
                    0,
                    0,
                    0,
                    0
                ];
            }
            var startIndex = getColumnStartIndexForOffset(this.props, scrollLeft, this._instanceProps);
            var stopIndex = getColumnStopIndexForStartIndex(this.props, startIndex, scrollLeft, this._instanceProps); // Overscan by one item in each direction so that tab/focus works.
            // If there isn't at least one extra item, tab loops back around.
            var overscanBackward = !isScrolling || horizontalScrollDirection === 'backward' ? Math.max(1, overscanCountResolved) : 1;
            var overscanForward = !isScrolling || horizontalScrollDirection === 'forward' ? Math.max(1, overscanCountResolved) : 1;
            return [
                Math.max(0, startIndex - overscanBackward),
                Math.max(0, Math.min(columnCount - 1, stopIndex + overscanForward)),
                startIndex,
                stopIndex
            ];
        };
        _proto._getVerticalRangeToRender = function _getVerticalRangeToRender() {
            var _this$props7 = this.props, columnCount = _this$props7.columnCount, overscanCount = _this$props7.overscanCount, overscanRowCount = _this$props7.overscanRowCount, overscanRowsCount = _this$props7.overscanRowsCount, rowCount = _this$props7.rowCount;
            var _this$state5 = this.state, isScrolling = _this$state5.isScrolling, verticalScrollDirection = _this$state5.verticalScrollDirection, scrollTop = _this$state5.scrollTop;
            var overscanCountResolved = overscanRowCount || overscanRowsCount || overscanCount || 1;
            if (columnCount === 0 || rowCount === 0) {
                return [
                    0,
                    0,
                    0,
                    0
                ];
            }
            var startIndex = getRowStartIndexForOffset(this.props, scrollTop, this._instanceProps);
            var stopIndex = getRowStopIndexForStartIndex(this.props, startIndex, scrollTop, this._instanceProps); // Overscan by one item in each direction so that tab/focus works.
            // If there isn't at least one extra item, tab loops back around.
            var overscanBackward = !isScrolling || verticalScrollDirection === 'backward' ? Math.max(1, overscanCountResolved) : 1;
            var overscanForward = !isScrolling || verticalScrollDirection === 'forward' ? Math.max(1, overscanCountResolved) : 1;
            return [
                Math.max(0, startIndex - overscanBackward),
                Math.max(0, Math.min(rowCount - 1, stopIndex + overscanForward)),
                startIndex,
                stopIndex
            ];
        };
        return Grid;
    }(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PureComponent"]), _class.defaultProps = {
        direction: 'ltr',
        itemData: undefined,
        useIsScrolling: false
    }, _class;
}
var validateSharedProps = function validateSharedProps(_ref5, _ref6) {
    var children = _ref5.children, direction = _ref5.direction, height = _ref5.height, innerTagName = _ref5.innerTagName, outerTagName = _ref5.outerTagName, overscanColumnsCount = _ref5.overscanColumnsCount, overscanCount = _ref5.overscanCount, overscanRowsCount = _ref5.overscanRowsCount, width = _ref5.width;
    var instance = _ref6.instance;
    if ("TURBOPACK compile-time truthy", 1) {
        if (typeof overscanCount === 'number') {
            if (devWarningsOverscanCount && !devWarningsOverscanCount.has(instance)) {
                devWarningsOverscanCount.add(instance);
                console.warn('The overscanCount prop has been deprecated. ' + 'Please use the overscanColumnCount and overscanRowCount props instead.');
            }
        }
        if (typeof overscanColumnsCount === 'number' || typeof overscanRowsCount === 'number') {
            if (devWarningsOverscanRowsColumnsCount && !devWarningsOverscanRowsColumnsCount.has(instance)) {
                devWarningsOverscanRowsColumnsCount.add(instance);
                console.warn('The overscanColumnsCount and overscanRowsCount props have been deprecated. ' + 'Please use the overscanColumnCount and overscanRowCount props instead.');
            }
        }
        if (innerTagName != null || outerTagName != null) {
            if (devWarningsTagName && !devWarningsTagName.has(instance)) {
                devWarningsTagName.add(instance);
                console.warn('The innerTagName and outerTagName props have been deprecated. ' + 'Please use the innerElementType and outerElementType props instead.');
            }
        }
        if (children == null) {
            throw Error('An invalid "children" prop has been specified. ' + 'Value should be a React component. ' + ("\"" + (children === null ? 'null' : typeof children) + "\" was specified."));
        }
        switch(direction){
            case 'ltr':
            case 'rtl':
                break;
            default:
                throw Error('An invalid "direction" prop has been specified. ' + 'Value should be either "ltr" or "rtl". ' + ("\"" + direction + "\" was specified."));
        }
        if (typeof width !== 'number') {
            throw Error('An invalid "width" prop has been specified. ' + 'Grids must specify a number for width. ' + ("\"" + (width === null ? 'null' : typeof width) + "\" was specified."));
        }
        if (typeof height !== 'number') {
            throw Error('An invalid "height" prop has been specified. ' + 'Grids must specify a number for height. ' + ("\"" + (height === null ? 'null' : typeof height) + "\" was specified."));
        }
    }
};
var DEFAULT_ESTIMATED_ITEM_SIZE = 50;
var getEstimatedTotalHeight = function getEstimatedTotalHeight(_ref, _ref2) {
    var rowCount = _ref.rowCount;
    var rowMetadataMap = _ref2.rowMetadataMap, estimatedRowHeight = _ref2.estimatedRowHeight, lastMeasuredRowIndex = _ref2.lastMeasuredRowIndex;
    var totalSizeOfMeasuredRows = 0; // Edge case check for when the number of items decreases while a scroll is in progress.
    // https://github.com/bvaughn/react-window/pull/138
    if (lastMeasuredRowIndex >= rowCount) {
        lastMeasuredRowIndex = rowCount - 1;
    }
    if (lastMeasuredRowIndex >= 0) {
        var itemMetadata = rowMetadataMap[lastMeasuredRowIndex];
        totalSizeOfMeasuredRows = itemMetadata.offset + itemMetadata.size;
    }
    var numUnmeasuredItems = rowCount - lastMeasuredRowIndex - 1;
    var totalSizeOfUnmeasuredItems = numUnmeasuredItems * estimatedRowHeight;
    return totalSizeOfMeasuredRows + totalSizeOfUnmeasuredItems;
};
var getEstimatedTotalWidth = function getEstimatedTotalWidth(_ref3, _ref4) {
    var columnCount = _ref3.columnCount;
    var columnMetadataMap = _ref4.columnMetadataMap, estimatedColumnWidth = _ref4.estimatedColumnWidth, lastMeasuredColumnIndex = _ref4.lastMeasuredColumnIndex;
    var totalSizeOfMeasuredRows = 0; // Edge case check for when the number of items decreases while a scroll is in progress.
    // https://github.com/bvaughn/react-window/pull/138
    if (lastMeasuredColumnIndex >= columnCount) {
        lastMeasuredColumnIndex = columnCount - 1;
    }
    if (lastMeasuredColumnIndex >= 0) {
        var itemMetadata = columnMetadataMap[lastMeasuredColumnIndex];
        totalSizeOfMeasuredRows = itemMetadata.offset + itemMetadata.size;
    }
    var numUnmeasuredItems = columnCount - lastMeasuredColumnIndex - 1;
    var totalSizeOfUnmeasuredItems = numUnmeasuredItems * estimatedColumnWidth;
    return totalSizeOfMeasuredRows + totalSizeOfUnmeasuredItems;
};
var getItemMetadata = function getItemMetadata(itemType, props, index, instanceProps) {
    var itemMetadataMap, itemSize, lastMeasuredIndex;
    if (itemType === 'column') {
        itemMetadataMap = instanceProps.columnMetadataMap;
        itemSize = props.columnWidth;
        lastMeasuredIndex = instanceProps.lastMeasuredColumnIndex;
    } else {
        itemMetadataMap = instanceProps.rowMetadataMap;
        itemSize = props.rowHeight;
        lastMeasuredIndex = instanceProps.lastMeasuredRowIndex;
    }
    if (index > lastMeasuredIndex) {
        var offset = 0;
        if (lastMeasuredIndex >= 0) {
            var itemMetadata = itemMetadataMap[lastMeasuredIndex];
            offset = itemMetadata.offset + itemMetadata.size;
        }
        for(var i = lastMeasuredIndex + 1; i <= index; i++){
            var size = itemSize(i);
            itemMetadataMap[i] = {
                offset: offset,
                size: size
            };
            offset += size;
        }
        if (itemType === 'column') {
            instanceProps.lastMeasuredColumnIndex = index;
        } else {
            instanceProps.lastMeasuredRowIndex = index;
        }
    }
    return itemMetadataMap[index];
};
var findNearestItem = function findNearestItem(itemType, props, instanceProps, offset) {
    var itemMetadataMap, lastMeasuredIndex;
    if (itemType === 'column') {
        itemMetadataMap = instanceProps.columnMetadataMap;
        lastMeasuredIndex = instanceProps.lastMeasuredColumnIndex;
    } else {
        itemMetadataMap = instanceProps.rowMetadataMap;
        lastMeasuredIndex = instanceProps.lastMeasuredRowIndex;
    }
    var lastMeasuredItemOffset = lastMeasuredIndex > 0 ? itemMetadataMap[lastMeasuredIndex].offset : 0;
    if (lastMeasuredItemOffset >= offset) {
        // If we've already measured items within this range just use a binary search as it's faster.
        return findNearestItemBinarySearch(itemType, props, instanceProps, lastMeasuredIndex, 0, offset);
    } else {
        // If we haven't yet measured this high, fallback to an exponential search with an inner binary search.
        // The exponential search avoids pre-computing sizes for the full set of items as a binary search would.
        // The overall complexity for this approach is O(log n).
        return findNearestItemExponentialSearch(itemType, props, instanceProps, Math.max(0, lastMeasuredIndex), offset);
    }
};
var findNearestItemBinarySearch = function findNearestItemBinarySearch(itemType, props, instanceProps, high, low, offset) {
    while(low <= high){
        var middle = low + Math.floor((high - low) / 2);
        var currentOffset = getItemMetadata(itemType, props, middle, instanceProps).offset;
        if (currentOffset === offset) {
            return middle;
        } else if (currentOffset < offset) {
            low = middle + 1;
        } else if (currentOffset > offset) {
            high = middle - 1;
        }
    }
    if (low > 0) {
        return low - 1;
    } else {
        return 0;
    }
};
var findNearestItemExponentialSearch = function findNearestItemExponentialSearch(itemType, props, instanceProps, index, offset) {
    var itemCount = itemType === 'column' ? props.columnCount : props.rowCount;
    var interval = 1;
    while(index < itemCount && getItemMetadata(itemType, props, index, instanceProps).offset < offset){
        index += interval;
        interval *= 2;
    }
    return findNearestItemBinarySearch(itemType, props, instanceProps, Math.min(index, itemCount - 1), Math.floor(index / 2), offset);
};
var getOffsetForIndexAndAlignment = function getOffsetForIndexAndAlignment(itemType, props, index, align, scrollOffset, instanceProps, scrollbarSize) {
    var size = itemType === 'column' ? props.width : props.height;
    var itemMetadata = getItemMetadata(itemType, props, index, instanceProps); // Get estimated total size after ItemMetadata is computed,
    // To ensure it reflects actual measurements instead of just estimates.
    var estimatedTotalSize = itemType === 'column' ? getEstimatedTotalWidth(props, instanceProps) : getEstimatedTotalHeight(props, instanceProps);
    var maxOffset = Math.max(0, Math.min(estimatedTotalSize - size, itemMetadata.offset));
    var minOffset = Math.max(0, itemMetadata.offset - size + scrollbarSize + itemMetadata.size);
    if (align === 'smart') {
        if (scrollOffset >= minOffset - size && scrollOffset <= maxOffset + size) {
            align = 'auto';
        } else {
            align = 'center';
        }
    }
    switch(align){
        case 'start':
            return maxOffset;
        case 'end':
            return minOffset;
        case 'center':
            return Math.round(minOffset + (maxOffset - minOffset) / 2);
        case 'auto':
        default:
            if (scrollOffset >= minOffset && scrollOffset <= maxOffset) {
                return scrollOffset;
            } else if (minOffset > maxOffset) {
                // Because we only take into account the scrollbar size when calculating minOffset
                // this value can be larger than maxOffset when at the end of the list
                return minOffset;
            } else if (scrollOffset < minOffset) {
                return minOffset;
            } else {
                return maxOffset;
            }
    }
};
var VariableSizeGrid = /*#__PURE__*/ createGridComponent({
    getColumnOffset: function getColumnOffset(props, index, instanceProps) {
        return getItemMetadata('column', props, index, instanceProps).offset;
    },
    getColumnStartIndexForOffset: function getColumnStartIndexForOffset(props, scrollLeft, instanceProps) {
        return findNearestItem('column', props, instanceProps, scrollLeft);
    },
    getColumnStopIndexForStartIndex: function getColumnStopIndexForStartIndex(props, startIndex, scrollLeft, instanceProps) {
        var columnCount = props.columnCount, width = props.width;
        var itemMetadata = getItemMetadata('column', props, startIndex, instanceProps);
        var maxOffset = scrollLeft + width;
        var offset = itemMetadata.offset + itemMetadata.size;
        var stopIndex = startIndex;
        while(stopIndex < columnCount - 1 && offset < maxOffset){
            stopIndex++;
            offset += getItemMetadata('column', props, stopIndex, instanceProps).size;
        }
        return stopIndex;
    },
    getColumnWidth: function getColumnWidth(props, index, instanceProps) {
        return instanceProps.columnMetadataMap[index].size;
    },
    getEstimatedTotalHeight: getEstimatedTotalHeight,
    getEstimatedTotalWidth: getEstimatedTotalWidth,
    getOffsetForColumnAndAlignment: function getOffsetForColumnAndAlignment(props, index, align, scrollOffset, instanceProps, scrollbarSize) {
        return getOffsetForIndexAndAlignment('column', props, index, align, scrollOffset, instanceProps, scrollbarSize);
    },
    getOffsetForRowAndAlignment: function getOffsetForRowAndAlignment(props, index, align, scrollOffset, instanceProps, scrollbarSize) {
        return getOffsetForIndexAndAlignment('row', props, index, align, scrollOffset, instanceProps, scrollbarSize);
    },
    getRowOffset: function getRowOffset(props, index, instanceProps) {
        return getItemMetadata('row', props, index, instanceProps).offset;
    },
    getRowHeight: function getRowHeight(props, index, instanceProps) {
        return instanceProps.rowMetadataMap[index].size;
    },
    getRowStartIndexForOffset: function getRowStartIndexForOffset(props, scrollTop, instanceProps) {
        return findNearestItem('row', props, instanceProps, scrollTop);
    },
    getRowStopIndexForStartIndex: function getRowStopIndexForStartIndex(props, startIndex, scrollTop, instanceProps) {
        var rowCount = props.rowCount, height = props.height;
        var itemMetadata = getItemMetadata('row', props, startIndex, instanceProps);
        var maxOffset = scrollTop + height;
        var offset = itemMetadata.offset + itemMetadata.size;
        var stopIndex = startIndex;
        while(stopIndex < rowCount - 1 && offset < maxOffset){
            stopIndex++;
            offset += getItemMetadata('row', props, stopIndex, instanceProps).size;
        }
        return stopIndex;
    },
    initInstanceProps: function initInstanceProps(props, instance) {
        var _ref5 = props, estimatedColumnWidth = _ref5.estimatedColumnWidth, estimatedRowHeight = _ref5.estimatedRowHeight;
        var instanceProps = {
            columnMetadataMap: {},
            estimatedColumnWidth: estimatedColumnWidth || DEFAULT_ESTIMATED_ITEM_SIZE,
            estimatedRowHeight: estimatedRowHeight || DEFAULT_ESTIMATED_ITEM_SIZE,
            lastMeasuredColumnIndex: -1,
            lastMeasuredRowIndex: -1,
            rowMetadataMap: {}
        };
        instance.resetAfterColumnIndex = function(columnIndex, shouldForceUpdate) {
            if (shouldForceUpdate === void 0) {
                shouldForceUpdate = true;
            }
            instance.resetAfterIndices({
                columnIndex: columnIndex,
                shouldForceUpdate: shouldForceUpdate
            });
        };
        instance.resetAfterRowIndex = function(rowIndex, shouldForceUpdate) {
            if (shouldForceUpdate === void 0) {
                shouldForceUpdate = true;
            }
            instance.resetAfterIndices({
                rowIndex: rowIndex,
                shouldForceUpdate: shouldForceUpdate
            });
        };
        instance.resetAfterIndices = function(_ref6) {
            var columnIndex = _ref6.columnIndex, rowIndex = _ref6.rowIndex, _ref6$shouldForceUpda = _ref6.shouldForceUpdate, shouldForceUpdate = _ref6$shouldForceUpda === void 0 ? true : _ref6$shouldForceUpda;
            if (typeof columnIndex === 'number') {
                instanceProps.lastMeasuredColumnIndex = Math.min(instanceProps.lastMeasuredColumnIndex, columnIndex - 1);
            }
            if (typeof rowIndex === 'number') {
                instanceProps.lastMeasuredRowIndex = Math.min(instanceProps.lastMeasuredRowIndex, rowIndex - 1);
            } // We could potentially optimize further by only evicting styles after this index,
            // But since styles are only cached while scrolling is in progress-
            // It seems an unnecessary optimization.
            // It's unlikely that resetAfterIndex() will be called while a user is scrolling.
            instance._getItemStyleCache(-1);
            if (shouldForceUpdate) {
                instance.forceUpdate();
            }
        };
        return instanceProps;
    },
    shouldResetStyleCacheOnItemSizeChange: false,
    validateProps: function validateProps(_ref7) {
        var columnWidth = _ref7.columnWidth, rowHeight = _ref7.rowHeight;
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof columnWidth !== 'function') {
                throw Error('An invalid "columnWidth" prop has been specified. ' + 'Value should be a function. ' + ("\"" + (columnWidth === null ? 'null' : typeof columnWidth) + "\" was specified."));
            } else if (typeof rowHeight !== 'function') {
                throw Error('An invalid "rowHeight" prop has been specified. ' + 'Value should be a function. ' + ("\"" + (rowHeight === null ? 'null' : typeof rowHeight) + "\" was specified."));
            }
        }
    }
});
var IS_SCROLLING_DEBOUNCE_INTERVAL$1 = 150;
var defaultItemKey$1 = function defaultItemKey(index, data) {
    return index;
}; // In DEV mode, this Set helps us only log a warning once per component instance.
// This avoids spamming the console every time a render happens.
var devWarningsDirection = null;
var devWarningsTagName$1 = null;
if ("TURBOPACK compile-time truthy", 1) {
    if (typeof window !== 'undefined' && typeof window.WeakSet !== 'undefined') {
        devWarningsDirection = /*#__PURE__*/ new WeakSet();
        devWarningsTagName$1 = /*#__PURE__*/ new WeakSet();
    }
}
function createListComponent(_ref) {
    var _class;
    var getItemOffset = _ref.getItemOffset, getEstimatedTotalSize = _ref.getEstimatedTotalSize, getItemSize = _ref.getItemSize, getOffsetForIndexAndAlignment = _ref.getOffsetForIndexAndAlignment, getStartIndexForOffset = _ref.getStartIndexForOffset, getStopIndexForStartIndex = _ref.getStopIndexForStartIndex, initInstanceProps = _ref.initInstanceProps, shouldResetStyleCacheOnItemSizeChange = _ref.shouldResetStyleCacheOnItemSizeChange, validateProps = _ref.validateProps;
    return _class = /*#__PURE__*/ function(_PureComponent) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$inheritsLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(List, _PureComponent);
        // Always use explicit constructor for React components.
        // It produces less code after transpilation. (#26)
        // eslint-disable-next-line no-useless-constructor
        function List(props) {
            var _this;
            _this = _PureComponent.call(this, props) || this;
            _this._instanceProps = initInstanceProps(_this.props, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$assertThisInitialized$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this));
            _this._outerRef = void 0;
            _this._resetIsScrollingTimeoutId = null;
            _this.state = {
                instance: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$assertThisInitialized$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_this),
                isScrolling: false,
                scrollDirection: 'forward',
                scrollOffset: typeof _this.props.initialScrollOffset === 'number' ? _this.props.initialScrollOffset : 0,
                scrollUpdateWasRequested: false
            };
            _this._callOnItemsRendered = void 0;
            _this._callOnItemsRendered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(overscanStartIndex, overscanStopIndex, visibleStartIndex, visibleStopIndex) {
                return _this.props.onItemsRendered({
                    overscanStartIndex: overscanStartIndex,
                    overscanStopIndex: overscanStopIndex,
                    visibleStartIndex: visibleStartIndex,
                    visibleStopIndex: visibleStopIndex
                });
            });
            _this._callOnScroll = void 0;
            _this._callOnScroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(scrollDirection, scrollOffset, scrollUpdateWasRequested) {
                return _this.props.onScroll({
                    scrollDirection: scrollDirection,
                    scrollOffset: scrollOffset,
                    scrollUpdateWasRequested: scrollUpdateWasRequested
                });
            });
            _this._getItemStyle = void 0;
            _this._getItemStyle = function(index) {
                var _this$props = _this.props, direction = _this$props.direction, itemSize = _this$props.itemSize, layout = _this$props.layout;
                var itemStyleCache = _this._getItemStyleCache(shouldResetStyleCacheOnItemSizeChange && itemSize, shouldResetStyleCacheOnItemSizeChange && layout, shouldResetStyleCacheOnItemSizeChange && direction);
                var style;
                if (itemStyleCache.hasOwnProperty(index)) {
                    style = itemStyleCache[index];
                } else {
                    var _offset = getItemOffset(_this.props, index, _this._instanceProps);
                    var size = getItemSize(_this.props, index, _this._instanceProps); // TODO Deprecate direction "horizontal"
                    var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
                    var isRtl = direction === 'rtl';
                    var offsetHorizontal = isHorizontal ? _offset : 0;
                    itemStyleCache[index] = style = {
                        position: 'absolute',
                        left: isRtl ? undefined : offsetHorizontal,
                        right: isRtl ? offsetHorizontal : undefined,
                        top: !isHorizontal ? _offset : 0,
                        height: !isHorizontal ? size : '100%',
                        width: isHorizontal ? size : '100%'
                    };
                }
                return style;
            };
            _this._getItemStyleCache = void 0;
            _this._getItemStyleCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$memoize$2d$one$40$5$2e$2$2e$1$2f$node_modules$2f$memoize$2d$one$2f$dist$2f$memoize$2d$one$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(_, __, ___) {
                return {};
            });
            _this._onScrollHorizontal = function(event) {
                var _event$currentTarget = event.currentTarget, clientWidth = _event$currentTarget.clientWidth, scrollLeft = _event$currentTarget.scrollLeft, scrollWidth = _event$currentTarget.scrollWidth;
                _this.setState(function(prevState) {
                    if (prevState.scrollOffset === scrollLeft) {
                        // Scroll position may have been updated by cDM/cDU,
                        // In which case we don't need to trigger another render,
                        // And we don't want to update state.isScrolling.
                        return null;
                    }
                    var direction = _this.props.direction;
                    var scrollOffset = scrollLeft;
                    if (direction === 'rtl') {
                        // TRICKY According to the spec, scrollLeft should be negative for RTL aligned elements.
                        // This is not the case for all browsers though (e.g. Chrome reports values as positive, measured relative to the left).
                        // It's also easier for this component if we convert offsets to the same format as they would be in for ltr.
                        // So the simplest solution is to determine which browser behavior we're dealing with, and convert based on it.
                        switch(getRTLOffsetType()){
                            case 'negative':
                                scrollOffset = -scrollLeft;
                                break;
                            case 'positive-descending':
                                scrollOffset = scrollWidth - clientWidth - scrollLeft;
                                break;
                        }
                    } // Prevent Safari's elastic scrolling from causing visual shaking when scrolling past bounds.
                    scrollOffset = Math.max(0, Math.min(scrollOffset, scrollWidth - clientWidth));
                    return {
                        isScrolling: true,
                        scrollDirection: prevState.scrollOffset < scrollOffset ? 'forward' : 'backward',
                        scrollOffset: scrollOffset,
                        scrollUpdateWasRequested: false
                    };
                }, _this._resetIsScrollingDebounced);
            };
            _this._onScrollVertical = function(event) {
                var _event$currentTarget2 = event.currentTarget, clientHeight = _event$currentTarget2.clientHeight, scrollHeight = _event$currentTarget2.scrollHeight, scrollTop = _event$currentTarget2.scrollTop;
                _this.setState(function(prevState) {
                    if (prevState.scrollOffset === scrollTop) {
                        // Scroll position may have been updated by cDM/cDU,
                        // In which case we don't need to trigger another render,
                        // And we don't want to update state.isScrolling.
                        return null;
                    } // Prevent Safari's elastic scrolling from causing visual shaking when scrolling past bounds.
                    var scrollOffset = Math.max(0, Math.min(scrollTop, scrollHeight - clientHeight));
                    return {
                        isScrolling: true,
                        scrollDirection: prevState.scrollOffset < scrollOffset ? 'forward' : 'backward',
                        scrollOffset: scrollOffset,
                        scrollUpdateWasRequested: false
                    };
                }, _this._resetIsScrollingDebounced);
            };
            _this._outerRefSetter = function(ref) {
                var outerRef = _this.props.outerRef;
                _this._outerRef = ref;
                if (typeof outerRef === 'function') {
                    outerRef(ref);
                } else if (outerRef != null && typeof outerRef === 'object' && outerRef.hasOwnProperty('current')) {
                    outerRef.current = ref;
                }
            };
            _this._resetIsScrollingDebounced = function() {
                if (_this._resetIsScrollingTimeoutId !== null) {
                    cancelTimeout(_this._resetIsScrollingTimeoutId);
                }
                _this._resetIsScrollingTimeoutId = requestTimeout(_this._resetIsScrolling, IS_SCROLLING_DEBOUNCE_INTERVAL$1);
            };
            _this._resetIsScrolling = function() {
                _this._resetIsScrollingTimeoutId = null;
                _this.setState({
                    isScrolling: false
                }, function() {
                    // Clear style cache after state update has been committed.
                    // This way we don't break pure sCU for items that don't use isScrolling param.
                    _this._getItemStyleCache(-1, null);
                });
            };
            return _this;
        }
        List.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
            validateSharedProps$1(nextProps, prevState);
            validateProps(nextProps);
            return null;
        };
        var _proto = List.prototype;
        _proto.scrollTo = function scrollTo(scrollOffset) {
            scrollOffset = Math.max(0, scrollOffset);
            this.setState(function(prevState) {
                if (prevState.scrollOffset === scrollOffset) {
                    return null;
                }
                return {
                    scrollDirection: prevState.scrollOffset < scrollOffset ? 'forward' : 'backward',
                    scrollOffset: scrollOffset,
                    scrollUpdateWasRequested: true
                };
            }, this._resetIsScrollingDebounced);
        };
        _proto.scrollToItem = function scrollToItem(index, align) {
            if (align === void 0) {
                align = 'auto';
            }
            var _this$props2 = this.props, itemCount = _this$props2.itemCount, layout = _this$props2.layout;
            var scrollOffset = this.state.scrollOffset;
            index = Math.max(0, Math.min(index, itemCount - 1)); // The scrollbar size should be considered when scrolling an item into view, to ensure it's fully visible.
            // But we only need to account for its size when it's actually visible.
            // This is an edge case for lists; normally they only scroll in the dominant direction.
            var scrollbarSize = 0;
            if (this._outerRef) {
                var outerRef = this._outerRef;
                if (layout === 'vertical') {
                    scrollbarSize = outerRef.scrollWidth > outerRef.clientWidth ? getScrollbarSize() : 0;
                } else {
                    scrollbarSize = outerRef.scrollHeight > outerRef.clientHeight ? getScrollbarSize() : 0;
                }
            }
            this.scrollTo(getOffsetForIndexAndAlignment(this.props, index, align, scrollOffset, this._instanceProps, scrollbarSize));
        };
        _proto.componentDidMount = function componentDidMount() {
            var _this$props3 = this.props, direction = _this$props3.direction, initialScrollOffset = _this$props3.initialScrollOffset, layout = _this$props3.layout;
            if (typeof initialScrollOffset === 'number' && this._outerRef != null) {
                var outerRef = this._outerRef; // TODO Deprecate direction "horizontal"
                if (direction === 'horizontal' || layout === 'horizontal') {
                    outerRef.scrollLeft = initialScrollOffset;
                } else {
                    outerRef.scrollTop = initialScrollOffset;
                }
            }
            this._callPropsCallbacks();
        };
        _proto.componentDidUpdate = function componentDidUpdate() {
            var _this$props4 = this.props, direction = _this$props4.direction, layout = _this$props4.layout;
            var _this$state = this.state, scrollOffset = _this$state.scrollOffset, scrollUpdateWasRequested = _this$state.scrollUpdateWasRequested;
            if (scrollUpdateWasRequested && this._outerRef != null) {
                var outerRef = this._outerRef; // TODO Deprecate direction "horizontal"
                if (direction === 'horizontal' || layout === 'horizontal') {
                    if (direction === 'rtl') {
                        // TRICKY According to the spec, scrollLeft should be negative for RTL aligned elements.
                        // This is not the case for all browsers though (e.g. Chrome reports values as positive, measured relative to the left).
                        // So we need to determine which browser behavior we're dealing with, and mimic it.
                        switch(getRTLOffsetType()){
                            case 'negative':
                                outerRef.scrollLeft = -scrollOffset;
                                break;
                            case 'positive-ascending':
                                outerRef.scrollLeft = scrollOffset;
                                break;
                            default:
                                var clientWidth = outerRef.clientWidth, scrollWidth = outerRef.scrollWidth;
                                outerRef.scrollLeft = scrollWidth - clientWidth - scrollOffset;
                                break;
                        }
                    } else {
                        outerRef.scrollLeft = scrollOffset;
                    }
                } else {
                    outerRef.scrollTop = scrollOffset;
                }
            }
            this._callPropsCallbacks();
        };
        _proto.componentWillUnmount = function componentWillUnmount() {
            if (this._resetIsScrollingTimeoutId !== null) {
                cancelTimeout(this._resetIsScrollingTimeoutId);
            }
        };
        _proto.render = function render() {
            var _this$props5 = this.props, children = _this$props5.children, className = _this$props5.className, direction = _this$props5.direction, height = _this$props5.height, innerRef = _this$props5.innerRef, innerElementType = _this$props5.innerElementType, innerTagName = _this$props5.innerTagName, itemCount = _this$props5.itemCount, itemData = _this$props5.itemData, _this$props5$itemKey = _this$props5.itemKey, itemKey = _this$props5$itemKey === void 0 ? defaultItemKey$1 : _this$props5$itemKey, layout = _this$props5.layout, outerElementType = _this$props5.outerElementType, outerTagName = _this$props5.outerTagName, style = _this$props5.style, useIsScrolling = _this$props5.useIsScrolling, width = _this$props5.width;
            var isScrolling = this.state.isScrolling; // TODO Deprecate direction "horizontal"
            var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
            var onScroll = isHorizontal ? this._onScrollHorizontal : this._onScrollVertical;
            var _this$_getRangeToRend = this._getRangeToRender(), startIndex = _this$_getRangeToRend[0], stopIndex = _this$_getRangeToRend[1];
            var items = [];
            if (itemCount > 0) {
                for(var _index = startIndex; _index <= stopIndex; _index++){
                    items.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(children, {
                        data: itemData,
                        key: itemKey(_index, itemData),
                        index: _index,
                        isScrolling: useIsScrolling ? isScrolling : undefined,
                        style: this._getItemStyle(_index)
                    }));
                }
            } // Read this value AFTER items have been created,
            // So their actual sizes (if variable) are taken into consideration.
            var estimatedTotalSize = getEstimatedTotalSize(this.props, this._instanceProps);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(outerElementType || outerTagName || 'div', {
                className: className,
                onScroll: onScroll,
                ref: this._outerRefSetter,
                style: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    position: 'relative',
                    height: height,
                    width: width,
                    overflow: 'auto',
                    WebkitOverflowScrolling: 'touch',
                    willChange: 'transform',
                    direction: direction
                }, style)
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(innerElementType || innerTagName || 'div', {
                children: items,
                ref: innerRef,
                style: {
                    height: isHorizontal ? '100%' : estimatedTotalSize,
                    pointerEvents: isScrolling ? 'none' : undefined,
                    width: isHorizontal ? estimatedTotalSize : '100%'
                }
            }));
        };
        _proto._callPropsCallbacks = function _callPropsCallbacks() {
            if (typeof this.props.onItemsRendered === 'function') {
                var itemCount = this.props.itemCount;
                if (itemCount > 0) {
                    var _this$_getRangeToRend2 = this._getRangeToRender(), _overscanStartIndex = _this$_getRangeToRend2[0], _overscanStopIndex = _this$_getRangeToRend2[1], _visibleStartIndex = _this$_getRangeToRend2[2], _visibleStopIndex = _this$_getRangeToRend2[3];
                    this._callOnItemsRendered(_overscanStartIndex, _overscanStopIndex, _visibleStartIndex, _visibleStopIndex);
                }
            }
            if (typeof this.props.onScroll === 'function') {
                var _this$state2 = this.state, _scrollDirection = _this$state2.scrollDirection, _scrollOffset = _this$state2.scrollOffset, _scrollUpdateWasRequested = _this$state2.scrollUpdateWasRequested;
                this._callOnScroll(_scrollDirection, _scrollOffset, _scrollUpdateWasRequested);
            }
        } // Lazily create and cache item styles while scrolling,
        ;
        _proto._getRangeToRender = function _getRangeToRender() {
            var _this$props6 = this.props, itemCount = _this$props6.itemCount, overscanCount = _this$props6.overscanCount;
            var _this$state3 = this.state, isScrolling = _this$state3.isScrolling, scrollDirection = _this$state3.scrollDirection, scrollOffset = _this$state3.scrollOffset;
            if (itemCount === 0) {
                return [
                    0,
                    0,
                    0,
                    0
                ];
            }
            var startIndex = getStartIndexForOffset(this.props, scrollOffset, this._instanceProps);
            var stopIndex = getStopIndexForStartIndex(this.props, startIndex, scrollOffset, this._instanceProps); // Overscan by one item in each direction so that tab/focus works.
            // If there isn't at least one extra item, tab loops back around.
            var overscanBackward = !isScrolling || scrollDirection === 'backward' ? Math.max(1, overscanCount) : 1;
            var overscanForward = !isScrolling || scrollDirection === 'forward' ? Math.max(1, overscanCount) : 1;
            return [
                Math.max(0, startIndex - overscanBackward),
                Math.max(0, Math.min(itemCount - 1, stopIndex + overscanForward)),
                startIndex,
                stopIndex
            ];
        };
        return List;
    }(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PureComponent"]), _class.defaultProps = {
        direction: 'ltr',
        itemData: undefined,
        layout: 'vertical',
        overscanCount: 2,
        useIsScrolling: false
    }, _class;
} // NOTE: I considered further wrapping individual items with a pure ListItem component.
// This would avoid ever calling the render function for the same index more than once,
// But it would also add the overhead of a lot of components/fibers.
// I assume people already do this (render function returning a class component),
// So my doing it would just unnecessarily double the wrappers.
var validateSharedProps$1 = function validateSharedProps(_ref2, _ref3) {
    var children = _ref2.children, direction = _ref2.direction, height = _ref2.height, layout = _ref2.layout, innerTagName = _ref2.innerTagName, outerTagName = _ref2.outerTagName, width = _ref2.width;
    var instance = _ref3.instance;
    if ("TURBOPACK compile-time truthy", 1) {
        if (innerTagName != null || outerTagName != null) {
            if (devWarningsTagName$1 && !devWarningsTagName$1.has(instance)) {
                devWarningsTagName$1.add(instance);
                console.warn('The innerTagName and outerTagName props have been deprecated. ' + 'Please use the innerElementType and outerElementType props instead.');
            }
        } // TODO Deprecate direction "horizontal"
        var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
        switch(direction){
            case 'horizontal':
            case 'vertical':
                if (devWarningsDirection && !devWarningsDirection.has(instance)) {
                    devWarningsDirection.add(instance);
                    console.warn('The direction prop should be either "ltr" (default) or "rtl". ' + 'Please use the layout prop to specify "vertical" (default) or "horizontal" orientation.');
                }
                break;
            case 'ltr':
            case 'rtl':
                break;
            default:
                throw Error('An invalid "direction" prop has been specified. ' + 'Value should be either "ltr" or "rtl". ' + ("\"" + direction + "\" was specified."));
        }
        switch(layout){
            case 'horizontal':
            case 'vertical':
                break;
            default:
                throw Error('An invalid "layout" prop has been specified. ' + 'Value should be either "horizontal" or "vertical". ' + ("\"" + layout + "\" was specified."));
        }
        if (children == null) {
            throw Error('An invalid "children" prop has been specified. ' + 'Value should be a React component. ' + ("\"" + (children === null ? 'null' : typeof children) + "\" was specified."));
        }
        if (isHorizontal && typeof width !== 'number') {
            throw Error('An invalid "width" prop has been specified. ' + 'Horizontal lists must specify a number for width. ' + ("\"" + (width === null ? 'null' : typeof width) + "\" was specified."));
        } else if (!isHorizontal && typeof height !== 'number') {
            throw Error('An invalid "height" prop has been specified. ' + 'Vertical lists must specify a number for height. ' + ("\"" + (height === null ? 'null' : typeof height) + "\" was specified."));
        }
    }
};
var DEFAULT_ESTIMATED_ITEM_SIZE$1 = 50;
var getItemMetadata$1 = function getItemMetadata(props, index, instanceProps) {
    var _ref = props, itemSize = _ref.itemSize;
    var itemMetadataMap = instanceProps.itemMetadataMap, lastMeasuredIndex = instanceProps.lastMeasuredIndex;
    if (index > lastMeasuredIndex) {
        var offset = 0;
        if (lastMeasuredIndex >= 0) {
            var itemMetadata = itemMetadataMap[lastMeasuredIndex];
            offset = itemMetadata.offset + itemMetadata.size;
        }
        for(var i = lastMeasuredIndex + 1; i <= index; i++){
            var size = itemSize(i);
            itemMetadataMap[i] = {
                offset: offset,
                size: size
            };
            offset += size;
        }
        instanceProps.lastMeasuredIndex = index;
    }
    return itemMetadataMap[index];
};
var findNearestItem$1 = function findNearestItem(props, instanceProps, offset) {
    var itemMetadataMap = instanceProps.itemMetadataMap, lastMeasuredIndex = instanceProps.lastMeasuredIndex;
    var lastMeasuredItemOffset = lastMeasuredIndex > 0 ? itemMetadataMap[lastMeasuredIndex].offset : 0;
    if (lastMeasuredItemOffset >= offset) {
        // If we've already measured items within this range just use a binary search as it's faster.
        return findNearestItemBinarySearch$1(props, instanceProps, lastMeasuredIndex, 0, offset);
    } else {
        // If we haven't yet measured this high, fallback to an exponential search with an inner binary search.
        // The exponential search avoids pre-computing sizes for the full set of items as a binary search would.
        // The overall complexity for this approach is O(log n).
        return findNearestItemExponentialSearch$1(props, instanceProps, Math.max(0, lastMeasuredIndex), offset);
    }
};
var findNearestItemBinarySearch$1 = function findNearestItemBinarySearch(props, instanceProps, high, low, offset) {
    while(low <= high){
        var middle = low + Math.floor((high - low) / 2);
        var currentOffset = getItemMetadata$1(props, middle, instanceProps).offset;
        if (currentOffset === offset) {
            return middle;
        } else if (currentOffset < offset) {
            low = middle + 1;
        } else if (currentOffset > offset) {
            high = middle - 1;
        }
    }
    if (low > 0) {
        return low - 1;
    } else {
        return 0;
    }
};
var findNearestItemExponentialSearch$1 = function findNearestItemExponentialSearch(props, instanceProps, index, offset) {
    var itemCount = props.itemCount;
    var interval = 1;
    while(index < itemCount && getItemMetadata$1(props, index, instanceProps).offset < offset){
        index += interval;
        interval *= 2;
    }
    return findNearestItemBinarySearch$1(props, instanceProps, Math.min(index, itemCount - 1), Math.floor(index / 2), offset);
};
var getEstimatedTotalSize = function getEstimatedTotalSize(_ref2, _ref3) {
    var itemCount = _ref2.itemCount;
    var itemMetadataMap = _ref3.itemMetadataMap, estimatedItemSize = _ref3.estimatedItemSize, lastMeasuredIndex = _ref3.lastMeasuredIndex;
    var totalSizeOfMeasuredItems = 0; // Edge case check for when the number of items decreases while a scroll is in progress.
    // https://github.com/bvaughn/react-window/pull/138
    if (lastMeasuredIndex >= itemCount) {
        lastMeasuredIndex = itemCount - 1;
    }
    if (lastMeasuredIndex >= 0) {
        var itemMetadata = itemMetadataMap[lastMeasuredIndex];
        totalSizeOfMeasuredItems = itemMetadata.offset + itemMetadata.size;
    }
    var numUnmeasuredItems = itemCount - lastMeasuredIndex - 1;
    var totalSizeOfUnmeasuredItems = numUnmeasuredItems * estimatedItemSize;
    return totalSizeOfMeasuredItems + totalSizeOfUnmeasuredItems;
};
var VariableSizeList = /*#__PURE__*/ createListComponent({
    getItemOffset: function getItemOffset(props, index, instanceProps) {
        return getItemMetadata$1(props, index, instanceProps).offset;
    },
    getItemSize: function getItemSize(props, index, instanceProps) {
        return instanceProps.itemMetadataMap[index].size;
    },
    getEstimatedTotalSize: getEstimatedTotalSize,
    getOffsetForIndexAndAlignment: function getOffsetForIndexAndAlignment(props, index, align, scrollOffset, instanceProps, scrollbarSize) {
        var direction = props.direction, height = props.height, layout = props.layout, width = props.width; // TODO Deprecate direction "horizontal"
        var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
        var size = isHorizontal ? width : height;
        var itemMetadata = getItemMetadata$1(props, index, instanceProps); // Get estimated total size after ItemMetadata is computed,
        // To ensure it reflects actual measurements instead of just estimates.
        var estimatedTotalSize = getEstimatedTotalSize(props, instanceProps);
        var maxOffset = Math.max(0, Math.min(estimatedTotalSize - size, itemMetadata.offset));
        var minOffset = Math.max(0, itemMetadata.offset - size + itemMetadata.size + scrollbarSize);
        if (align === 'smart') {
            if (scrollOffset >= minOffset - size && scrollOffset <= maxOffset + size) {
                align = 'auto';
            } else {
                align = 'center';
            }
        }
        switch(align){
            case 'start':
                return maxOffset;
            case 'end':
                return minOffset;
            case 'center':
                return Math.round(minOffset + (maxOffset - minOffset) / 2);
            case 'auto':
            default:
                if (scrollOffset >= minOffset && scrollOffset <= maxOffset) {
                    return scrollOffset;
                } else if (scrollOffset < minOffset) {
                    return minOffset;
                } else {
                    return maxOffset;
                }
        }
    },
    getStartIndexForOffset: function getStartIndexForOffset(props, offset, instanceProps) {
        return findNearestItem$1(props, instanceProps, offset);
    },
    getStopIndexForStartIndex: function getStopIndexForStartIndex(props, startIndex, scrollOffset, instanceProps) {
        var direction = props.direction, height = props.height, itemCount = props.itemCount, layout = props.layout, width = props.width; // TODO Deprecate direction "horizontal"
        var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
        var size = isHorizontal ? width : height;
        var itemMetadata = getItemMetadata$1(props, startIndex, instanceProps);
        var maxOffset = scrollOffset + size;
        var offset = itemMetadata.offset + itemMetadata.size;
        var stopIndex = startIndex;
        while(stopIndex < itemCount - 1 && offset < maxOffset){
            stopIndex++;
            offset += getItemMetadata$1(props, stopIndex, instanceProps).size;
        }
        return stopIndex;
    },
    initInstanceProps: function initInstanceProps(props, instance) {
        var _ref4 = props, estimatedItemSize = _ref4.estimatedItemSize;
        var instanceProps = {
            itemMetadataMap: {},
            estimatedItemSize: estimatedItemSize || DEFAULT_ESTIMATED_ITEM_SIZE$1,
            lastMeasuredIndex: -1
        };
        instance.resetAfterIndex = function(index, shouldForceUpdate) {
            if (shouldForceUpdate === void 0) {
                shouldForceUpdate = true;
            }
            instanceProps.lastMeasuredIndex = Math.min(instanceProps.lastMeasuredIndex, index - 1); // We could potentially optimize further by only evicting styles after this index,
            // But since styles are only cached while scrolling is in progress-
            // It seems an unnecessary optimization.
            // It's unlikely that resetAfterIndex() will be called while a user is scrolling.
            instance._getItemStyleCache(-1);
            if (shouldForceUpdate) {
                instance.forceUpdate();
            }
        };
        return instanceProps;
    },
    shouldResetStyleCacheOnItemSizeChange: false,
    validateProps: function validateProps(_ref5) {
        var itemSize = _ref5.itemSize;
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof itemSize !== 'function') {
                throw Error('An invalid "itemSize" prop has been specified. ' + 'Value should be a function. ' + ("\"" + (itemSize === null ? 'null' : typeof itemSize) + "\" was specified."));
            }
        }
    }
});
var FixedSizeGrid = /*#__PURE__*/ createGridComponent({
    getColumnOffset: function getColumnOffset(_ref, index) {
        var columnWidth = _ref.columnWidth;
        return index * columnWidth;
    },
    getColumnWidth: function getColumnWidth(_ref2, index) {
        var columnWidth = _ref2.columnWidth;
        return columnWidth;
    },
    getRowOffset: function getRowOffset(_ref3, index) {
        var rowHeight = _ref3.rowHeight;
        return index * rowHeight;
    },
    getRowHeight: function getRowHeight(_ref4, index) {
        var rowHeight = _ref4.rowHeight;
        return rowHeight;
    },
    getEstimatedTotalHeight: function getEstimatedTotalHeight(_ref5) {
        var rowCount = _ref5.rowCount, rowHeight = _ref5.rowHeight;
        return rowHeight * rowCount;
    },
    getEstimatedTotalWidth: function getEstimatedTotalWidth(_ref6) {
        var columnCount = _ref6.columnCount, columnWidth = _ref6.columnWidth;
        return columnWidth * columnCount;
    },
    getOffsetForColumnAndAlignment: function getOffsetForColumnAndAlignment(_ref7, columnIndex, align, scrollLeft, instanceProps, scrollbarSize) {
        var columnCount = _ref7.columnCount, columnWidth = _ref7.columnWidth, width = _ref7.width;
        var lastColumnOffset = Math.max(0, columnCount * columnWidth - width);
        var maxOffset = Math.min(lastColumnOffset, columnIndex * columnWidth);
        var minOffset = Math.max(0, columnIndex * columnWidth - width + scrollbarSize + columnWidth);
        if (align === 'smart') {
            if (scrollLeft >= minOffset - width && scrollLeft <= maxOffset + width) {
                align = 'auto';
            } else {
                align = 'center';
            }
        }
        switch(align){
            case 'start':
                return maxOffset;
            case 'end':
                return minOffset;
            case 'center':
                // "Centered" offset is usually the average of the min and max.
                // But near the edges of the list, this doesn't hold true.
                var middleOffset = Math.round(minOffset + (maxOffset - minOffset) / 2);
                if (middleOffset < Math.ceil(width / 2)) {
                    return 0; // near the beginning
                } else if (middleOffset > lastColumnOffset + Math.floor(width / 2)) {
                    return lastColumnOffset; // near the end
                } else {
                    return middleOffset;
                }
            case 'auto':
            default:
                if (scrollLeft >= minOffset && scrollLeft <= maxOffset) {
                    return scrollLeft;
                } else if (minOffset > maxOffset) {
                    // Because we only take into account the scrollbar size when calculating minOffset
                    // this value can be larger than maxOffset when at the end of the list
                    return minOffset;
                } else if (scrollLeft < minOffset) {
                    return minOffset;
                } else {
                    return maxOffset;
                }
        }
    },
    getOffsetForRowAndAlignment: function getOffsetForRowAndAlignment(_ref8, rowIndex, align, scrollTop, instanceProps, scrollbarSize) {
        var rowHeight = _ref8.rowHeight, height = _ref8.height, rowCount = _ref8.rowCount;
        var lastRowOffset = Math.max(0, rowCount * rowHeight - height);
        var maxOffset = Math.min(lastRowOffset, rowIndex * rowHeight);
        var minOffset = Math.max(0, rowIndex * rowHeight - height + scrollbarSize + rowHeight);
        if (align === 'smart') {
            if (scrollTop >= minOffset - height && scrollTop <= maxOffset + height) {
                align = 'auto';
            } else {
                align = 'center';
            }
        }
        switch(align){
            case 'start':
                return maxOffset;
            case 'end':
                return minOffset;
            case 'center':
                // "Centered" offset is usually the average of the min and max.
                // But near the edges of the list, this doesn't hold true.
                var middleOffset = Math.round(minOffset + (maxOffset - minOffset) / 2);
                if (middleOffset < Math.ceil(height / 2)) {
                    return 0; // near the beginning
                } else if (middleOffset > lastRowOffset + Math.floor(height / 2)) {
                    return lastRowOffset; // near the end
                } else {
                    return middleOffset;
                }
            case 'auto':
            default:
                if (scrollTop >= minOffset && scrollTop <= maxOffset) {
                    return scrollTop;
                } else if (minOffset > maxOffset) {
                    // Because we only take into account the scrollbar size when calculating minOffset
                    // this value can be larger than maxOffset when at the end of the list
                    return minOffset;
                } else if (scrollTop < minOffset) {
                    return minOffset;
                } else {
                    return maxOffset;
                }
        }
    },
    getColumnStartIndexForOffset: function getColumnStartIndexForOffset(_ref9, scrollLeft) {
        var columnWidth = _ref9.columnWidth, columnCount = _ref9.columnCount;
        return Math.max(0, Math.min(columnCount - 1, Math.floor(scrollLeft / columnWidth)));
    },
    getColumnStopIndexForStartIndex: function getColumnStopIndexForStartIndex(_ref10, startIndex, scrollLeft) {
        var columnWidth = _ref10.columnWidth, columnCount = _ref10.columnCount, width = _ref10.width;
        var left = startIndex * columnWidth;
        var numVisibleColumns = Math.ceil((width + scrollLeft - left) / columnWidth);
        return Math.max(0, Math.min(columnCount - 1, startIndex + numVisibleColumns - 1 // -1 is because stop index is inclusive
        ));
    },
    getRowStartIndexForOffset: function getRowStartIndexForOffset(_ref11, scrollTop) {
        var rowHeight = _ref11.rowHeight, rowCount = _ref11.rowCount;
        return Math.max(0, Math.min(rowCount - 1, Math.floor(scrollTop / rowHeight)));
    },
    getRowStopIndexForStartIndex: function getRowStopIndexForStartIndex(_ref12, startIndex, scrollTop) {
        var rowHeight = _ref12.rowHeight, rowCount = _ref12.rowCount, height = _ref12.height;
        var top = startIndex * rowHeight;
        var numVisibleRows = Math.ceil((height + scrollTop - top) / rowHeight);
        return Math.max(0, Math.min(rowCount - 1, startIndex + numVisibleRows - 1 // -1 is because stop index is inclusive
        ));
    },
    initInstanceProps: function initInstanceProps(props) {},
    shouldResetStyleCacheOnItemSizeChange: true,
    validateProps: function validateProps(_ref13) {
        var columnWidth = _ref13.columnWidth, rowHeight = _ref13.rowHeight;
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof columnWidth !== 'number') {
                throw Error('An invalid "columnWidth" prop has been specified. ' + 'Value should be a number. ' + ("\"" + (columnWidth === null ? 'null' : typeof columnWidth) + "\" was specified."));
            }
            if (typeof rowHeight !== 'number') {
                throw Error('An invalid "rowHeight" prop has been specified. ' + 'Value should be a number. ' + ("\"" + (rowHeight === null ? 'null' : typeof rowHeight) + "\" was specified."));
            }
        }
    }
});
var FixedSizeList = /*#__PURE__*/ createListComponent({
    getItemOffset: function getItemOffset(_ref, index) {
        var itemSize = _ref.itemSize;
        return index * itemSize;
    },
    getItemSize: function getItemSize(_ref2, index) {
        var itemSize = _ref2.itemSize;
        return itemSize;
    },
    getEstimatedTotalSize: function getEstimatedTotalSize(_ref3) {
        var itemCount = _ref3.itemCount, itemSize = _ref3.itemSize;
        return itemSize * itemCount;
    },
    getOffsetForIndexAndAlignment: function getOffsetForIndexAndAlignment(_ref4, index, align, scrollOffset, instanceProps, scrollbarSize) {
        var direction = _ref4.direction, height = _ref4.height, itemCount = _ref4.itemCount, itemSize = _ref4.itemSize, layout = _ref4.layout, width = _ref4.width;
        // TODO Deprecate direction "horizontal"
        var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
        var size = isHorizontal ? width : height;
        var lastItemOffset = Math.max(0, itemCount * itemSize - size);
        var maxOffset = Math.min(lastItemOffset, index * itemSize);
        var minOffset = Math.max(0, index * itemSize - size + itemSize + scrollbarSize);
        if (align === 'smart') {
            if (scrollOffset >= minOffset - size && scrollOffset <= maxOffset + size) {
                align = 'auto';
            } else {
                align = 'center';
            }
        }
        switch(align){
            case 'start':
                return maxOffset;
            case 'end':
                return minOffset;
            case 'center':
                {
                    // "Centered" offset is usually the average of the min and max.
                    // But near the edges of the list, this doesn't hold true.
                    var middleOffset = Math.round(minOffset + (maxOffset - minOffset) / 2);
                    if (middleOffset < Math.ceil(size / 2)) {
                        return 0; // near the beginning
                    } else if (middleOffset > lastItemOffset + Math.floor(size / 2)) {
                        return lastItemOffset; // near the end
                    } else {
                        return middleOffset;
                    }
                }
            case 'auto':
            default:
                if (scrollOffset >= minOffset && scrollOffset <= maxOffset) {
                    return scrollOffset;
                } else if (scrollOffset < minOffset) {
                    return minOffset;
                } else {
                    return maxOffset;
                }
        }
    },
    getStartIndexForOffset: function getStartIndexForOffset(_ref5, offset) {
        var itemCount = _ref5.itemCount, itemSize = _ref5.itemSize;
        return Math.max(0, Math.min(itemCount - 1, Math.floor(offset / itemSize)));
    },
    getStopIndexForStartIndex: function getStopIndexForStartIndex(_ref6, startIndex, scrollOffset) {
        var direction = _ref6.direction, height = _ref6.height, itemCount = _ref6.itemCount, itemSize = _ref6.itemSize, layout = _ref6.layout, width = _ref6.width;
        // TODO Deprecate direction "horizontal"
        var isHorizontal = direction === 'horizontal' || layout === 'horizontal';
        var offset = startIndex * itemSize;
        var size = isHorizontal ? width : height;
        var numVisibleItems = Math.ceil((size + scrollOffset - offset) / itemSize);
        return Math.max(0, Math.min(itemCount - 1, startIndex + numVisibleItems - 1 // -1 is because stop index is inclusive
        ));
    },
    initInstanceProps: function initInstanceProps(props) {},
    shouldResetStyleCacheOnItemSizeChange: true,
    validateProps: function validateProps(_ref7) {
        var itemSize = _ref7.itemSize;
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof itemSize !== 'number') {
                throw Error('An invalid "itemSize" prop has been specified. ' + 'Value should be a number. ' + ("\"" + (itemSize === null ? 'null' : typeof itemSize) + "\" was specified."));
            }
        }
    }
});
// Pulled from react-compat
// https://github.com/developit/preact-compat/blob/7c5de00e7c85e2ffd011bf3af02899b63f699d3a/src/index.js#L349
function shallowDiffers(prev, next) {
    for(var attribute in prev){
        if (!(attribute in next)) {
            return true;
        }
    }
    for(var _attribute in next){
        if (prev[_attribute] !== next[_attribute]) {
            return true;
        }
    }
    return false;
}
var _excluded = [
    "style"
], _excluded2 = [
    "style"
];
// It knows to compare individual style props and ignore the wrapper object.
// See https://reactjs.org/docs/react-api.html#reactmemo
function areEqual(prevProps, nextProps) {
    var prevStyle = prevProps.style, prevRest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prevProps, _excluded);
    var nextStyle = nextProps.style, nextRest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nextProps, _excluded2);
    return !shallowDiffers(prevStyle, nextStyle) && !shallowDiffers(prevRest, nextRest);
}
// It knows to compare individual style props and ignore the wrapper object.
// See https://reactjs.org/docs/react-component.html#shouldcomponentupdate
function shouldComponentUpdate(nextProps, nextState) {
    return !areEqual(this.props, nextProps) || shallowDiffers(this.state, nextState);
}
;
 //# sourceMappingURL=index.esm.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */ __turbopack_context__.s({
    "invariant": ()=>invariant
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function invariant(condition, format) {
    for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
        args[_key - 2] = arguments[_key];
    }
    if ("TURBOPACK compile-time truthy", 1) {
        if (format === undefined) {
            throw new Error('invariant requires an error message argument');
        }
    }
    if (!condition) {
        var error;
        if (format === undefined) {
            error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
        } else {
            var argIndex = 0;
            error = new Error(format.replace(/%s/g, function() {
                return args[argIndex++];
            }));
            error.name = 'Invariant Violation';
        }
        error.framesToPop = 1; // we don't care about invariant's own frame
        throw error;
    }
}
;
 //# sourceMappingURL=invariant.esm.js.map
}),
"[project]/node_modules/.pnpm/@react-dnd+shallowequal@2.0.0/node_modules/@react-dnd/shallowequal/dist/shallowequal.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "shallowEqual": ()=>shallowEqual
});
function shallowEqual(objA, objB, compare, compareContext) {
    var compareResult = compare ? compare.call(compareContext, objA, objB) : void 0;
    if (compareResult !== void 0) {
        return !!compareResult;
    }
    if (objA === objB) {
        return true;
    }
    if (typeof objA !== 'object' || !objA || typeof objB !== 'object' || !objB) {
        return false;
    }
    var keysA = Object.keys(objA);
    var keysB = Object.keys(objB);
    if (keysA.length !== keysB.length) {
        return false;
    }
    var bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB); // Test for A's keys different from B.
    for(var idx = 0; idx < keysA.length; idx++){
        var key = keysA[idx];
        if (!bHasOwnProperty(key)) {
            return false;
        }
        var valueA = objA[key];
        var valueB = objB[key];
        compareResult = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;
        if (compareResult === false || compareResult === void 0 && valueA !== valueB) {
            return false;
        }
    }
    return true;
}
;
 //# sourceMappingURL=shallowequal.esm.js.map
}),
"[project]/node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
// do not edit .js files directly - edit src/index.jst
module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && typeof a == 'object' && typeof b == 'object') {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
            length = a.length;
            if (length != b.length) return false;
            for(i = length; i-- !== 0;)if (!equal(a[i], b[i])) return false;
            return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for(i = length; i-- !== 0;)if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for(i = length; i-- !== 0;){
            var key = keys[i];
            if (!equal(a[key], b[key])) return false;
        }
        return true;
    }
    // true if both NaN, false otherwise
    return a !== a && b !== b;
};
}}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/getEmptyImage.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "getEmptyImage": ()=>getEmptyImage
});
var emptyImage;
function getEmptyImage() {
    if (!emptyImage) {
        emptyImage = new Image();
        emptyImage.src = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
    }
    return emptyImage;
}
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/utils/js_utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// cheap lodash replacements
__turbopack_context__.s({
    "memoize": ()=>memoize,
    "union": ()=>union,
    "without": ()=>without
});
function memoize(fn) {
    var result = null;
    var memoized = function memoized() {
        if (result == null) {
            result = fn();
        }
        return result;
    };
    return memoized;
}
function without(items, item) {
    return items.filter(function(i) {
        return i !== item;
    });
}
function union(itemsA, itemsB) {
    var set = new Set();
    var insertItem = function insertItem(item) {
        return set.add(item);
    };
    itemsA.forEach(insertItem);
    itemsB.forEach(insertItem);
    var result = [];
    set.forEach(function(key) {
        return result.push(key);
    });
    return result;
}
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/EnterLeaveCounter.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "EnterLeaveCounter": ()=>EnterLeaveCounter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
var EnterLeaveCounter = /*#__PURE__*/ function() {
    function EnterLeaveCounter(isNodeInDocument) {
        _classCallCheck(this, EnterLeaveCounter);
        _defineProperty(this, "entered", []);
        _defineProperty(this, "isNodeInDocument", void 0);
        this.isNodeInDocument = isNodeInDocument;
    }
    _createClass(EnterLeaveCounter, [
        {
            key: "enter",
            value: function enter(enteringNode) {
                var _this = this;
                var previousLength = this.entered.length;
                var isNodeEntered = function isNodeEntered(node) {
                    return _this.isNodeInDocument(node) && (!node.contains || node.contains(enteringNode));
                };
                this.entered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["union"])(this.entered.filter(isNodeEntered), [
                    enteringNode
                ]);
                return previousLength === 0 && this.entered.length > 0;
            }
        },
        {
            key: "leave",
            value: function leave(leavingNode) {
                var previousLength = this.entered.length;
                this.entered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["without"])(this.entered.filter(this.isNodeInDocument), leavingNode);
                return previousLength > 0 && this.entered.length === 0;
            }
        },
        {
            key: "reset",
            value: function reset() {
                this.entered = [];
            }
        }
    ]);
    return EnterLeaveCounter;
}();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/BrowserDetector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "isFirefox": ()=>isFirefox,
    "isSafari": ()=>isSafari
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
;
var isFirefox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memoize"])(function() {
    return /firefox/i.test(navigator.userAgent);
});
var isSafari = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memoize"])(function() {
    return Boolean(window.safari);
});
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/MonotonicInterpolant.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "MonotonicInterpolant": ()=>MonotonicInterpolant
});
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
var MonotonicInterpolant = /*#__PURE__*/ function() {
    function MonotonicInterpolant(xs, ys) {
        _classCallCheck(this, MonotonicInterpolant);
        _defineProperty(this, "xs", void 0);
        _defineProperty(this, "ys", void 0);
        _defineProperty(this, "c1s", void 0);
        _defineProperty(this, "c2s", void 0);
        _defineProperty(this, "c3s", void 0);
        var length = xs.length; // Rearrange xs and ys so that xs is sorted
        var indexes = [];
        for(var i = 0; i < length; i++){
            indexes.push(i);
        }
        indexes.sort(function(a, b) {
            return xs[a] < xs[b] ? -1 : 1;
        }); // Get consecutive differences and slopes
        var dys = [];
        var dxs = [];
        var ms = [];
        var dx;
        var dy;
        for(var _i = 0; _i < length - 1; _i++){
            dx = xs[_i + 1] - xs[_i];
            dy = ys[_i + 1] - ys[_i];
            dxs.push(dx);
            dys.push(dy);
            ms.push(dy / dx);
        } // Get degree-1 coefficients
        var c1s = [
            ms[0]
        ];
        for(var _i2 = 0; _i2 < dxs.length - 1; _i2++){
            var m2 = ms[_i2];
            var mNext = ms[_i2 + 1];
            if (m2 * mNext <= 0) {
                c1s.push(0);
            } else {
                dx = dxs[_i2];
                var dxNext = dxs[_i2 + 1];
                var common = dx + dxNext;
                c1s.push(3 * common / ((common + dxNext) / m2 + (common + dx) / mNext));
            }
        }
        c1s.push(ms[ms.length - 1]); // Get degree-2 and degree-3 coefficients
        var c2s = [];
        var c3s = [];
        var m;
        for(var _i3 = 0; _i3 < c1s.length - 1; _i3++){
            m = ms[_i3];
            var c1 = c1s[_i3];
            var invDx = 1 / dxs[_i3];
            var _common = c1 + c1s[_i3 + 1] - m - m;
            c2s.push((m - c1 - _common) * invDx);
            c3s.push(_common * invDx * invDx);
        }
        this.xs = xs;
        this.ys = ys;
        this.c1s = c1s;
        this.c2s = c2s;
        this.c3s = c3s;
    }
    _createClass(MonotonicInterpolant, [
        {
            key: "interpolate",
            value: function interpolate(x) {
                var xs = this.xs, ys = this.ys, c1s = this.c1s, c2s = this.c2s, c3s = this.c3s; // The rightmost point in the dataset should give an exact result
                var i = xs.length - 1;
                if (x === xs[i]) {
                    return ys[i];
                } // Search for the interval x is in, returning the corresponding y if x is one of the original xs
                var low = 0;
                var high = c3s.length - 1;
                var mid;
                while(low <= high){
                    mid = Math.floor(0.5 * (low + high));
                    var xHere = xs[mid];
                    if (xHere < x) {
                        low = mid + 1;
                    } else if (xHere > x) {
                        high = mid - 1;
                    } else {
                        return ys[mid];
                    }
                }
                i = Math.max(0, high); // Interpolate
                var diff = x - xs[i];
                var diffSq = diff * diff;
                return ys[i] + c1s[i] * diff + c2s[i] * diffSq + c3s[i] * diff * diffSq;
            }
        }
    ]);
    return MonotonicInterpolant;
}();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/OffsetUtils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "getDragPreviewOffset": ()=>getDragPreviewOffset,
    "getEventClientOffset": ()=>getEventClientOffset,
    "getNodeClientOffset": ()=>getNodeClientOffset
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/BrowserDetector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/MonotonicInterpolant.js [app-client] (ecmascript)");
;
;
var ELEMENT_NODE = 1;
function getNodeClientOffset(node) {
    var el = node.nodeType === ELEMENT_NODE ? node : node.parentElement;
    if (!el) {
        return null;
    }
    var _el$getBoundingClient = el.getBoundingClientRect(), top = _el$getBoundingClient.top, left = _el$getBoundingClient.left;
    return {
        x: left,
        y: top
    };
}
function getEventClientOffset(e) {
    return {
        x: e.clientX,
        y: e.clientY
    };
}
function isImageNode(node) {
    var _document$documentEle;
    return node.nodeName === 'IMG' && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFirefox"])() || !((_document$documentEle = document.documentElement) !== null && _document$documentEle !== void 0 && _document$documentEle.contains(node)));
}
function getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight) {
    var dragPreviewWidth = isImage ? dragPreview.width : sourceWidth;
    var dragPreviewHeight = isImage ? dragPreview.height : sourceHeight; // Work around @2x coordinate discrepancies in browsers
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSafari"])() && isImage) {
        dragPreviewHeight /= window.devicePixelRatio;
        dragPreviewWidth /= window.devicePixelRatio;
    }
    return {
        dragPreviewWidth: dragPreviewWidth,
        dragPreviewHeight: dragPreviewHeight
    };
}
function getDragPreviewOffset(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint) {
    // The browsers will use the image intrinsic size under different conditions.
    // Firefox only cares if it's an image, but WebKit also wants it to be detached.
    var isImage = isImageNode(dragPreview);
    var dragPreviewNode = isImage ? sourceNode : dragPreview;
    var dragPreviewNodeOffsetFromClient = getNodeClientOffset(dragPreviewNode);
    var offsetFromDragPreview = {
        x: clientOffset.x - dragPreviewNodeOffsetFromClient.x,
        y: clientOffset.y - dragPreviewNodeOffsetFromClient.y
    };
    var sourceWidth = sourceNode.offsetWidth, sourceHeight = sourceNode.offsetHeight;
    var anchorX = anchorPoint.anchorX, anchorY = anchorPoint.anchorY;
    var _getDragPreviewSize = getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight), dragPreviewWidth = _getDragPreviewSize.dragPreviewWidth, dragPreviewHeight = _getDragPreviewSize.dragPreviewHeight;
    var calculateYOffset = function calculateYOffset() {
        var interpolantY = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MonotonicInterpolant"]([
            0,
            0.5,
            1
        ], [
            offsetFromDragPreview.y,
            offsetFromDragPreview.y / sourceHeight * dragPreviewHeight,
            offsetFromDragPreview.y + dragPreviewHeight - sourceHeight
        ]);
        var y = interpolantY.interpolate(anchorY); // Work around Safari 8 positioning bug
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$BrowserDetector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSafari"])() && isImage) {
            // We'll have to wait for @3x to see if this is entirely correct
            y += (window.devicePixelRatio - 1) * dragPreviewHeight;
        }
        return y;
    };
    var calculateXOffset = function calculateXOffset() {
        // Interpolate coordinates depending on anchor point
        // If you know a simpler way to do this, let me know
        var interpolantX = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$MonotonicInterpolant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MonotonicInterpolant"]([
            0,
            0.5,
            1
        ], [
            offsetFromDragPreview.x,
            offsetFromDragPreview.x / sourceWidth * dragPreviewWidth,
            offsetFromDragPreview.x + dragPreviewWidth - sourceWidth
        ]);
        return interpolantX.interpolate(anchorX);
    }; // Force offsets if specified in the options.
    var offsetX = offsetPoint.offsetX, offsetY = offsetPoint.offsetY;
    var isManualOffsetX = offsetX === 0 || offsetX;
    var isManualOffsetY = offsetY === 0 || offsetY;
    return {
        x: isManualOffsetX ? offsetX : calculateXOffset(),
        y: isManualOffsetY ? offsetY : calculateYOffset()
    };
}
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeTypes.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "FILE": ()=>FILE,
    "HTML": ()=>HTML,
    "TEXT": ()=>TEXT,
    "URL": ()=>URL
});
var FILE = '__NATIVE_FILE__';
var URL = '__NATIVE_URL__';
var TEXT = '__NATIVE_TEXT__';
var HTML = '__NATIVE_HTML__';
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/getDataFromDataTransfer.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "getDataFromDataTransfer": ()=>getDataFromDataTransfer
});
function getDataFromDataTransfer(dataTransfer, typesToTry, defaultValue) {
    var result = typesToTry.reduce(function(resultSoFar, typeToTry) {
        return resultSoFar || dataTransfer.getData(typeToTry);
    }, '');
    return result != null ? result : defaultValue;
}
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/nativeTypesConfig.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "nativeTypesConfig": ()=>nativeTypesConfig
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/getDataFromDataTransfer.js [app-client] (ecmascript)");
var _nativeTypesConfig;
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
var nativeTypesConfig = (_nativeTypesConfig = {}, _defineProperty(_nativeTypesConfig, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE"], {
    exposeProperties: {
        files: function files(dataTransfer) {
            return Array.prototype.slice.call(dataTransfer.files);
        },
        items: function items(dataTransfer) {
            return dataTransfer.items;
        },
        dataTransfer: function dataTransfer(_dataTransfer) {
            return _dataTransfer;
        }
    },
    matchesTypes: [
        'Files'
    ]
}), _defineProperty(_nativeTypesConfig, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML"], {
    exposeProperties: {
        html: function html(dataTransfer, matchesTypes) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, '');
        },
        dataTransfer: function dataTransfer(_dataTransfer2) {
            return _dataTransfer2;
        }
    },
    matchesTypes: [
        'Html',
        'text/html'
    ]
}), _defineProperty(_nativeTypesConfig, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["URL"], {
    exposeProperties: {
        urls: function urls(dataTransfer, matchesTypes) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, '').split('\n');
        },
        dataTransfer: function dataTransfer(_dataTransfer3) {
            return _dataTransfer3;
        }
    },
    matchesTypes: [
        'Url',
        'text/uri-list'
    ]
}), _defineProperty(_nativeTypesConfig, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT"], {
    exposeProperties: {
        text: function text(dataTransfer, matchesTypes) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$getDataFromDataTransfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataFromDataTransfer"])(dataTransfer, matchesTypes, '');
        },
        dataTransfer: function dataTransfer(_dataTransfer4) {
            return _dataTransfer4;
        }
    },
    matchesTypes: [
        'Text',
        'text/plain'
    ]
}), _nativeTypesConfig);
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/NativeDragSource.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "NativeDragSource": ()=>NativeDragSource
});
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
var NativeDragSource = /*#__PURE__*/ function() {
    function NativeDragSource(config) {
        _classCallCheck(this, NativeDragSource);
        _defineProperty(this, "item", void 0);
        _defineProperty(this, "config", void 0);
        this.config = config;
        this.item = {};
        this.initializeExposedProperties();
    }
    _createClass(NativeDragSource, [
        {
            key: "initializeExposedProperties",
            value: function initializeExposedProperties() {
                var _this = this;
                Object.keys(this.config.exposeProperties).forEach(function(property) {
                    Object.defineProperty(_this.item, property, {
                        configurable: true,
                        enumerable: true,
                        get: function get() {
                            // eslint-disable-next-line no-console
                            console.warn("Browser doesn't allow reading \"".concat(property, "\" until the drop event."));
                            return null;
                        }
                    });
                });
            }
        },
        {
            key: "loadDataTransfer",
            value: function loadDataTransfer(dataTransfer) {
                var _this2 = this;
                if (dataTransfer) {
                    var newProperties = {};
                    Object.keys(this.config.exposeProperties).forEach(function(property) {
                        newProperties[property] = {
                            value: _this2.config.exposeProperties[property](dataTransfer, _this2.config.matchesTypes),
                            configurable: true,
                            enumerable: true
                        };
                    });
                    Object.defineProperties(this.item, newProperties);
                }
            }
        },
        {
            key: "canDrag",
            value: function canDrag() {
                return true;
            }
        },
        {
            key: "beginDrag",
            value: function beginDrag() {
                return this.item;
            }
        },
        {
            key: "isDragging",
            value: function isDragging(monitor, handle) {
                return handle === monitor.getSourceId();
            }
        },
        {
            key: "endDrag",
            value: function endDrag() {}
        }
    ]);
    return NativeDragSource;
}();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createNativeDragSource": ()=>createNativeDragSource,
    "matchNativeItemType": ()=>matchNativeItemType
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/nativeTypesConfig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$NativeDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/NativeDragSource.js [app-client] (ecmascript)");
;
;
function createNativeDragSource(type, dataTransfer) {
    var result = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$NativeDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NativeDragSource"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"][type]);
    result.loadDataTransfer(dataTransfer);
    return result;
}
function matchNativeItemType(dataTransfer) {
    if (!dataTransfer) {
        return null;
    }
    var dataTransferTypes = Array.prototype.slice.call(dataTransfer.types || []);
    return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"]).filter(function(nativeItemType) {
        var matchesTypes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$nativeTypesConfig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nativeTypesConfig"][nativeItemType].matchesTypes;
        return matchesTypes.some(function(t) {
            return dataTransferTypes.indexOf(t) > -1;
        });
    })[0] || null;
}
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/OptionsReader.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "OptionsReader": ()=>OptionsReader
});
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
var OptionsReader = /*#__PURE__*/ function() {
    function OptionsReader(globalContext, options) {
        _classCallCheck(this, OptionsReader);
        _defineProperty(this, "ownerDocument", null);
        _defineProperty(this, "globalContext", void 0);
        _defineProperty(this, "optionsArgs", void 0);
        this.globalContext = globalContext;
        this.optionsArgs = options;
    }
    _createClass(OptionsReader, [
        {
            key: "window",
            get: function get() {
                if (this.globalContext) {
                    return this.globalContext;
                } else if (typeof window !== 'undefined') {
                    return window;
                }
                return undefined;
            }
        },
        {
            key: "document",
            get: function get() {
                var _this$globalContext;
                if ((_this$globalContext = this.globalContext) !== null && _this$globalContext !== void 0 && _this$globalContext.document) {
                    return this.globalContext.document;
                } else if (this.window) {
                    return this.window.document;
                } else {
                    return undefined;
                }
            }
        },
        {
            key: "rootElement",
            get: function get() {
                var _this$optionsArgs;
                return ((_this$optionsArgs = this.optionsArgs) === null || _this$optionsArgs === void 0 ? void 0 : _this$optionsArgs.rootElement) || this.window;
            }
        }
    ]);
    return OptionsReader;
}();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/HTML5BackendImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "HTML5BackendImpl": ()=>HTML5BackendImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$EnterLeaveCounter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/EnterLeaveCounter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/OffsetUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeDragSources/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/NativeTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/OptionsReader.js [app-client] (ecmascript)");
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
            ownKeys(Object(source), true).forEach(function(key) {
                _defineProperty(target, key, source[key]);
            });
        } else if (Object.getOwnPropertyDescriptors) {
            Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
            ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
            });
        }
    }
    return target;
}
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
;
;
var HTML5BackendImpl = /*#__PURE__*/ function() {
    // React-Dnd Components
    // Internal State
    function HTML5BackendImpl(manager, globalContext, options) {
        var _this = this;
        _classCallCheck(this, HTML5BackendImpl);
        _defineProperty(this, "options", void 0);
        _defineProperty(this, "actions", void 0);
        _defineProperty(this, "monitor", void 0);
        _defineProperty(this, "registry", void 0);
        _defineProperty(this, "enterLeaveCounter", void 0);
        _defineProperty(this, "sourcePreviewNodes", new Map());
        _defineProperty(this, "sourcePreviewNodeOptions", new Map());
        _defineProperty(this, "sourceNodes", new Map());
        _defineProperty(this, "sourceNodeOptions", new Map());
        _defineProperty(this, "dragStartSourceIds", null);
        _defineProperty(this, "dropTargetIds", []);
        _defineProperty(this, "dragEnterTargetIds", []);
        _defineProperty(this, "currentNativeSource", null);
        _defineProperty(this, "currentNativeHandle", null);
        _defineProperty(this, "currentDragSourceNode", null);
        _defineProperty(this, "altKeyPressed", false);
        _defineProperty(this, "mouseMoveTimeoutTimer", null);
        _defineProperty(this, "asyncEndDragFrameId", null);
        _defineProperty(this, "dragOverTargetIds", null);
        _defineProperty(this, "lastClientOffset", null);
        _defineProperty(this, "hoverRafId", null);
        _defineProperty(this, "getSourceClientOffset", function(sourceId) {
            var source = _this.sourceNodes.get(sourceId);
            return source && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeClientOffset"])(source) || null;
        });
        _defineProperty(this, "endDragNativeItem", function() {
            if (!_this.isDraggingNativeItem()) {
                return;
            }
            _this.actions.endDrag();
            if (_this.currentNativeHandle) {
                _this.registry.removeSource(_this.currentNativeHandle);
            }
            _this.currentNativeHandle = null;
            _this.currentNativeSource = null;
        });
        _defineProperty(this, "isNodeInDocument", function(node) {
            // Check the node either in the main document or in the current context
            return Boolean(node && _this.document && _this.document.body && _this.document.body.contains(node));
        });
        _defineProperty(this, "endDragIfSourceWasRemovedFromDOM", function() {
            var node = _this.currentDragSourceNode;
            if (node == null || _this.isNodeInDocument(node)) {
                return;
            }
            if (_this.clearCurrentDragSourceNode() && _this.monitor.isDragging()) {
                _this.actions.endDrag();
            }
        });
        _defineProperty(this, "handleTopDragStartCapture", function() {
            _this.clearCurrentDragSourceNode();
            _this.dragStartSourceIds = [];
        });
        _defineProperty(this, "handleTopDragStart", function(e) {
            if (e.defaultPrevented) {
                return;
            }
            var dragStartSourceIds = _this.dragStartSourceIds;
            _this.dragStartSourceIds = null;
            var clientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e); // Avoid crashing if we missed a drop event or our previous drag died
            if (_this.monitor.isDragging()) {
                _this.actions.endDrag();
            } // Don't publish the source just yet (see why below)
            _this.actions.beginDrag(dragStartSourceIds || [], {
                publishSource: false,
                getSourceClientOffset: _this.getSourceClientOffset,
                clientOffset: clientOffset
            });
            var dataTransfer = e.dataTransfer;
            var nativeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(dataTransfer);
            if (_this.monitor.isDragging()) {
                if (dataTransfer && typeof dataTransfer.setDragImage === 'function') {
                    // Use custom drag image if user specifies it.
                    // If child drag source refuses drag but parent agrees,
                    // use parent's node as drag image. Neither works in IE though.
                    var sourceId = _this.monitor.getSourceId();
                    var sourceNode = _this.sourceNodes.get(sourceId);
                    var dragPreview = _this.sourcePreviewNodes.get(sourceId) || sourceNode;
                    if (dragPreview) {
                        var _this$getCurrentSourc = _this.getCurrentSourcePreviewNodeOptions(), anchorX = _this$getCurrentSourc.anchorX, anchorY = _this$getCurrentSourc.anchorY, offsetX = _this$getCurrentSourc.offsetX, offsetY = _this$getCurrentSourc.offsetY;
                        var anchorPoint = {
                            anchorX: anchorX,
                            anchorY: anchorY
                        };
                        var offsetPoint = {
                            offsetX: offsetX,
                            offsetY: offsetY
                        };
                        var dragPreviewOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDragPreviewOffset"])(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint);
                        dataTransfer.setDragImage(dragPreview, dragPreviewOffset.x, dragPreviewOffset.y);
                    }
                }
                try {
                    // Firefox won't drag without setting data
                    dataTransfer === null || dataTransfer === void 0 ? void 0 : dataTransfer.setData('application/json', {});
                } catch (err) {} // Store drag source node so we can check whether
                // it is removed from DOM and trigger endDrag manually.
                _this.setCurrentDragSourceNode(e.target); // Now we are ready to publish the drag source.. or are we not?
                var _this$getCurrentSourc2 = _this.getCurrentSourcePreviewNodeOptions(), captureDraggingState = _this$getCurrentSourc2.captureDraggingState;
                if (!captureDraggingState) {
                    // Usually we want to publish it in the next tick so that browser
                    // is able to screenshot the current (not yet dragging) state.
                    //
                    // It also neatly avoids a situation where render() returns null
                    // in the same tick for the source element, and browser freaks out.
                    setTimeout(function() {
                        return _this.actions.publishDragSource();
                    }, 0);
                } else {
                    // In some cases the user may want to override this behavior, e.g.
                    // to work around IE not supporting custom drag previews.
                    //
                    // When using a custom drag layer, the only way to prevent
                    // the default drag preview from drawing in IE is to screenshot
                    // the dragging state in which the node itself has zero opacity
                    // and height. In this case, though, returning null from render()
                    // will abruptly end the dragging, which is not obvious.
                    //
                    // This is the reason such behavior is strictly opt-in.
                    _this.actions.publishDragSource();
                }
            } else if (nativeType) {
                // A native item (such as URL) dragged from inside the document
                _this.beginDragNativeItem(nativeType);
            } else if (dataTransfer && !dataTransfer.types && (e.target && !e.target.hasAttribute || !e.target.hasAttribute('draggable'))) {
                // Looks like a Safari bug: dataTransfer.types is null, but there was no draggable.
                // Just let it drag. It's a native type (URL or text) and will be picked up in
                // dragenter handler.
                return;
            } else {
                // If by this time no drag source reacted, tell browser not to drag.
                e.preventDefault();
            }
        });
        _defineProperty(this, "handleTopDragEndCapture", function() {
            if (_this.clearCurrentDragSourceNode() && _this.monitor.isDragging()) {
                // Firefox can dispatch this event in an infinite loop
                // if dragend handler does something like showing an alert.
                // Only proceed if we have not handled it already.
                _this.actions.endDrag();
            }
        });
        _defineProperty(this, "handleTopDragEnterCapture", function(e) {
            _this.dragEnterTargetIds = [];
            var isFirstEnter = _this.enterLeaveCounter.enter(e.target);
            if (!isFirstEnter || _this.monitor.isDragging()) {
                return;
            }
            var dataTransfer = e.dataTransfer;
            var nativeType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(dataTransfer);
            if (nativeType) {
                // A native item (such as file or URL) dragged from outside the document
                _this.beginDragNativeItem(nativeType, dataTransfer);
            }
        });
        _defineProperty(this, "handleTopDragEnter", function(e) {
            var dragEnterTargetIds = _this.dragEnterTargetIds;
            _this.dragEnterTargetIds = [];
            if (!_this.monitor.isDragging()) {
                // This is probably a native item type we don't understand.
                return;
            }
            _this.altKeyPressed = e.altKey; // If the target changes position as the result of `dragenter`, `dragover` might still
            // get dispatched despite target being no longer there. The easy solution is to check
            // whether there actually is a target before firing `hover`.
            if (dragEnterTargetIds.length > 0) {
                _this.actions.hover(dragEnterTargetIds, {
                    clientOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e)
                });
            }
            var canDrop = dragEnterTargetIds.some(function(targetId) {
                return _this.monitor.canDropOnTarget(targetId);
            });
            if (canDrop) {
                // IE requires this to fire dragover events
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = _this.getCurrentDropEffect();
                }
            }
        });
        _defineProperty(this, "handleTopDragOverCapture", function() {
            _this.dragOverTargetIds = [];
        });
        _defineProperty(this, "handleTopDragOver", function(e) {
            var dragOverTargetIds = _this.dragOverTargetIds;
            _this.dragOverTargetIds = [];
            if (!_this.monitor.isDragging()) {
                // This is probably a native item type we don't understand.
                // Prevent default "drop and blow away the whole document" action.
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = 'none';
                }
                return;
            }
            _this.altKeyPressed = e.altKey;
            _this.lastClientOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e);
            if (_this.hoverRafId === null && typeof requestAnimationFrame !== 'undefined') {
                _this.hoverRafId = requestAnimationFrame(function() {
                    if (_this.monitor.isDragging()) {
                        _this.actions.hover(dragOverTargetIds || [], {
                            clientOffset: _this.lastClientOffset
                        });
                    }
                    _this.hoverRafId = null;
                });
            }
            var canDrop = (dragOverTargetIds || []).some(function(targetId) {
                return _this.monitor.canDropOnTarget(targetId);
            });
            if (canDrop) {
                // Show user-specified drop effect.
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = _this.getCurrentDropEffect();
                }
            } else if (_this.isDraggingNativeItem()) {
                // Don't show a nice cursor but still prevent default
                // "drop and blow away the whole document" action.
                e.preventDefault();
            } else {
                e.preventDefault();
                if (e.dataTransfer) {
                    e.dataTransfer.dropEffect = 'none';
                }
            }
        });
        _defineProperty(this, "handleTopDragLeaveCapture", function(e) {
            if (_this.isDraggingNativeItem()) {
                e.preventDefault();
            }
            var isLastLeave = _this.enterLeaveCounter.leave(e.target);
            if (!isLastLeave) {
                return;
            }
            if (_this.isDraggingNativeItem()) {
                setTimeout(function() {
                    return _this.endDragNativeItem();
                }, 0);
            }
        });
        _defineProperty(this, "handleTopDropCapture", function(e) {
            _this.dropTargetIds = [];
            if (_this.isDraggingNativeItem()) {
                var _this$currentNativeSo;
                e.preventDefault();
                (_this$currentNativeSo = _this.currentNativeSource) === null || _this$currentNativeSo === void 0 ? void 0 : _this$currentNativeSo.loadDataTransfer(e.dataTransfer);
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchNativeItemType"])(e.dataTransfer)) {
                // Dragging some elements, like <a> and <img> may still behave like a native drag event,
                // even if the current drag event matches a user-defined type.
                // Stop the default behavior when we're not expecting a native item to be dropped.
                e.preventDefault();
            }
            _this.enterLeaveCounter.reset();
        });
        _defineProperty(this, "handleTopDrop", function(e) {
            var dropTargetIds = _this.dropTargetIds;
            _this.dropTargetIds = [];
            _this.actions.hover(dropTargetIds, {
                clientOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OffsetUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEventClientOffset"])(e)
            });
            _this.actions.drop({
                dropEffect: _this.getCurrentDropEffect()
            });
            if (_this.isDraggingNativeItem()) {
                _this.endDragNativeItem();
            } else if (_this.monitor.isDragging()) {
                _this.actions.endDrag();
            }
        });
        _defineProperty(this, "handleSelectStart", function(e) {
            var target = e.target; // Only IE requires us to explicitly say
            // we want drag drop operation to start
            if (typeof target.dragDrop !== 'function') {
                return;
            } // Inputs and textareas should be selectable
            if (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
                return;
            } // For other targets, ask IE
            // to enable drag and drop
            e.preventDefault();
            target.dragDrop();
        });
        this.options = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$OptionsReader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OptionsReader"](globalContext, options);
        this.actions = manager.getActions();
        this.monitor = manager.getMonitor();
        this.registry = manager.getRegistry();
        this.enterLeaveCounter = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$EnterLeaveCounter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EnterLeaveCounter"](this.isNodeInDocument);
    }
    /**
   * Generate profiling statistics for the HTML5Backend.
   */ _createClass(HTML5BackendImpl, [
        {
            key: "profile",
            value: function profile() {
                var _this$dragStartSource, _this$dragOverTargetI;
                return {
                    sourcePreviewNodes: this.sourcePreviewNodes.size,
                    sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
                    sourceNodeOptions: this.sourceNodeOptions.size,
                    sourceNodes: this.sourceNodes.size,
                    dragStartSourceIds: ((_this$dragStartSource = this.dragStartSourceIds) === null || _this$dragStartSource === void 0 ? void 0 : _this$dragStartSource.length) || 0,
                    dropTargetIds: this.dropTargetIds.length,
                    dragEnterTargetIds: this.dragEnterTargetIds.length,
                    dragOverTargetIds: ((_this$dragOverTargetI = this.dragOverTargetIds) === null || _this$dragOverTargetI === void 0 ? void 0 : _this$dragOverTargetI.length) || 0
                };
            } // public for test
        },
        {
            key: "window",
            get: function get() {
                return this.options.window;
            }
        },
        {
            key: "document",
            get: function get() {
                return this.options.document;
            }
        },
        {
            key: "rootElement",
            get: function get() {
                return this.options.rootElement;
            }
        },
        {
            key: "setup",
            value: function setup() {
                var root = this.rootElement;
                if (root === undefined) {
                    return;
                }
                if (root.__isReactDndBackendSetUp) {
                    throw new Error('Cannot have two HTML5 backends at the same time.');
                }
                root.__isReactDndBackendSetUp = true;
                this.addEventListeners(root);
            }
        },
        {
            key: "teardown",
            value: function teardown() {
                var root = this.rootElement;
                if (root === undefined) {
                    return;
                }
                root.__isReactDndBackendSetUp = false;
                this.removeEventListeners(this.rootElement);
                this.clearCurrentDragSourceNode();
                if (this.asyncEndDragFrameId) {
                    var _this$window;
                    (_this$window = this.window) === null || _this$window === void 0 ? void 0 : _this$window.cancelAnimationFrame(this.asyncEndDragFrameId);
                }
            }
        },
        {
            key: "connectDragPreview",
            value: function connectDragPreview(sourceId, node, options) {
                var _this2 = this;
                this.sourcePreviewNodeOptions.set(sourceId, options);
                this.sourcePreviewNodes.set(sourceId, node);
                return function() {
                    _this2.sourcePreviewNodes.delete(sourceId);
                    _this2.sourcePreviewNodeOptions.delete(sourceId);
                };
            }
        },
        {
            key: "connectDragSource",
            value: function connectDragSource(sourceId, node, options) {
                var _this3 = this;
                this.sourceNodes.set(sourceId, node);
                this.sourceNodeOptions.set(sourceId, options);
                var handleDragStart = function handleDragStart(e) {
                    return _this3.handleDragStart(e, sourceId);
                };
                var handleSelectStart = function handleSelectStart(e) {
                    return _this3.handleSelectStart(e);
                };
                node.setAttribute('draggable', 'true');
                node.addEventListener('dragstart', handleDragStart);
                node.addEventListener('selectstart', handleSelectStart);
                return function() {
                    _this3.sourceNodes.delete(sourceId);
                    _this3.sourceNodeOptions.delete(sourceId);
                    node.removeEventListener('dragstart', handleDragStart);
                    node.removeEventListener('selectstart', handleSelectStart);
                    node.setAttribute('draggable', 'false');
                };
            }
        },
        {
            key: "connectDropTarget",
            value: function connectDropTarget(targetId, node) {
                var _this4 = this;
                var handleDragEnter = function handleDragEnter(e) {
                    return _this4.handleDragEnter(e, targetId);
                };
                var handleDragOver = function handleDragOver(e) {
                    return _this4.handleDragOver(e, targetId);
                };
                var handleDrop = function handleDrop(e) {
                    return _this4.handleDrop(e, targetId);
                };
                node.addEventListener('dragenter', handleDragEnter);
                node.addEventListener('dragover', handleDragOver);
                node.addEventListener('drop', handleDrop);
                return function() {
                    node.removeEventListener('dragenter', handleDragEnter);
                    node.removeEventListener('dragover', handleDragOver);
                    node.removeEventListener('drop', handleDrop);
                };
            }
        },
        {
            key: "addEventListeners",
            value: function addEventListeners(target) {
                // SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
                if (!target.addEventListener) {
                    return;
                }
                target.addEventListener('dragstart', this.handleTopDragStart);
                target.addEventListener('dragstart', this.handleTopDragStartCapture, true);
                target.addEventListener('dragend', this.handleTopDragEndCapture, true);
                target.addEventListener('dragenter', this.handleTopDragEnter);
                target.addEventListener('dragenter', this.handleTopDragEnterCapture, true);
                target.addEventListener('dragleave', this.handleTopDragLeaveCapture, true);
                target.addEventListener('dragover', this.handleTopDragOver);
                target.addEventListener('dragover', this.handleTopDragOverCapture, true);
                target.addEventListener('drop', this.handleTopDrop);
                target.addEventListener('drop', this.handleTopDropCapture, true);
            }
        },
        {
            key: "removeEventListeners",
            value: function removeEventListeners(target) {
                // SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
                if (!target.removeEventListener) {
                    return;
                }
                target.removeEventListener('dragstart', this.handleTopDragStart);
                target.removeEventListener('dragstart', this.handleTopDragStartCapture, true);
                target.removeEventListener('dragend', this.handleTopDragEndCapture, true);
                target.removeEventListener('dragenter', this.handleTopDragEnter);
                target.removeEventListener('dragenter', this.handleTopDragEnterCapture, true);
                target.removeEventListener('dragleave', this.handleTopDragLeaveCapture, true);
                target.removeEventListener('dragover', this.handleTopDragOver);
                target.removeEventListener('dragover', this.handleTopDragOverCapture, true);
                target.removeEventListener('drop', this.handleTopDrop);
                target.removeEventListener('drop', this.handleTopDropCapture, true);
            }
        },
        {
            key: "getCurrentSourceNodeOptions",
            value: function getCurrentSourceNodeOptions() {
                var sourceId = this.monitor.getSourceId();
                var sourceNodeOptions = this.sourceNodeOptions.get(sourceId);
                return _objectSpread({
                    dropEffect: this.altKeyPressed ? 'copy' : 'move'
                }, sourceNodeOptions || {});
            }
        },
        {
            key: "getCurrentDropEffect",
            value: function getCurrentDropEffect() {
                if (this.isDraggingNativeItem()) {
                    // It makes more sense to default to 'copy' for native resources
                    return 'copy';
                }
                return this.getCurrentSourceNodeOptions().dropEffect;
            }
        },
        {
            key: "getCurrentSourcePreviewNodeOptions",
            value: function getCurrentSourcePreviewNodeOptions() {
                var sourceId = this.monitor.getSourceId();
                var sourcePreviewNodeOptions = this.sourcePreviewNodeOptions.get(sourceId);
                return _objectSpread({
                    anchorX: 0.5,
                    anchorY: 0.5,
                    captureDraggingState: false
                }, sourcePreviewNodeOptions || {});
            }
        },
        {
            key: "isDraggingNativeItem",
            value: function isDraggingNativeItem() {
                var itemType = this.monitor.getItemType();
                return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__).some(function(key) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__[key] === itemType;
                });
            }
        },
        {
            key: "beginDragNativeItem",
            value: function beginDragNativeItem(type, dataTransfer) {
                this.clearCurrentDragSourceNode();
                this.currentNativeSource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$NativeDragSources$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createNativeDragSource"])(type, dataTransfer);
                this.currentNativeHandle = this.registry.addSource(type, this.currentNativeSource);
                this.actions.beginDrag([
                    this.currentNativeHandle
                ]);
            }
        },
        {
            key: "setCurrentDragSourceNode",
            value: function setCurrentDragSourceNode(node) {
                var _this5 = this;
                this.clearCurrentDragSourceNode();
                this.currentDragSourceNode = node; // A timeout of > 0 is necessary to resolve Firefox issue referenced
                // See:
                //   * https://github.com/react-dnd/react-dnd/pull/928
                //   * https://github.com/react-dnd/react-dnd/issues/869
                var MOUSE_MOVE_TIMEOUT = 1000; // Receiving a mouse event in the middle of a dragging operation
                // means it has ended and the drag source node disappeared from DOM,
                // so the browser didn't dispatch the dragend event.
                //
                // We need to wait before we start listening for mousemove events.
                // This is needed because the drag preview needs to be drawn or else it fires an 'mousemove' event
                // immediately in some browsers.
                //
                // See:
                //   * https://github.com/react-dnd/react-dnd/pull/928
                //   * https://github.com/react-dnd/react-dnd/issues/869
                //
                this.mouseMoveTimeoutTimer = setTimeout(function() {
                    var _this5$rootElement;
                    return (_this5$rootElement = _this5.rootElement) === null || _this5$rootElement === void 0 ? void 0 : _this5$rootElement.addEventListener('mousemove', _this5.endDragIfSourceWasRemovedFromDOM, true);
                }, MOUSE_MOVE_TIMEOUT);
            }
        },
        {
            key: "clearCurrentDragSourceNode",
            value: function clearCurrentDragSourceNode() {
                if (this.currentDragSourceNode) {
                    this.currentDragSourceNode = null;
                    if (this.rootElement) {
                        var _this$window2;
                        (_this$window2 = this.window) === null || _this$window2 === void 0 ? void 0 : _this$window2.clearTimeout(this.mouseMoveTimeoutTimer || undefined);
                        this.rootElement.removeEventListener('mousemove', this.endDragIfSourceWasRemovedFromDOM, true);
                    }
                    this.mouseMoveTimeoutTimer = null;
                    return true;
                }
                return false;
            }
        },
        {
            key: "handleDragStart",
            value: function handleDragStart(e, sourceId) {
                if (e.defaultPrevented) {
                    return;
                }
                if (!this.dragStartSourceIds) {
                    this.dragStartSourceIds = [];
                }
                this.dragStartSourceIds.unshift(sourceId);
            }
        },
        {
            key: "handleDragEnter",
            value: function handleDragEnter(e, targetId) {
                this.dragEnterTargetIds.unshift(targetId);
            }
        },
        {
            key: "handleDragOver",
            value: function handleDragOver(e, targetId) {
                if (this.dragOverTargetIds === null) {
                    this.dragOverTargetIds = [];
                }
                this.dragOverTargetIds.unshift(targetId);
            }
        },
        {
            key: "handleDrop",
            value: function handleDrop(e, targetId) {
                this.dropTargetIds.unshift(targetId);
            }
        }
    ]);
    return HTML5BackendImpl;
}();
}),
"[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "HTML5Backend": ()=>HTML5Backend
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$HTML5BackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/HTML5BackendImpl.js [app-client] (ecmascript)");
;
;
;
;
var HTML5Backend = function createBackend(manager, context, options) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$HTML5BackendImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HTML5BackendImpl"](manager, context, options);
};
}),
"[project]/node_modules/.pnpm/redux@5.0.1/node_modules/redux/dist/redux.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/utils/formatProdErrorMessage.ts
__turbopack_context__.s({
    "__DO_NOT_USE__ActionTypes": ()=>actionTypes_default,
    "applyMiddleware": ()=>applyMiddleware,
    "bindActionCreators": ()=>bindActionCreators,
    "combineReducers": ()=>combineReducers,
    "compose": ()=>compose,
    "createStore": ()=>createStore,
    "isAction": ()=>isAction,
    "isPlainObject": ()=>isPlainObject,
    "legacy_createStore": ()=>legacy_createStore
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function formatProdErrorMessage(code) {
    return "Minified Redux error #".concat(code, "; visit https://redux.js.org/Errors?code=").concat(code, " for the full message or use the non-minified dev environment for full errors. ");
}
// src/utils/symbol-observable.ts
var $$observable = /* @__PURE__ */ (()=>typeof Symbol === "function" && Symbol.observable || "@@observable")();
var symbol_observable_default = $$observable;
// src/utils/actionTypes.ts
var randomString = ()=>Math.random().toString(36).substring(7).split("").join(".");
var ActionTypes = {
    INIT: "@@redux/INIT".concat(/* @__PURE__ */ randomString()),
    REPLACE: "@@redux/REPLACE".concat(/* @__PURE__ */ randomString()),
    PROBE_UNKNOWN_ACTION: ()=>"@@redux/PROBE_UNKNOWN_ACTION".concat(randomString())
};
var actionTypes_default = ActionTypes;
// src/utils/isPlainObject.ts
function isPlainObject(obj) {
    if (typeof obj !== "object" || obj === null) return false;
    let proto = obj;
    while(Object.getPrototypeOf(proto) !== null){
        proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(obj) === proto || Object.getPrototypeOf(obj) === null;
}
// src/utils/kindOf.ts
function miniKindOf(val) {
    if (val === void 0) return "undefined";
    if (val === null) return "null";
    const type = typeof val;
    switch(type){
        case "boolean":
        case "string":
        case "number":
        case "symbol":
        case "function":
            {
                return type;
            }
    }
    if (Array.isArray(val)) return "array";
    if (isDate(val)) return "date";
    if (isError(val)) return "error";
    const constructorName = ctorName(val);
    switch(constructorName){
        case "Symbol":
        case "Promise":
        case "WeakMap":
        case "WeakSet":
        case "Map":
        case "Set":
            return constructorName;
    }
    return Object.prototype.toString.call(val).slice(8, -1).toLowerCase().replace(/\s/g, "");
}
function ctorName(val) {
    return typeof val.constructor === "function" ? val.constructor.name : null;
}
function isError(val) {
    return val instanceof Error || typeof val.message === "string" && val.constructor && typeof val.constructor.stackTraceLimit === "number";
}
function isDate(val) {
    if (val instanceof Date) return true;
    return typeof val.toDateString === "function" && typeof val.getDate === "function" && typeof val.setDate === "function";
}
function kindOf(val) {
    let typeOfVal = typeof val;
    if ("TURBOPACK compile-time truthy", 1) {
        typeOfVal = miniKindOf(val);
    }
    return typeOfVal;
}
// src/createStore.ts
function createStore(reducer, preloadedState, enhancer) {
    if (typeof reducer !== "function") {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the root reducer to be a function. Instead, received: '".concat(kindOf(reducer), "'"));
    }
    if (typeof preloadedState === "function" && typeof enhancer === "function" || typeof enhancer === "function" && typeof arguments[3] === "function") {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "It looks like you are passing several store enhancers to createStore(). This is not supported. Instead, compose them together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example.");
    }
    if (typeof preloadedState === "function" && typeof enhancer === "undefined") {
        enhancer = preloadedState;
        preloadedState = void 0;
    }
    if (typeof enhancer !== "undefined") {
        if (typeof enhancer !== "function") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the enhancer to be a function. Instead, received: '".concat(kindOf(enhancer), "'"));
        }
        return enhancer(createStore)(reducer, preloadedState);
    }
    let currentReducer = reducer;
    let currentState = preloadedState;
    let currentListeners = /* @__PURE__ */ new Map();
    let nextListeners = currentListeners;
    let listenerIdCounter = 0;
    let isDispatching = false;
    function ensureCanMutateNextListeners() {
        if (nextListeners === currentListeners) {
            nextListeners = /* @__PURE__ */ new Map();
            currentListeners.forEach((listener, key)=>{
                nextListeners.set(key, listener);
            });
        }
    }
    function getState() {
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "You may not call store.getState() while the reducer is executing. The reducer has already received the state as an argument. Pass it down from the top reducer instead of reading it from the store.");
        }
        return currentState;
    }
    function subscribe(listener) {
        if (typeof listener !== "function") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the listener to be a function. Instead, received: '".concat(kindOf(listener), "'"));
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "You may not call store.subscribe() while the reducer is executing. If you would like to be notified after the store has been updated, subscribe from a component and invoke store.getState() in the callback to access the latest state. See https://redux.js.org/api/store#subscribelistener for more details.");
        }
        let isSubscribed = true;
        ensureCanMutateNextListeners();
        const listenerId = listenerIdCounter++;
        nextListeners.set(listenerId, listener);
        return function unsubscribe() {
            if (!isSubscribed) {
                return;
            }
            if (isDispatching) {
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "You may not unsubscribe from a store listener while the reducer is executing. See https://redux.js.org/api/store#subscribelistener for more details.");
            }
            isSubscribed = false;
            ensureCanMutateNextListeners();
            nextListeners.delete(listenerId);
            currentListeners = null;
        };
    }
    function dispatch(action) {
        if (!isPlainObject(action)) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Actions must be plain objects. Instead, the actual type was: '".concat(kindOf(action), "'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples."));
        }
        if (typeof action.type === "undefined") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Actions may not have an undefined "type" property. You may have misspelled an action type string constant.');
        }
        if (typeof action.type !== "string") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Action "type" property must be a string. Instead, the actual type was: \''.concat(kindOf(action.type), "'. Value was: '").concat(action.type, "' (stringified)"));
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Reducers may not dispatch actions.");
        }
        try {
            isDispatching = true;
            currentState = currentReducer(currentState, action);
        } finally{
            isDispatching = false;
        }
        const listeners = currentListeners = nextListeners;
        listeners.forEach((listener)=>{
            listener();
        });
        return action;
    }
    function replaceReducer(nextReducer) {
        if (typeof nextReducer !== "function") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the nextReducer to be a function. Instead, received: '".concat(kindOf(nextReducer)));
        }
        currentReducer = nextReducer;
        dispatch({
            type: actionTypes_default.REPLACE
        });
    }
    function observable() {
        const outerSubscribe = subscribe;
        return {
            /**
       * The minimal observable subscription method.
       * @param observer Any object that can be used as an observer.
       * The observer object should have a `next` method.
       * @returns An object with an `unsubscribe` method that can
       * be used to unsubscribe the observable from the store, and prevent further
       * emission of values from the observable.
       */ subscribe (observer) {
                if (typeof observer !== "object" || observer === null) {
                    throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the observer to be an object. Instead, received: '".concat(kindOf(observer), "'"));
                }
                function observeState() {
                    const observerAsObserver = observer;
                    if (observerAsObserver.next) {
                        observerAsObserver.next(getState());
                    }
                }
                observeState();
                const unsubscribe = outerSubscribe(observeState);
                return {
                    unsubscribe
                };
            },
            [symbol_observable_default] () {
                return this;
            }
        };
    }
    dispatch({
        type: actionTypes_default.INIT
    });
    const store = {
        dispatch,
        subscribe,
        getState,
        replaceReducer,
        [symbol_observable_default]: observable
    };
    return store;
}
function legacy_createStore(reducer, preloadedState, enhancer) {
    return createStore(reducer, preloadedState, enhancer);
}
// src/utils/warning.ts
function warning(message) {
    if (typeof console !== "undefined" && typeof console.error === "function") {
        console.error(message);
    }
    try {
        throw new Error(message);
    } catch (e) {}
}
// src/combineReducers.ts
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
    const reducerKeys = Object.keys(reducers);
    const argumentName = action && action.type === actionTypes_default.INIT ? "preloadedState argument passed to createStore" : "previous state received by the reducer";
    if (reducerKeys.length === 0) {
        return "Store does not have a valid reducer. Make sure the argument passed to combineReducers is an object whose values are reducers.";
    }
    if (!isPlainObject(inputState)) {
        return "The ".concat(argumentName, ' has unexpected type of "').concat(kindOf(inputState), '". Expected argument to be an object with the following keys: "').concat(reducerKeys.join('", "'), '"');
    }
    const unexpectedKeys = Object.keys(inputState).filter((key)=>!reducers.hasOwnProperty(key) && !unexpectedKeyCache[key]);
    unexpectedKeys.forEach((key)=>{
        unexpectedKeyCache[key] = true;
    });
    if (action && action.type === actionTypes_default.REPLACE) return;
    if (unexpectedKeys.length > 0) {
        return "Unexpected ".concat(unexpectedKeys.length > 1 ? "keys" : "key", ' "').concat(unexpectedKeys.join('", "'), '" found in ').concat(argumentName, '. Expected to find one of the known reducer keys instead: "').concat(reducerKeys.join('", "'), '". Unexpected keys will be ignored.');
    }
}
function assertReducerShape(reducers) {
    Object.keys(reducers).forEach((key)=>{
        const reducer = reducers[key];
        const initialState = reducer(void 0, {
            type: actionTypes_default.INIT
        });
        if (typeof initialState === "undefined") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'The slice reducer for key "'.concat(key, "\" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined."));
        }
        if (typeof reducer(void 0, {
            type: actionTypes_default.PROBE_UNKNOWN_ACTION()
        }) === "undefined") {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'The slice reducer for key "'.concat(key, "\" returned undefined when probed with a random type. Don't try to handle '").concat(actionTypes_default.INIT, '\' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.'));
        }
    });
}
function combineReducers(reducers) {
    const reducerKeys = Object.keys(reducers);
    const finalReducers = {};
    for(let i = 0; i < reducerKeys.length; i++){
        const key = reducerKeys[i];
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof reducers[key] === "undefined") {
                warning('No reducer provided for key "'.concat(key, '"'));
            }
        }
        if (typeof reducers[key] === "function") {
            finalReducers[key] = reducers[key];
        }
    }
    const finalReducerKeys = Object.keys(finalReducers);
    let unexpectedKeyCache;
    if (("TURBOPACK compile-time value", "development") !== "production") {
        unexpectedKeyCache = {};
    }
    let shapeAssertionError;
    try {
        assertReducerShape(finalReducers);
    } catch (e) {
        shapeAssertionError = e;
    }
    return function combination() {
        let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, action = arguments.length > 1 ? arguments[1] : void 0;
        if (shapeAssertionError) {
            throw shapeAssertionError;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            const warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
            if (warningMessage) {
                warning(warningMessage);
            }
        }
        let hasChanged = false;
        const nextState = {};
        for(let i = 0; i < finalReducerKeys.length; i++){
            const key = finalReducerKeys[i];
            const reducer = finalReducers[key];
            const previousStateForKey = state[key];
            const nextStateForKey = reducer(previousStateForKey, action);
            if (typeof nextStateForKey === "undefined") {
                const actionType = action && action.type;
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "When called with an action of type ".concat(actionType ? '"'.concat(String(actionType), '"') : "(unknown type)", ', the slice reducer for key "').concat(key, '" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.'));
            }
            nextState[key] = nextStateForKey;
            hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
        }
        hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
        return hasChanged ? nextState : state;
    };
}
// src/bindActionCreators.ts
function bindActionCreator(actionCreator, dispatch) {
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        return dispatch(actionCreator.apply(this, args));
    };
}
function bindActionCreators(actionCreators, dispatch) {
    if (typeof actionCreators === "function") {
        return bindActionCreator(actionCreators, dispatch);
    }
    if (typeof actionCreators !== "object" || actionCreators === null) {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "bindActionCreators expected an object or a function, but instead received: '".concat(kindOf(actionCreators), '\'. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?'));
    }
    const boundActionCreators = {};
    for(const key in actionCreators){
        const actionCreator = actionCreators[key];
        if (typeof actionCreator === "function") {
            boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
        }
    }
    return boundActionCreators;
}
// src/compose.ts
function compose() {
    for(var _len = arguments.length, funcs = new Array(_len), _key = 0; _key < _len; _key++){
        funcs[_key] = arguments[_key];
    }
    if (funcs.length === 0) {
        return (arg)=>arg;
    }
    if (funcs.length === 1) {
        return funcs[0];
    }
    return funcs.reduce((a, b)=>function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            return a(b(...args));
        });
}
// src/applyMiddleware.ts
function applyMiddleware() {
    for(var _len = arguments.length, middlewares = new Array(_len), _key = 0; _key < _len; _key++){
        middlewares[_key] = arguments[_key];
    }
    return (createStore2)=>(reducer, preloadedState)=>{
            const store = createStore2(reducer, preloadedState);
            let dispatch = ()=>{
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Dispatching while constructing your middleware is not allowed. Other middleware would not be applied to this dispatch.");
            };
            const middlewareAPI = {
                getState: store.getState,
                dispatch: function(action) {
                    for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
                        args[_key - 1] = arguments[_key];
                    }
                    return dispatch(action, ...args);
                }
            };
            const chain = middlewares.map((middleware)=>middleware(middlewareAPI));
            dispatch = compose(...chain)(store.dispatch);
            return {
                ...store,
                dispatch
            };
        };
}
// src/utils/isAction.ts
function isAction(action) {
    return isPlainObject(action) && "type" in action && typeof action.type === "string";
}
;
 //# sourceMappingURL=redux.mjs.map
}),
"[project]/node_modules/.pnpm/redux@4.2.0/node_modules/redux/es/redux.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "__DO_NOT_USE__ActionTypes": ()=>ActionTypes,
    "applyMiddleware": ()=>applyMiddleware,
    "bindActionCreators": ()=>bindActionCreators,
    "combineReducers": ()=>combineReducers,
    "compose": ()=>compose,
    "createStore": ()=>createStore,
    "legacy_createStore": ()=>legacy_createStore
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@babel+runtime@7.28.2/node_modules/@babel/runtime/helpers/esm/objectSpread2.js [app-client] (ecmascript)");
;
/**
 * Adapted from React: https://github.com/facebook/react/blob/master/packages/shared/formatProdErrorMessage.js
 *
 * Do not require this module directly! Use normal throw error calls. These messages will be replaced with error codes
 * during build.
 * @param {number} code
 */ function formatProdErrorMessage(code) {
    return "Minified Redux error #" + code + "; visit https://redux.js.org/Errors?code=" + code + " for the full message or " + 'use the non-minified dev environment for full errors. ';
}
// Inlined version of the `symbol-observable` polyfill
var $$observable = function() {
    return typeof Symbol === 'function' && Symbol.observable || '@@observable';
}();
/**
 * These are private action types reserved by Redux.
 * For any unknown actions, you must return the current state.
 * If the current state is undefined, you must return the initial state.
 * Do not reference these action types directly in your code.
 */ var randomString = function randomString() {
    return Math.random().toString(36).substring(7).split('').join('.');
};
var ActionTypes = {
    INIT: "@@redux/INIT" + randomString(),
    REPLACE: "@@redux/REPLACE" + randomString(),
    PROBE_UNKNOWN_ACTION: function PROBE_UNKNOWN_ACTION() {
        return "@@redux/PROBE_UNKNOWN_ACTION" + randomString();
    }
};
/**
 * @param {any} obj The object to inspect.
 * @returns {boolean} True if the argument appears to be a plain object.
 */ function isPlainObject(obj) {
    if (typeof obj !== 'object' || obj === null) return false;
    var proto = obj;
    while(Object.getPrototypeOf(proto) !== null){
        proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(obj) === proto;
}
// Inlined / shortened version of `kindOf` from https://github.com/jonschlinkert/kind-of
function miniKindOf(val) {
    if (val === void 0) return 'undefined';
    if (val === null) return 'null';
    var type = typeof val;
    switch(type){
        case 'boolean':
        case 'string':
        case 'number':
        case 'symbol':
        case 'function':
            {
                return type;
            }
    }
    if (Array.isArray(val)) return 'array';
    if (isDate(val)) return 'date';
    if (isError(val)) return 'error';
    var constructorName = ctorName(val);
    switch(constructorName){
        case 'Symbol':
        case 'Promise':
        case 'WeakMap':
        case 'WeakSet':
        case 'Map':
        case 'Set':
            return constructorName;
    } // other
    return type.slice(8, -1).toLowerCase().replace(/\s/g, '');
}
function ctorName(val) {
    return typeof val.constructor === 'function' ? val.constructor.name : null;
}
function isError(val) {
    return val instanceof Error || typeof val.message === 'string' && val.constructor && typeof val.constructor.stackTraceLimit === 'number';
}
function isDate(val) {
    if (val instanceof Date) return true;
    return typeof val.toDateString === 'function' && typeof val.getDate === 'function' && typeof val.setDate === 'function';
}
function kindOf(val) {
    var typeOfVal = typeof val;
    if ("TURBOPACK compile-time truthy", 1) {
        typeOfVal = miniKindOf(val);
    }
    return typeOfVal;
}
/**
 * @deprecated
 *
 * **We recommend using the `configureStore` method
 * of the `@reduxjs/toolkit` package**, which replaces `createStore`.
 *
 * Redux Toolkit is our recommended approach for writing Redux logic today,
 * including store setup, reducers, data fetching, and more.
 *
 * **For more details, please read this Redux docs page:**
 * **https://redux.js.org/introduction/why-rtk-is-redux-today**
 *
 * `configureStore` from Redux Toolkit is an improved version of `createStore` that
 * simplifies setup and helps avoid common bugs.
 *
 * You should not be using the `redux` core package by itself today, except for learning purposes.
 * The `createStore` method from the core `redux` package will not be removed, but we encourage
 * all users to migrate to using Redux Toolkit for all Redux code.
 *
 * If you want to use `createStore` without this visual deprecation warning, use
 * the `legacy_createStore` import instead:
 *
 * `import { legacy_createStore as createStore} from 'redux'`
 *
 */ function createStore(reducer, preloadedState, enhancer) {
    var _ref2;
    if (typeof preloadedState === 'function' && typeof enhancer === 'function' || typeof enhancer === 'function' && typeof arguments[3] === 'function') {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'It looks like you are passing several store enhancers to ' + 'createStore(). This is not supported. Instead, compose them ' + 'together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example.');
    }
    if (typeof preloadedState === 'function' && typeof enhancer === 'undefined') {
        enhancer = preloadedState;
        preloadedState = undefined;
    }
    if (typeof enhancer !== 'undefined') {
        if (typeof enhancer !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the enhancer to be a function. Instead, received: '" + kindOf(enhancer) + "'");
        }
        return enhancer(createStore)(reducer, preloadedState);
    }
    if (typeof reducer !== 'function') {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the root reducer to be a function. Instead, received: '" + kindOf(reducer) + "'");
    }
    var currentReducer = reducer;
    var currentState = preloadedState;
    var currentListeners = [];
    var nextListeners = currentListeners;
    var isDispatching = false;
    /**
   * This makes a shallow copy of currentListeners so we can use
   * nextListeners as a temporary list while dispatching.
   *
   * This prevents any bugs around consumers calling
   * subscribe/unsubscribe in the middle of a dispatch.
   */ function ensureCanMutateNextListeners() {
        if (nextListeners === currentListeners) {
            nextListeners = currentListeners.slice();
        }
    }
    /**
   * Reads the state tree managed by the store.
   *
   * @returns {any} The current state tree of your application.
   */ function getState() {
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not call store.getState() while the reducer is executing. ' + 'The reducer has already received the state as an argument. ' + 'Pass it down from the top reducer instead of reading it from the store.');
        }
        return currentState;
    }
    /**
   * Adds a change listener. It will be called any time an action is dispatched,
   * and some part of the state tree may potentially have changed. You may then
   * call `getState()` to read the current state tree inside the callback.
   *
   * You may call `dispatch()` from a change listener, with the following
   * caveats:
   *
   * 1. The subscriptions are snapshotted just before every `dispatch()` call.
   * If you subscribe or unsubscribe while the listeners are being invoked, this
   * will not have any effect on the `dispatch()` that is currently in progress.
   * However, the next `dispatch()` call, whether nested or not, will use a more
   * recent snapshot of the subscription list.
   *
   * 2. The listener should not expect to see all state changes, as the state
   * might have been updated multiple times during a nested `dispatch()` before
   * the listener is called. It is, however, guaranteed that all subscribers
   * registered before the `dispatch()` started will be called with the latest
   * state by the time it exits.
   *
   * @param {Function} listener A callback to be invoked on every dispatch.
   * @returns {Function} A function to remove this change listener.
   */ function subscribe(listener) {
        if (typeof listener !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the listener to be a function. Instead, received: '" + kindOf(listener) + "'");
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not call store.subscribe() while the reducer is executing. ' + 'If you would like to be notified after the store has been updated, subscribe from a ' + 'component and invoke store.getState() in the callback to access the latest state. ' + 'See https://redux.js.org/api/store#subscribelistener for more details.');
        }
        var isSubscribed = true;
        ensureCanMutateNextListeners();
        nextListeners.push(listener);
        return function unsubscribe() {
            if (!isSubscribed) {
                return;
            }
            if (isDispatching) {
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'You may not unsubscribe from a store listener while the reducer is executing. ' + 'See https://redux.js.org/api/store#subscribelistener for more details.');
            }
            isSubscribed = false;
            ensureCanMutateNextListeners();
            var index = nextListeners.indexOf(listener);
            nextListeners.splice(index, 1);
            currentListeners = null;
        };
    }
    /**
   * Dispatches an action. It is the only way to trigger a state change.
   *
   * The `reducer` function, used to create the store, will be called with the
   * current state tree and the given `action`. Its return value will
   * be considered the **next** state of the tree, and the change listeners
   * will be notified.
   *
   * The base implementation only supports plain object actions. If you want to
   * dispatch a Promise, an Observable, a thunk, or something else, you need to
   * wrap your store creating function into the corresponding middleware. For
   * example, see the documentation for the `redux-thunk` package. Even the
   * middleware will eventually dispatch plain object actions using this method.
   *
   * @param {Object} action A plain object representing “what changed”. It is
   * a good idea to keep actions serializable so you can record and replay user
   * sessions, or use the time travelling `redux-devtools`. An action must have
   * a `type` property which may not be `undefined`. It is a good idea to use
   * string constants for action types.
   *
   * @returns {Object} For convenience, the same action object you dispatched.
   *
   * Note that, if you use a custom middleware, it may wrap `dispatch()` to
   * return something else (for example, a Promise you can await).
   */ function dispatch(action) {
        if (!isPlainObject(action)) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Actions must be plain objects. Instead, the actual type was: '" + kindOf(action) + "'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples.");
        }
        if (typeof action.type === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Actions may not have an undefined "type" property. You may have misspelled an action type string constant.');
        }
        if (isDispatching) {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Reducers may not dispatch actions.');
        }
        try {
            isDispatching = true;
            currentState = currentReducer(currentState, action);
        } finally{
            isDispatching = false;
        }
        var listeners = currentListeners = nextListeners;
        for(var i = 0; i < listeners.length; i++){
            var listener = listeners[i];
            listener();
        }
        return action;
    }
    /**
   * Replaces the reducer currently used by the store to calculate the state.
   *
   * You might need this if your app implements code splitting and you want to
   * load some of the reducers dynamically. You might also need this if you
   * implement a hot reloading mechanism for Redux.
   *
   * @param {Function} nextReducer The reducer for the store to use instead.
   * @returns {void}
   */ function replaceReducer(nextReducer) {
        if (typeof nextReducer !== 'function') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the nextReducer to be a function. Instead, received: '" + kindOf(nextReducer));
        }
        currentReducer = nextReducer; // This action has a similiar effect to ActionTypes.INIT.
        // Any reducers that existed in both the new and old rootReducer
        // will receive the previous state. This effectively populates
        // the new state tree with any relevant data from the old one.
        dispatch({
            type: ActionTypes.REPLACE
        });
    }
    /**
   * Interoperability point for observable/reactive libraries.
   * @returns {observable} A minimal observable of state changes.
   * For more information, see the observable proposal:
   * https://github.com/tc39/proposal-observable
   */ function observable() {
        var _ref;
        var outerSubscribe = subscribe;
        return _ref = {
            /**
       * The minimal observable subscription method.
       * @param {Object} observer Any object that can be used as an observer.
       * The observer object should have a `next` method.
       * @returns {subscription} An object with an `unsubscribe` method that can
       * be used to unsubscribe the observable from the store, and prevent further
       * emission of values from the observable.
       */ subscribe: function subscribe(observer) {
                if (typeof observer !== 'object' || observer === null) {
                    throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "Expected the observer to be an object. Instead, received: '" + kindOf(observer) + "'");
                }
                function observeState() {
                    if (observer.next) {
                        observer.next(getState());
                    }
                }
                observeState();
                var unsubscribe = outerSubscribe(observeState);
                return {
                    unsubscribe: unsubscribe
                };
            }
        }, _ref[$$observable] = function() {
            return this;
        }, _ref;
    } // When a store is created, an "INIT" action is dispatched so that every
    // reducer returns their initial state. This effectively populates
    // the initial state tree.
    dispatch({
        type: ActionTypes.INIT
    });
    return _ref2 = {
        dispatch: dispatch,
        subscribe: subscribe,
        getState: getState,
        replaceReducer: replaceReducer
    }, _ref2[$$observable] = observable, _ref2;
}
/**
 * Creates a Redux store that holds the state tree.
 *
 * **We recommend using `configureStore` from the
 * `@reduxjs/toolkit` package**, which replaces `createStore`:
 * **https://redux.js.org/introduction/why-rtk-is-redux-today**
 *
 * The only way to change the data in the store is to call `dispatch()` on it.
 *
 * There should only be a single store in your app. To specify how different
 * parts of the state tree respond to actions, you may combine several reducers
 * into a single reducer function by using `combineReducers`.
 *
 * @param {Function} reducer A function that returns the next state tree, given
 * the current state tree and the action to handle.
 *
 * @param {any} [preloadedState] The initial state. You may optionally specify it
 * to hydrate the state from the server in universal apps, or to restore a
 * previously serialized user session.
 * If you use `combineReducers` to produce the root reducer function, this must be
 * an object with the same shape as `combineReducers` keys.
 *
 * @param {Function} [enhancer] The store enhancer. You may optionally specify it
 * to enhance the store with third-party capabilities such as middleware,
 * time travel, persistence, etc. The only store enhancer that ships with Redux
 * is `applyMiddleware()`.
 *
 * @returns {Store} A Redux store that lets you read the state, dispatch actions
 * and subscribe to changes.
 */ var legacy_createStore = createStore;
/**
 * Prints a warning in the console if it exists.
 *
 * @param {String} message The warning message.
 * @returns {void}
 */ function warning(message) {
    /* eslint-disable no-console */ if (typeof console !== 'undefined' && typeof console.error === 'function') {
        console.error(message);
    }
    /* eslint-enable no-console */ try {
        // This error was thrown as a convenience so that if you enable
        // "break on all exceptions" in your console,
        // it would pause the execution at this line.
        throw new Error(message);
    } catch (e) {} // eslint-disable-line no-empty
}
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
    var reducerKeys = Object.keys(reducers);
    var argumentName = action && action.type === ActionTypes.INIT ? 'preloadedState argument passed to createStore' : 'previous state received by the reducer';
    if (reducerKeys.length === 0) {
        return 'Store does not have a valid reducer. Make sure the argument passed ' + 'to combineReducers is an object whose values are reducers.';
    }
    if (!isPlainObject(inputState)) {
        return "The " + argumentName + " has unexpected type of \"" + kindOf(inputState) + "\". Expected argument to be an object with the following " + ("keys: \"" + reducerKeys.join('", "') + "\"");
    }
    var unexpectedKeys = Object.keys(inputState).filter(function(key) {
        return !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key];
    });
    unexpectedKeys.forEach(function(key) {
        unexpectedKeyCache[key] = true;
    });
    if (action && action.type === ActionTypes.REPLACE) return;
    if (unexpectedKeys.length > 0) {
        return "Unexpected " + (unexpectedKeys.length > 1 ? 'keys' : 'key') + " " + ("\"" + unexpectedKeys.join('", "') + "\" found in " + argumentName + ". ") + "Expected to find one of the known reducer keys instead: " + ("\"" + reducerKeys.join('", "') + "\". Unexpected keys will be ignored.");
    }
}
function assertReducerShape(reducers) {
    Object.keys(reducers).forEach(function(key) {
        var reducer = reducers[key];
        var initialState = reducer(undefined, {
            type: ActionTypes.INIT
        });
        if (typeof initialState === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "The slice reducer for key \"" + key + "\" returned undefined during initialization. " + "If the state passed to the reducer is undefined, you must " + "explicitly return the initial state. The initial state may " + "not be undefined. If you don't want to set a value for this reducer, " + "you can use null instead of undefined.");
        }
        if (typeof reducer(undefined, {
            type: ActionTypes.PROBE_UNKNOWN_ACTION()
        }) === 'undefined') {
            throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "The slice reducer for key \"" + key + "\" returned undefined when probed with a random type. " + ("Don't try to handle '" + ActionTypes.INIT + "' or other actions in \"redux/*\" ") + "namespace. They are considered private. Instead, you must return the " + "current state for any unknown actions, unless it is undefined, " + "in which case you must return the initial state, regardless of the " + "action type. The initial state may not be undefined, but can be null.");
        }
    });
}
/**
 * Turns an object whose values are different reducer functions, into a single
 * reducer function. It will call every child reducer, and gather their results
 * into a single state object, whose keys correspond to the keys of the passed
 * reducer functions.
 *
 * @param {Object} reducers An object whose values correspond to different
 * reducer functions that need to be combined into one. One handy way to obtain
 * it is to use ES6 `import * as reducers` syntax. The reducers may never return
 * undefined for any action. Instead, they should return their initial state
 * if the state passed to them was undefined, and the current state for any
 * unrecognized action.
 *
 * @returns {Function} A reducer function that invokes every reducer inside the
 * passed object, and builds a state object with the same shape.
 */ function combineReducers(reducers) {
    var reducerKeys = Object.keys(reducers);
    var finalReducers = {};
    for(var i = 0; i < reducerKeys.length; i++){
        var key = reducerKeys[i];
        if ("TURBOPACK compile-time truthy", 1) {
            if (typeof reducers[key] === 'undefined') {
                warning("No reducer provided for key \"" + key + "\"");
            }
        }
        if (typeof reducers[key] === 'function') {
            finalReducers[key] = reducers[key];
        }
    }
    var finalReducerKeys = Object.keys(finalReducers); // This is used to make sure we don't warn about the same
    // keys multiple times.
    var unexpectedKeyCache;
    if (("TURBOPACK compile-time value", "development") !== 'production') {
        unexpectedKeyCache = {};
    }
    var shapeAssertionError;
    try {
        assertReducerShape(finalReducers);
    } catch (e) {
        shapeAssertionError = e;
    }
    return function combination(state, action) {
        if (state === void 0) {
            state = {};
        }
        if (shapeAssertionError) {
            throw shapeAssertionError;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            var warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
            if (warningMessage) {
                warning(warningMessage);
            }
        }
        var hasChanged = false;
        var nextState = {};
        for(var _i = 0; _i < finalReducerKeys.length; _i++){
            var _key = finalReducerKeys[_i];
            var reducer = finalReducers[_key];
            var previousStateForKey = state[_key];
            var nextStateForKey = reducer(previousStateForKey, action);
            if (typeof nextStateForKey === 'undefined') {
                var actionType = action && action.type;
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "When called with an action of type " + (actionType ? "\"" + String(actionType) + "\"" : '(unknown type)') + ", the slice reducer for key \"" + _key + "\" returned undefined. " + "To ignore an action, you must explicitly return the previous state. " + "If you want this reducer to hold no value, you can return null instead of undefined.");
            }
            nextState[_key] = nextStateForKey;
            hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
        }
        hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
        return hasChanged ? nextState : state;
    };
}
function bindActionCreator(actionCreator, dispatch) {
    return function() {
        return dispatch(actionCreator.apply(this, arguments));
    };
}
/**
 * Turns an object whose values are action creators, into an object with the
 * same keys, but with every function wrapped into a `dispatch` call so they
 * may be invoked directly. This is just a convenience method, as you can call
 * `store.dispatch(MyActionCreators.doSomething())` yourself just fine.
 *
 * For convenience, you can also pass an action creator as the first argument,
 * and get a dispatch wrapped function in return.
 *
 * @param {Function|Object} actionCreators An object whose values are action
 * creator functions. One handy way to obtain it is to use ES6 `import * as`
 * syntax. You may also pass a single function.
 *
 * @param {Function} dispatch The `dispatch` function available on your Redux
 * store.
 *
 * @returns {Function|Object} The object mimicking the original object, but with
 * every action creator wrapped into the `dispatch` call. If you passed a
 * function as `actionCreators`, the return value will also be a single
 * function.
 */ function bindActionCreators(actionCreators, dispatch) {
    if (typeof actionCreators === 'function') {
        return bindActionCreator(actionCreators, dispatch);
    }
    if (typeof actionCreators !== 'object' || actionCreators === null) {
        throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "bindActionCreators expected an object or a function, but instead received: '" + kindOf(actionCreators) + "'. " + "Did you write \"import ActionCreators from\" instead of \"import * as ActionCreators from\"?");
    }
    var boundActionCreators = {};
    for(var key in actionCreators){
        var actionCreator = actionCreators[key];
        if (typeof actionCreator === 'function') {
            boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
        }
    }
    return boundActionCreators;
}
/**
 * Composes single-argument functions from right to left. The rightmost
 * function can take multiple arguments as it provides the signature for
 * the resulting composite function.
 *
 * @param {...Function} funcs The functions to compose.
 * @returns {Function} A function obtained by composing the argument functions
 * from right to left. For example, compose(f, g, h) is identical to doing
 * (...args) => f(g(h(...args))).
 */ function compose() {
    for(var _len = arguments.length, funcs = new Array(_len), _key = 0; _key < _len; _key++){
        funcs[_key] = arguments[_key];
    }
    if (funcs.length === 0) {
        return function(arg) {
            return arg;
        };
    }
    if (funcs.length === 1) {
        return funcs[0];
    }
    return funcs.reduce(function(a, b) {
        return function() {
            return a(b.apply(void 0, arguments));
        };
    });
}
/**
 * Creates a store enhancer that applies middleware to the dispatch method
 * of the Redux store. This is handy for a variety of tasks, such as expressing
 * asynchronous actions in a concise manner, or logging every action payload.
 *
 * See `redux-thunk` package as an example of the Redux middleware.
 *
 * Because middleware is potentially asynchronous, this should be the first
 * store enhancer in the composition chain.
 *
 * Note that each middleware will be given the `dispatch` and `getState` functions
 * as named arguments.
 *
 * @param {...Function} middlewares The middleware chain to be applied.
 * @returns {Function} A store enhancer applying the middleware.
 */ function applyMiddleware() {
    for(var _len = arguments.length, middlewares = new Array(_len), _key = 0; _key < _len; _key++){
        middlewares[_key] = arguments[_key];
    }
    return function(createStore) {
        return function() {
            var store = createStore.apply(void 0, arguments);
            var _dispatch = function dispatch() {
                throw new Error(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'Dispatching while constructing your middleware is not allowed. ' + 'Other middleware would not be applied to this dispatch.');
            };
            var middlewareAPI = {
                getState: store.getState,
                dispatch: function dispatch() {
                    return _dispatch.apply(void 0, arguments);
                }
            };
            var chain = middlewares.map(function(middleware) {
                return middleware(middlewareAPI);
            });
            _dispatch = compose.apply(void 0, chain)(store.dispatch);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$babel$2b$runtime$40$7$2e$28$2e$2$2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectSpread2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, store), {}, {
                dispatch: _dispatch
            });
        };
    };
}
/*
 * This is a dummy function to check if the function name has been altered by minification.
 * If the function has been minified and NODE_ENV !== 'production', warn the user.
 */ function isCrushed() {}
if (("TURBOPACK compile-time value", "development") !== 'production' && typeof isCrushed.name === 'string' && isCrushed.name !== 'isCrushed') {
    warning('You are currently using minified code outside of NODE_ENV === "production". ' + 'This means that you are running a slower development build of Redux. ' + 'You can use loose-envify (https://github.com/zertosh/loose-envify) for browserify ' + 'or setting mode to production in webpack (https://webpack.js.org/concepts/mode/) ' + 'to ensure you have the correct code for your production build.');
}
;
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "BEGIN_DRAG": ()=>BEGIN_DRAG,
    "DROP": ()=>DROP,
    "END_DRAG": ()=>END_DRAG,
    "HOVER": ()=>HOVER,
    "INIT_COORDS": ()=>INIT_COORDS,
    "PUBLISH_DRAG_SOURCE": ()=>PUBLISH_DRAG_SOURCE
});
var INIT_COORDS = 'dnd-core/INIT_COORDS';
var BEGIN_DRAG = 'dnd-core/BEGIN_DRAG';
var PUBLISH_DRAG_SOURCE = 'dnd-core/PUBLISH_DRAG_SOURCE';
var HOVER = 'dnd-core/HOVER';
var DROP = 'dnd-core/DROP';
var END_DRAG = 'dnd-core/END_DRAG';
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/local/setClientOffset.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "setClientOffset": ()=>setClientOffset
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
;
function setClientOffset(clientOffset, sourceClientOffset) {
    return {
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"],
        payload: {
            sourceClientOffset: sourceClientOffset || null,
            clientOffset: clientOffset || null
        }
    };
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "get": ()=>get,
    "intersection": ()=>intersection,
    "isObject": ()=>isObject,
    "isString": ()=>isString,
    "without": ()=>without,
    "xor": ()=>xor
});
function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}
function get(obj, path, defaultValue) {
    return path.split('.').reduce(function(a, c) {
        return a && a[c] ? a[c] : defaultValue || null;
    }, obj);
}
function without(items, item) {
    return items.filter(function(i) {
        return i !== item;
    });
}
function isString(input) {
    return typeof input === 'string';
}
function isObject(input) {
    return _typeof(input) === 'object';
}
function xor(itemsA, itemsB) {
    var map = new Map();
    var insertItem = function insertItem(item) {
        map.set(item, map.has(item) ? map.get(item) + 1 : 1);
    };
    itemsA.forEach(insertItem);
    itemsB.forEach(insertItem);
    var result = [];
    map.forEach(function(count, key) {
        if (count === 1) {
            result.push(key);
        }
    });
    return result;
}
function intersection(itemsA, itemsB) {
    return itemsA.filter(function(t) {
        return itemsB.indexOf(t) > -1;
    });
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/beginDrag.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createBeginDrag": ()=>createBeginDrag
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/local/setClientOffset.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
;
;
var ResetCoordinatesAction = {
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"],
    payload: {
        clientOffset: null,
        sourceClientOffset: null
    }
};
function createBeginDrag(manager) {
    return function beginDrag() {
        var sourceIds = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
            publishSource: true
        };
        var _options$publishSourc = options.publishSource, publishSource = _options$publishSourc === void 0 ? true : _options$publishSourc, clientOffset = options.clientOffset, getSourceClientOffset = options.getSourceClientOffset;
        var monitor = manager.getMonitor();
        var registry = manager.getRegistry(); // Initialize the coordinates using the client offset
        manager.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setClientOffset"])(clientOffset));
        verifyInvariants(sourceIds, monitor, registry); // Get the draggable source
        var sourceId = getDraggableSource(sourceIds, monitor);
        if (sourceId === null) {
            manager.dispatch(ResetCoordinatesAction);
            return;
        } // Get the source client offset
        var sourceClientOffset = null;
        if (clientOffset) {
            if (!getSourceClientOffset) {
                throw new Error('getSourceClientOffset must be defined');
            }
            verifyGetSourceClientOffsetIsFunction(getSourceClientOffset);
            sourceClientOffset = getSourceClientOffset(sourceId);
        } // Initialize the full coordinates
        manager.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$local$2f$setClientOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setClientOffset"])(clientOffset, sourceClientOffset));
        var source = registry.getSource(sourceId);
        var item = source.beginDrag(monitor, sourceId); // If source.beginDrag returns null, this is an indicator to cancel the drag
        if (item == null) {
            return undefined;
        }
        verifyItemIsObject(item);
        registry.pinSource(sourceId);
        var itemType = registry.getSourceType(sourceId);
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"],
            payload: {
                itemType: itemType,
                item: item,
                sourceId: sourceId,
                clientOffset: clientOffset || null,
                sourceClientOffset: sourceClientOffset || null,
                isSourcePublic: !!publishSource
            }
        };
    };
}
function verifyInvariants(sourceIds, monitor, registry) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.isDragging(), 'Cannot call beginDrag while dragging.');
    sourceIds.forEach(function(sourceId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(registry.getSource(sourceId), 'Expected sourceIds to be registered.');
    });
}
function verifyGetSourceClientOffsetIsFunction(getSourceClientOffset) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof getSourceClientOffset === 'function', 'When clientOffset is provided, getSourceClientOffset must be a function.');
}
function verifyItemIsObject(item) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(item), 'Item must be an object.');
}
function getDraggableSource(sourceIds, monitor) {
    var sourceId = null;
    for(var i = sourceIds.length - 1; i >= 0; i--){
        if (monitor.canDragSource(sourceIds[i])) {
            sourceId = sourceIds[i];
            break;
        }
    }
    return sourceId;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/publishDragSource.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createPublishDragSource": ()=>createPublishDragSource
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
;
function createPublishDragSource(manager) {
    return function publishDragSource() {
        var monitor = manager.getMonitor();
        if (monitor.isDragging()) {
            return {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]
            };
        }
    };
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/matchesType.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "matchesType": ()=>matchesType
});
function matchesType(targetType, draggedItemType) {
    if (draggedItemType === null) {
        return targetType === null;
    }
    return Array.isArray(targetType) ? targetType.some(function(t) {
        return t === draggedItemType;
    }) : targetType === draggedItemType;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/hover.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createHover": ()=>createHover
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/matchesType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
;
function createHover(manager) {
    return function hover(targetIdsArg) {
        var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {}, clientOffset = _ref.clientOffset;
        verifyTargetIdsIsArray(targetIdsArg);
        var targetIds = targetIdsArg.slice(0);
        var monitor = manager.getMonitor();
        var registry = manager.getRegistry();
        checkInvariants(targetIds, monitor, registry);
        var draggedItemType = monitor.getItemType();
        removeNonMatchingTargetIds(targetIds, registry, draggedItemType);
        hoverAllTargets(targetIds, monitor, registry);
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"],
            payload: {
                targetIds: targetIds,
                clientOffset: clientOffset || null
            }
        };
    };
}
function verifyTargetIdsIsArray(targetIdsArg) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(Array.isArray(targetIdsArg), 'Expected targetIds to be an array.');
}
function checkInvariants(targetIds, monitor, registry) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call hover while not dragging.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.didDrop(), 'Cannot call hover after drop.');
    for(var i = 0; i < targetIds.length; i++){
        var targetId = targetIds[i];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(targetIds.lastIndexOf(targetId) === i, 'Expected targetIds to be unique in the passed array.');
        var target = registry.getTarget(targetId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(target, 'Expected targetIds to be registered.');
    }
}
function removeNonMatchingTargetIds(targetIds, registry, draggedItemType) {
    // Remove those targetIds that don't match the targetType.  This
    // fixes shallow isOver which would only be non-shallow because of
    // non-matching targets.
    for(var i = targetIds.length - 1; i >= 0; i--){
        var targetId = targetIds[i];
        var targetType = registry.getTargetType(targetId);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType)) {
            targetIds.splice(i, 1);
        }
    }
}
function hoverAllTargets(targetIds, monitor, registry) {
    // Finally call hover on all matching targets.
    targetIds.forEach(function(targetId) {
        var target = registry.getTarget(targetId);
        target.hover(monitor, targetId);
    });
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/drop.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createDrop": ()=>createDrop
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
            ownKeys(Object(source), true).forEach(function(key) {
                _defineProperty(target, key, source[key]);
            });
        } else if (Object.getOwnPropertyDescriptors) {
            Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
            ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
            });
        }
    }
    return target;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
function createDrop(manager) {
    return function drop() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var monitor = manager.getMonitor();
        var registry = manager.getRegistry();
        verifyInvariants(monitor);
        var targetIds = getDroppableTargets(monitor); // Multiple actions are dispatched here, which is why this doesn't return an action
        targetIds.forEach(function(targetId, index) {
            var dropResult = determineDropResult(targetId, index, registry, monitor);
            var action = {
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"],
                payload: {
                    dropResult: _objectSpread(_objectSpread({}, options), dropResult)
                }
            };
            manager.dispatch(action);
        });
    };
}
function verifyInvariants(monitor) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call drop while not dragging.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!monitor.didDrop(), 'Cannot call drop twice during one drag operation.');
}
function determineDropResult(targetId, index, registry, monitor) {
    var target = registry.getTarget(targetId);
    var dropResult = target ? target.drop(monitor, targetId) : undefined;
    verifyDropResultType(dropResult);
    if (typeof dropResult === 'undefined') {
        dropResult = index === 0 ? {} : monitor.getDropResult();
    }
    return dropResult;
}
function verifyDropResultType(dropResult) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof dropResult === 'undefined' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(dropResult), 'Drop result must either be an object or undefined.');
}
function getDroppableTargets(monitor) {
    var targetIds = monitor.getTargetIds().filter(monitor.canDropOnTarget, monitor);
    targetIds.reverse();
    return targetIds;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/endDrag.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createEndDrag": ()=>createEndDrag
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
;
;
function createEndDrag(manager) {
    return function endDrag() {
        var monitor = manager.getMonitor();
        var registry = manager.getRegistry();
        verifyIsDragging(monitor);
        var sourceId = monitor.getSourceId();
        if (sourceId != null) {
            var source = registry.getSource(sourceId, true);
            source.endDrag(monitor, sourceId);
            registry.unpinSource();
        }
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]
        };
    };
}
function verifyIsDragging(monitor) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(monitor.isDragging(), 'Cannot call endDrag while not dragging.');
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createDragDropActions": ()=>createDragDropActions
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$beginDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/beginDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$publishDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/publishDragSource.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$hover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/hover.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/drop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$endDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/endDrag.js [app-client] (ecmascript)");
;
;
;
;
;
;
function createDragDropActions(manager) {
    return {
        beginDrag: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$beginDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBeginDrag"])(manager),
        publishDragSource: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$publishDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPublishDragSource"])(manager),
        hover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$hover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHover"])(manager),
        drop: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDrop"])(manager),
        endDrag: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$endDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEndDrag"])(manager)
    };
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/DragDropManagerImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DragDropManagerImpl": ()=>DragDropManagerImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/index.js [app-client] (ecmascript) <locals>");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
var DragDropManagerImpl = /*#__PURE__*/ function() {
    function DragDropManagerImpl(store, monitor) {
        var _this = this;
        _classCallCheck(this, DragDropManagerImpl);
        _defineProperty(this, "store", void 0);
        _defineProperty(this, "monitor", void 0);
        _defineProperty(this, "backend", void 0);
        _defineProperty(this, "isSetUp", false);
        _defineProperty(this, "handleRefCountChange", function() {
            var shouldSetUp = _this.store.getState().refCount > 0;
            if (_this.backend) {
                if (shouldSetUp && !_this.isSetUp) {
                    _this.backend.setup();
                    _this.isSetUp = true;
                } else if (!shouldSetUp && _this.isSetUp) {
                    _this.backend.teardown();
                    _this.isSetUp = false;
                }
            }
        });
        this.store = store;
        this.monitor = monitor;
        store.subscribe(this.handleRefCountChange);
    }
    _createClass(DragDropManagerImpl, [
        {
            key: "receiveBackend",
            value: function receiveBackend(backend) {
                this.backend = backend;
            }
        },
        {
            key: "getMonitor",
            value: function getMonitor() {
                return this.monitor;
            }
        },
        {
            key: "getBackend",
            value: function getBackend() {
                return this.backend;
            }
        },
        {
            key: "getRegistry",
            value: function getRegistry() {
                return this.monitor.registry;
            }
        },
        {
            key: "getActions",
            value: function getActions() {
                /* eslint-disable-next-line @typescript-eslint/no-this-alias */ var manager = this;
                var dispatch = this.store.dispatch;
                function bindActionCreator(actionCreator) {
                    return function() {
                        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                            args[_key] = arguments[_key];
                        }
                        var action = actionCreator.apply(manager, args);
                        if (typeof action !== 'undefined') {
                            dispatch(action);
                        }
                    };
                }
                var actions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createDragDropActions"])(this);
                return Object.keys(actions).reduce(function(boundActions, key) {
                    var action = actions[key];
                    boundActions[key] = bindActionCreator(action);
                    return boundActions;
                }, {});
            }
        },
        {
            key: "dispatch",
            value: function dispatch(action) {
                this.store.dispatch(action);
            }
        }
    ]);
    return DragDropManagerImpl;
}();
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/equality.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "areArraysEqual": ()=>areArraysEqual,
    "areCoordsEqual": ()=>areCoordsEqual,
    "strictEquality": ()=>strictEquality
});
var strictEquality = function strictEquality(a, b) {
    return a === b;
};
function areCoordsEqual(offsetA, offsetB) {
    if (!offsetA && !offsetB) {
        return true;
    } else if (!offsetA || !offsetB) {
        return false;
    } else {
        return offsetA.x === offsetB.x && offsetA.y === offsetB.y;
    }
}
function areArraysEqual(a, b) {
    var isEqual = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : strictEquality;
    if (a.length !== b.length) {
        return false;
    }
    for(var i = 0; i < a.length; ++i){
        if (!isEqual(a[i], b[i])) {
            return false;
        }
    }
    return true;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dragOffset.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/equality.js [app-client] (ecmascript)");
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
            ownKeys(Object(source), true).forEach(function(key) {
                _defineProperty(target, key, source[key]);
            });
        } else if (Object.getOwnPropertyDescriptors) {
            Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
            ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
            });
        }
    }
    return target;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
var initialState = {
    initialSourceClientOffset: null,
    initialClientOffset: null,
    clientOffset: null
};
function reduce() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
    var action = arguments.length > 1 ? arguments[1] : undefined;
    var payload = action.payload;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INIT_COORDS"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
            return {
                initialSourceClientOffset: payload.sourceClientOffset,
                initialClientOffset: payload.clientOffset,
                clientOffset: payload.clientOffset
            };
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areCoordsEqual"])(state.clientOffset, payload.clientOffset)) {
                return state;
            }
            return _objectSpread(_objectSpread({}, state), {}, {
                clientOffset: payload.clientOffset
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
            return initialState;
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "ADD_SOURCE": ()=>ADD_SOURCE,
    "ADD_TARGET": ()=>ADD_TARGET,
    "REMOVE_SOURCE": ()=>REMOVE_SOURCE,
    "REMOVE_TARGET": ()=>REMOVE_TARGET,
    "addSource": ()=>addSource,
    "addTarget": ()=>addTarget,
    "removeSource": ()=>removeSource,
    "removeTarget": ()=>removeTarget
});
var ADD_SOURCE = 'dnd-core/ADD_SOURCE';
var ADD_TARGET = 'dnd-core/ADD_TARGET';
var REMOVE_SOURCE = 'dnd-core/REMOVE_SOURCE';
var REMOVE_TARGET = 'dnd-core/REMOVE_TARGET';
function addSource(sourceId) {
    return {
        type: ADD_SOURCE,
        payload: {
            sourceId: sourceId
        }
    };
}
function addTarget(targetId) {
    return {
        type: ADD_TARGET,
        payload: {
            targetId: targetId
        }
    };
}
function removeSource(sourceId) {
    return {
        type: REMOVE_SOURCE,
        payload: {
            sourceId: sourceId
        }
    };
}
function removeTarget(targetId) {
    return {
        type: REMOVE_TARGET,
        payload: {
            targetId: targetId
        }
    };
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dragOperation.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
            ownKeys(Object(source), true).forEach(function(key) {
                _defineProperty(target, key, source[key]);
            });
        } else if (Object.getOwnPropertyDescriptors) {
            Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
            ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
            });
        }
    }
    return target;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
var initialState = {
    itemType: null,
    item: null,
    sourceId: null,
    targetIds: [],
    dropResult: null,
    didDrop: false,
    isSourcePublic: null
};
function reduce() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
    var action = arguments.length > 1 ? arguments[1] : undefined;
    var payload = action.payload;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
            return _objectSpread(_objectSpread({}, state), {}, {
                itemType: payload.itemType,
                item: payload.item,
                sourceId: payload.sourceId,
                isSourcePublic: payload.isSourcePublic,
                dropResult: null,
                didDrop: false
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]:
            return _objectSpread(_objectSpread({}, state), {}, {
                isSourcePublic: true
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            return _objectSpread(_objectSpread({}, state), {}, {
                targetIds: payload.targetIds
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
            if (state.targetIds.indexOf(payload.targetId) === -1) {
                return state;
            }
            return _objectSpread(_objectSpread({}, state), {}, {
                targetIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["without"])(state.targetIds, payload.targetId)
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
            return _objectSpread(_objectSpread({}, state), {}, {
                dropResult: payload.dropResult,
                didDrop: true,
                targetIds: []
            });
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
            return _objectSpread(_objectSpread({}, state), {}, {
                itemType: null,
                item: null,
                sourceId: null,
                dropResult: null,
                didDrop: false,
                isSourcePublic: null,
                targetIds: []
            });
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/refCount.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/registry.js [app-client] (ecmascript)");
;
function reduce() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    var action = arguments.length > 1 ? arguments[1] : undefined;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_TARGET"]:
            return state + 1;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
            return state - 1;
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/dirtiness.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "ALL": ()=>ALL,
    "NONE": ()=>NONE,
    "areDirty": ()=>areDirty
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
;
var NONE = [];
var ALL = [];
NONE.__IS_NONE__ = true;
ALL.__IS_ALL__ = true;
function areDirty(dirtyIds, handlerIds) {
    if (dirtyIds === NONE) {
        return false;
    }
    if (dirtyIds === ALL || typeof handlerIds === 'undefined') {
        return true;
    }
    var commonIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["intersection"])(handlerIds, dirtyIds);
    return commonIds.length > 0;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dirtyHandlerIds.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/dragDrop/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/equality.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/dirtiness.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
;
;
;
;
;
function reduce() {
    var _state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"];
    var action = arguments.length > 1 ? arguments[1] : undefined;
    switch(action.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOVER"]:
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ADD_TARGET"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_TARGET"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REMOVE_SOURCE"]:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BEGIN_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLISH_DRAG_SOURCE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["END_DRAG"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$dragDrop$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP"]:
        default:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ALL"];
    }
    var _action$payload = action.payload, _action$payload$targe = _action$payload.targetIds, targetIds = _action$payload$targe === void 0 ? [] : _action$payload$targe, _action$payload$prevT = _action$payload.prevTargetIds, prevTargetIds = _action$payload$prevT === void 0 ? [] : _action$payload$prevT;
    var result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xor"])(targetIds, prevTargetIds);
    var didChange = result.length > 0 || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$equality$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areArraysEqual"])(targetIds, prevTargetIds);
    if (!didChange) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NONE"];
    } // Check the target ids at the innermost position. If they are valid, add them
    // to the result
    var prevInnermostTargetId = prevTargetIds[prevTargetIds.length - 1];
    var innermostTargetId = targetIds[targetIds.length - 1];
    if (prevInnermostTargetId !== innermostTargetId) {
        if (prevInnermostTargetId) {
            result.push(prevInnermostTargetId);
        }
        if (innermostTargetId) {
            result.push(innermostTargetId);
        }
    }
    return result;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/stateId.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
function reduce() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    return state + 1;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reduce": ()=>reduce
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dragOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dragOffset.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dragOperation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dragOperation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$refCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/refCount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dirtyHandlerIds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/dirtyHandlerIds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$stateId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/stateId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/js_utils.js [app-client] (ecmascript)");
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
            symbols = symbols.filter(function(sym) {
                return Object.getOwnPropertyDescriptor(object, sym).enumerable;
            });
        }
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
            ownKeys(Object(source), true).forEach(function(key) {
                _defineProperty(target, key, source[key]);
            });
        } else if (Object.getOwnPropertyDescriptors) {
            Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
            ownKeys(Object(source)).forEach(function(key) {
                Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
            });
        }
    }
    return target;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
;
;
;
function reduce() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var action = arguments.length > 1 ? arguments[1] : undefined;
    return {
        dirtyHandlerIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dirtyHandlerIds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dirtyHandlerIds, {
            type: action.type,
            payload: _objectSpread(_objectSpread({}, action.payload), {}, {
                prevTargetIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$js_utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["get"])(state, 'dragOperation.targetIds', [])
            })
        }),
        dragOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dragOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dragOffset, action),
        refCount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$refCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.refCount, action),
        dragOperation: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$dragOperation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.dragOperation, action),
        stateId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$stateId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"])(state.stateId)
    };
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/coords.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

/**
 * Coordinate addition
 * @param a The first coordinate
 * @param b The second coordinate
 */ __turbopack_context__.s({
    "add": ()=>add,
    "getDifferenceFromInitialOffset": ()=>getDifferenceFromInitialOffset,
    "getSourceClientOffset": ()=>getSourceClientOffset,
    "subtract": ()=>subtract
});
function add(a, b) {
    return {
        x: a.x + b.x,
        y: a.y + b.y
    };
}
function subtract(a, b) {
    return {
        x: a.x - b.x,
        y: a.y - b.y
    };
}
function getSourceClientOffset(state) {
    var clientOffset = state.clientOffset, initialClientOffset = state.initialClientOffset, initialSourceClientOffset = state.initialSourceClientOffset;
    if (!clientOffset || !initialClientOffset || !initialSourceClientOffset) {
        return null;
    }
    return subtract(add(clientOffset, initialSourceClientOffset), initialClientOffset);
}
function getDifferenceFromInitialOffset(state) {
    var clientOffset = state.clientOffset, initialClientOffset = state.initialClientOffset;
    if (!clientOffset || !initialClientOffset) {
        return null;
    }
    return subtract(clientOffset, initialClientOffset);
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/DragDropMonitorImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DragDropMonitorImpl": ()=>DragDropMonitorImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/matchesType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/coords.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/dirtiness.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
;
var DragDropMonitorImpl = /*#__PURE__*/ function() {
    function DragDropMonitorImpl(store, registry) {
        _classCallCheck(this, DragDropMonitorImpl);
        _defineProperty(this, "store", void 0);
        _defineProperty(this, "registry", void 0);
        this.store = store;
        this.registry = registry;
    }
    _createClass(DragDropMonitorImpl, [
        {
            key: "subscribeToStateChange",
            value: function subscribeToStateChange(listener) {
                var _this = this;
                var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
                    handlerIds: undefined
                };
                var handlerIds = options.handlerIds;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof listener === 'function', 'listener must be a function.');
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof handlerIds === 'undefined' || Array.isArray(handlerIds), 'handlerIds, when specified, must be an array of strings.');
                var prevStateId = this.store.getState().stateId;
                var handleChange = function handleChange() {
                    var state = _this.store.getState();
                    var currentStateId = state.stateId;
                    try {
                        var canSkipListener = currentStateId === prevStateId || currentStateId === prevStateId + 1 && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$dirtiness$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["areDirty"])(state.dirtyHandlerIds, handlerIds);
                        if (!canSkipListener) {
                            listener();
                        }
                    } finally{
                        prevStateId = currentStateId;
                    }
                };
                return this.store.subscribe(handleChange);
            }
        },
        {
            key: "subscribeToOffsetChange",
            value: function subscribeToOffsetChange(listener) {
                var _this2 = this;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof listener === 'function', 'listener must be a function.');
                var previousState = this.store.getState().dragOffset;
                var handleChange = function handleChange() {
                    var nextState = _this2.store.getState().dragOffset;
                    if (nextState === previousState) {
                        return;
                    }
                    previousState = nextState;
                    listener();
                };
                return this.store.subscribe(handleChange);
            }
        },
        {
            key: "canDragSource",
            value: function canDragSource(sourceId) {
                if (!sourceId) {
                    return false;
                }
                var source = this.registry.getSource(sourceId);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, "Expected to find a valid source. sourceId=".concat(sourceId));
                if (this.isDragging()) {
                    return false;
                }
                return source.canDrag(this, sourceId);
            }
        },
        {
            key: "canDropOnTarget",
            value: function canDropOnTarget(targetId) {
                // undefined on initial render
                if (!targetId) {
                    return false;
                }
                var target = this.registry.getTarget(targetId);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(target, "Expected to find a valid target. targetId=".concat(targetId));
                if (!this.isDragging() || this.didDrop()) {
                    return false;
                }
                var targetType = this.registry.getTargetType(targetId);
                var draggedItemType = this.getItemType();
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType) && target.canDrop(this, targetId);
            }
        },
        {
            key: "isDragging",
            value: function isDragging() {
                return Boolean(this.getItemType());
            }
        },
        {
            key: "isDraggingSource",
            value: function isDraggingSource(sourceId) {
                // undefined on initial render
                if (!sourceId) {
                    return false;
                }
                var source = this.registry.getSource(sourceId, true);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, "Expected to find a valid source. sourceId=".concat(sourceId));
                if (!this.isDragging() || !this.isSourcePublic()) {
                    return false;
                }
                var sourceType = this.registry.getSourceType(sourceId);
                var draggedItemType = this.getItemType();
                if (sourceType !== draggedItemType) {
                    return false;
                }
                return source.isDragging(this, sourceId);
            }
        },
        {
            key: "isOverTarget",
            value: function isOverTarget(targetId) {
                var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
                    shallow: false
                };
                // undefined on initial render
                if (!targetId) {
                    return false;
                }
                var shallow = options.shallow;
                if (!this.isDragging()) {
                    return false;
                }
                var targetType = this.registry.getTargetType(targetId);
                var draggedItemType = this.getItemType();
                if (draggedItemType && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$matchesType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchesType"])(targetType, draggedItemType)) {
                    return false;
                }
                var targetIds = this.getTargetIds();
                if (!targetIds.length) {
                    return false;
                }
                var index = targetIds.indexOf(targetId);
                if (shallow) {
                    return index === targetIds.length - 1;
                } else {
                    return index > -1;
                }
            }
        },
        {
            key: "getItemType",
            value: function getItemType() {
                return this.store.getState().dragOperation.itemType;
            }
        },
        {
            key: "getItem",
            value: function getItem() {
                return this.store.getState().dragOperation.item;
            }
        },
        {
            key: "getSourceId",
            value: function getSourceId() {
                return this.store.getState().dragOperation.sourceId;
            }
        },
        {
            key: "getTargetIds",
            value: function getTargetIds() {
                return this.store.getState().dragOperation.targetIds;
            }
        },
        {
            key: "getDropResult",
            value: function getDropResult() {
                return this.store.getState().dragOperation.dropResult;
            }
        },
        {
            key: "didDrop",
            value: function didDrop() {
                return this.store.getState().dragOperation.didDrop;
            }
        },
        {
            key: "isSourcePublic",
            value: function isSourcePublic() {
                return Boolean(this.store.getState().dragOperation.isSourcePublic);
            }
        },
        {
            key: "getInitialClientOffset",
            value: function getInitialClientOffset() {
                return this.store.getState().dragOffset.initialClientOffset;
            }
        },
        {
            key: "getInitialSourceClientOffset",
            value: function getInitialSourceClientOffset() {
                return this.store.getState().dragOffset.initialSourceClientOffset;
            }
        },
        {
            key: "getClientOffset",
            value: function getClientOffset() {
                return this.store.getState().dragOffset.clientOffset;
            }
        },
        {
            key: "getSourceClientOffset",
            value: function getSourceClientOffset() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSourceClientOffset"])(this.store.getState().dragOffset);
            }
        },
        {
            key: "getDifferenceFromInitialOffset",
            value: function getDifferenceFromInitialOffset() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$coords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDifferenceFromInitialOffset"])(this.store.getState().dragOffset);
            }
        }
    ]);
    return DragDropMonitorImpl;
}();
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/getNextUniqueId.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "getNextUniqueId": ()=>getNextUniqueId
});
var nextUniqueId = 0;
function getNextUniqueId() {
    return nextUniqueId++;
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/interfaces.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "HandlerRole": ()=>HandlerRole
});
var HandlerRole;
(function(HandlerRole) {
    HandlerRole["SOURCE"] = "SOURCE";
    HandlerRole["TARGET"] = "TARGET";
})(HandlerRole || (HandlerRole = {}));
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/contracts.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "validateSourceContract": ()=>validateSourceContract,
    "validateTargetContract": ()=>validateTargetContract,
    "validateType": ()=>validateType
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}
;
function validateSourceContract(source) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.canDrag === 'function', 'Expected canDrag to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.beginDrag === 'function', 'Expected beginDrag to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof source.endDrag === 'function', 'Expected endDrag to be a function.');
}
function validateTargetContract(target) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.canDrop === 'function', 'Expected canDrop to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.hover === 'function', 'Expected hover to be a function.');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof target.drop === 'function', 'Expected beginDrag to be a function.');
}
function validateType(type, allowArray) {
    if (allowArray && Array.isArray(type)) {
        type.forEach(function(t) {
            return validateType(t, false);
        });
        return;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof type === 'string' || _typeof(type) === 'symbol', allowArray ? 'Type can only be a string, a symbol, or an array of either.' : 'Type can only be a string or a symbol.');
}
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/HandlerRegistryImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "HandlerRegistryImpl": ()=>HandlerRegistryImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/actions/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$getNextUniqueId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/utils/getNextUniqueId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/interfaces.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/contracts.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/index.mjs [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$asap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/asap.mjs [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
;
;
;
;
function getNextHandlerId(role) {
    var id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$utils$2f$getNextUniqueId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextUniqueId"])().toString();
    switch(role){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE:
            return "S".concat(id);
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET:
            return "T".concat(id);
        default:
            throw new Error("Unknown Handler Role: ".concat(role));
    }
}
function parseRoleFromHandlerId(handlerId) {
    switch(handlerId[0]){
        case 'S':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE;
        case 'T':
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET;
        default:
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(false, "Cannot parse handler ID: ".concat(handlerId));
    }
}
function mapContainsValue(map, searchValue) {
    var entries = map.entries();
    var isDone = false;
    do {
        var _entries$next = entries.next(), done = _entries$next.done, _entries$next$value = _slicedToArray(_entries$next.value, 2), value = _entries$next$value[1];
        if (value === searchValue) {
            return true;
        }
        isDone = !!done;
    }while (!isDone)
    return false;
}
var HandlerRegistryImpl = /*#__PURE__*/ function() {
    function HandlerRegistryImpl(store) {
        _classCallCheck(this, HandlerRegistryImpl);
        _defineProperty(this, "types", new Map());
        _defineProperty(this, "dragSources", new Map());
        _defineProperty(this, "dropTargets", new Map());
        _defineProperty(this, "pinnedSourceId", null);
        _defineProperty(this, "pinnedSource", null);
        _defineProperty(this, "store", void 0);
        this.store = store;
    }
    _createClass(HandlerRegistryImpl, [
        {
            key: "addSource",
            value: function addSource(type, source) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateType"])(type);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateSourceContract"])(source);
                var sourceId = this.addHandler(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE, type, source);
                this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addSource"])(sourceId));
                return sourceId;
            }
        },
        {
            key: "addTarget",
            value: function addTarget(type, target) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateType"])(type, true);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$contracts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateTargetContract"])(target);
                var targetId = this.addHandler(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET, type, target);
                this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addTarget"])(targetId));
                return targetId;
            }
        },
        {
            key: "containsHandler",
            value: function containsHandler(handler) {
                return mapContainsValue(this.dragSources, handler) || mapContainsValue(this.dropTargets, handler);
            }
        },
        {
            key: "getSource",
            value: function getSource(sourceId) {
                var includePinned = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isSourceId(sourceId), 'Expected a valid source ID.');
                var isPinned = includePinned && sourceId === this.pinnedSourceId;
                var source = isPinned ? this.pinnedSource : this.dragSources.get(sourceId);
                return source;
            }
        },
        {
            key: "getTarget",
            value: function getTarget(targetId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isTargetId(targetId), 'Expected a valid target ID.');
                return this.dropTargets.get(targetId);
            }
        },
        {
            key: "getSourceType",
            value: function getSourceType(sourceId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isSourceId(sourceId), 'Expected a valid source ID.');
                return this.types.get(sourceId);
            }
        },
        {
            key: "getTargetType",
            value: function getTargetType(targetId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.isTargetId(targetId), 'Expected a valid target ID.');
                return this.types.get(targetId);
            }
        },
        {
            key: "isSourceId",
            value: function isSourceId(handlerId) {
                var role = parseRoleFromHandlerId(handlerId);
                return role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE;
            }
        },
        {
            key: "isTargetId",
            value: function isTargetId(handlerId) {
                var role = parseRoleFromHandlerId(handlerId);
                return role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET;
            }
        },
        {
            key: "removeSource",
            value: function removeSource(sourceId) {
                var _this = this;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.getSource(sourceId), 'Expected an existing source.');
                this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeSource"])(sourceId));
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$asap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asap"])(function() {
                    _this.dragSources.delete(sourceId);
                    _this.types.delete(sourceId);
                });
            }
        },
        {
            key: "removeTarget",
            value: function removeTarget(targetId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.getTarget(targetId), 'Expected an existing target.');
                this.store.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$actions$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeTarget"])(targetId));
                this.dropTargets.delete(targetId);
                this.types.delete(targetId);
            }
        },
        {
            key: "pinSource",
            value: function pinSource(sourceId) {
                var source = this.getSource(sourceId);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(source, 'Expected an existing source.');
                this.pinnedSourceId = sourceId;
                this.pinnedSource = source;
            }
        },
        {
            key: "unpinSource",
            value: function unpinSource() {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(this.pinnedSource, 'No source is pinned at the time.');
                this.pinnedSourceId = null;
                this.pinnedSource = null;
            }
        },
        {
            key: "addHandler",
            value: function addHandler(role, type, handler) {
                var id = getNextHandlerId(role);
                this.types.set(id, type);
                if (role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].SOURCE) {
                    this.dragSources.set(id, handler);
                } else if (role === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$interfaces$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRole"].TARGET) {
                    this.dropTargets.set(id, handler);
                }
                return id;
            }
        }
    ]);
    return HandlerRegistryImpl;
}();
}),
"[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/createDragDropManager.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createDragDropManager": ()=>createDragDropManager
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$DragDropManagerImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/DragDropManagerImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$4$2e$2$2e$0$2f$node_modules$2f$redux$2f$es$2f$redux$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/redux@4.2.0/node_modules/redux/es/redux.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/reducers/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$DragDropMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/DragDropMonitorImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$HandlerRegistryImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/classes/HandlerRegistryImpl.js [app-client] (ecmascript)");
;
;
;
;
;
function createDragDropManager(backendFactory) {
    var globalContext = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : undefined;
    var backendOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var debugMode = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
    var store = makeStoreInstance(debugMode);
    var monitor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$DragDropMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragDropMonitorImpl"](store, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$HandlerRegistryImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HandlerRegistryImpl"](store));
    var manager = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$classes$2f$DragDropManagerImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragDropManagerImpl"](store, monitor);
    var backend = backendFactory(manager, globalContext, backendOptions);
    manager.receiveBackend(backend);
    return manager;
}
function makeStoreInstance(debugMode) {
    // TODO: if we ever make a react-native version of this,
    // we'll need to consider how to pull off dev-tooling
    var reduxDevTools = typeof window !== 'undefined' && window.__REDUX_DEVTOOLS_EXTENSION__;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$4$2e$2$2e$0$2f$node_modules$2f$redux$2f$es$2f$redux$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$reducers$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduce"], debugMode && reduxDevTools && reduxDevTools({
        name: 'dnd-core',
        instanceId: 'dnd-core'
    }));
}
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/makeRequestCall.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// Safari 6 and 6.1 for desktop, iPad, and iPhone are the only browsers that
// have WebKitMutationObserver but not un-prefixed MutationObserver.
// Must use `global` or `self` instead of `window` to work in both frames and web
// workers. `global` is a provision of Browserify, Mr, Mrs, or Mop.
/* globals self */ __turbopack_context__.s({
    "makeRequestCall": ()=>makeRequestCall,
    "makeRequestCallFromMutationObserver": ()=>makeRequestCallFromMutationObserver,
    "makeRequestCallFromTimer": ()=>makeRequestCallFromTimer
});
const scope = ("TURBOPACK compile-time truthy", 1) ? ("TURBOPACK ident replacement", globalThis) : "TURBOPACK unreachable";
const BrowserMutationObserver = scope.MutationObserver || scope.WebKitMutationObserver;
function makeRequestCallFromTimer(callback) {
    return function requestCall() {
        // We dispatch a timeout with a specified delay of 0 for engines that
        // can reliably accommodate that request. This will usually be snapped
        // to a 4 milisecond delay, but once we're flushing, there's no delay
        // between events.
        const timeoutHandle = setTimeout(handleTimer, 0);
        // However, since this timer gets frequently dropped in Firefox
        // workers, we enlist an interval handle that will try to fire
        // an event 20 times per second until it succeeds.
        const intervalHandle = setInterval(handleTimer, 50);
        function handleTimer() {
            // Whichever timer succeeds will cancel both timers and
            // execute the callback.
            clearTimeout(timeoutHandle);
            clearInterval(intervalHandle);
            callback();
        }
    };
}
function makeRequestCallFromMutationObserver(callback) {
    let toggle = 1;
    const observer = new BrowserMutationObserver(callback);
    const node = document.createTextNode('');
    observer.observe(node, {
        characterData: true
    });
    return function requestCall() {
        toggle = -toggle;
        node.data = toggle;
    };
}
const makeRequestCall = typeof BrowserMutationObserver === 'function' ? // They are implemented in all modern browsers.
//
// - Android 4-4.3
// - Chrome 26-34
// - Firefox 14-29
// - Internet Explorer 11
// - iPad Safari 6-7.1
// - iPhone Safari 7-7.1
// - Safari 6-7
makeRequestCallFromMutationObserver : // 11-12, and in web workers in many engines.
// Although message channels yield to any queued rendering and IO tasks, they
// would be better than imposing the 4ms delay of timers.
// However, they do not work reliably in Internet Explorer or Safari.
// Internet Explorer 10 is the only browser that has setImmediate but does
// not have MutationObservers.
// Although setImmediate yields to the browser's renderer, it would be
// preferrable to falling back to setTimeout since it does not have
// the minimum 4ms penalty.
// Unfortunately there appears to be a bug in Internet Explorer 10 Mobile (and
// Desktop to a lesser extent) that renders both setImmediate and
// MessageChannel useless for the purposes of ASAP.
// https://github.com/kriskowal/q/issues/396
// Timers are implemented universally.
// We fall back to timers in workers in most engines, and in foreground
// contexts in the following browsers.
// However, note that even this simple case requires nuances to operate in a
// broad spectrum of browsers.
//
// - Firefox 3-13
// - Internet Explorer 6-9
// - iPad Safari 4.3
// - Lynx 2.8.7
makeRequestCallFromTimer; //# sourceMappingURL=makeRequestCall.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/AsapQueue.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "AsapQueue": ()=>AsapQueue
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$makeRequestCall$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/makeRequestCall.mjs [app-client] (ecmascript)");
;
class AsapQueue {
    // Use the fastest means possible to execute a task in its own turn, with
    // priority over other events including IO, animation, reflow, and redraw
    // events in browsers.
    //
    // An exception thrown by a task will permanently interrupt the processing of
    // subsequent tasks. The higher level `asap` function ensures that if an
    // exception is thrown by a task, that the task queue will continue flushing as
    // soon as possible, but if you use `rawAsap` directly, you are responsible to
    // either ensure that no exceptions are thrown from your task, or to manually
    // call `rawAsap.requestFlush` if an exception is thrown.
    enqueueTask(task) {
        const { queue: q, requestFlush } = this;
        if (!q.length) {
            requestFlush();
            this.flushing = true;
        }
        // Equivalent to push, but avoids a function call.
        q[q.length] = task;
    }
    constructor(){
        this.queue = [];
        // We queue errors to ensure they are thrown in right order (FIFO).
        // Array-as-queue is good enough here, since we are just dealing with exceptions.
        this.pendingErrors = [];
        // Once a flush has been requested, no further calls to `requestFlush` are
        // necessary until the next `flush` completes.
        // @ts-ignore
        this.flushing = false;
        // The position of the next task to execute in the task queue. This is
        // preserved between calls to `flush` so that it can be resumed if
        // a task throws an exception.
        this.index = 0;
        // If a task schedules additional tasks recursively, the task queue can grow
        // unbounded. To prevent memory exhaustion, the task queue will periodically
        // truncate already-completed tasks.
        this.capacity = 1024;
        // The flush function processes all tasks that have been scheduled with
        // `rawAsap` unless and until one of those tasks throws an exception.
        // If a task throws an exception, `flush` ensures that its state will remain
        // consistent and will resume where it left off when called again.
        // However, `flush` does not make any arrangements to be called again if an
        // exception is thrown.
        this.flush = ()=>{
            const { queue: q } = this;
            while(this.index < q.length){
                const currentIndex = this.index;
                // Advance the index before calling the task. This ensures that we will
                // begin flushing on the next task the task throws an error.
                this.index++;
                q[currentIndex].call();
                // Prevent leaking memory for long chains of recursive calls to `asap`.
                // If we call `asap` within tasks scheduled by `asap`, the queue will
                // grow, but to avoid an O(n) walk for every task we execute, we don't
                // shift tasks off the queue after they have been executed.
                // Instead, we periodically shift 1024 tasks off the queue.
                if (this.index > this.capacity) {
                    // Manually shift all values starting at the index back to the
                    // beginning of the queue.
                    for(let scan = 0, newLength = q.length - this.index; scan < newLength; scan++){
                        q[scan] = q[scan + this.index];
                    }
                    q.length -= this.index;
                    this.index = 0;
                }
            }
            q.length = 0;
            this.index = 0;
            this.flushing = false;
        };
        // In a web browser, exceptions are not fatal. However, to avoid
        // slowing down the queue of pending tasks, we rethrow the error in a
        // lower priority turn.
        this.registerPendingError = (err)=>{
            this.pendingErrors.push(err);
            this.requestErrorThrow();
        };
        // `requestFlush` requests that the high priority event queue be flushed as
        // soon as possible.
        // This is useful to prevent an error thrown in a task from stalling the event
        // queue if the exception handled by Node.js’s
        // `process.on("uncaughtException")` or by a domain.
        // `requestFlush` is implemented using a strategy based on data collected from
        // every available SauceLabs Selenium web driver worker at time of writing.
        // https://docs.google.com/spreadsheets/d/1mG-5UYGup5qxGdEMWkhP6BWCz053NUb2E1QoUTU16uA/edit#gid=783724593
        this.requestFlush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$makeRequestCall$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeRequestCall"])(this.flush);
        this.requestErrorThrow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$makeRequestCall$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeRequestCallFromTimer"])(()=>{
            // Throw first error
            if (this.pendingErrors.length) {
                throw this.pendingErrors.shift();
            }
        });
    }
} // The message channel technique was discovered by Malte Ubl and was the
 // original foundation for this library.
 // http://www.nonblocking.io/2011/06/windownexttick.html
 // Safari 6.0.5 (at least) intermittently fails to create message ports on a
 // page's first load. Thankfully, this version of Safari supports
 // MutationObservers, so we don't need to fall back in that case.
 // function makeRequestCallFromMessageChannel(callback) {
 //     var channel = new MessageChannel();
 //     channel.port1.onmessage = callback;
 //     return function requestCall() {
 //         channel.port2.postMessage(0);
 //     };
 // }
 // For reasons explained above, we are also unable to use `setImmediate`
 // under any circumstances.
 // Even if we were, there is another bug in Internet Explorer 10.
 // It is not sufficient to assign `setImmediate` to `requestFlush` because
 // `setImmediate` must be called *by name* and therefore must be wrapped in a
 // closure.
 // Never forget.
 // function makeRequestCallFromSetImmediate(callback) {
 //     return function requestCall() {
 //         setImmediate(callback);
 //     };
 // }
 // Safari 6.0 has a problem where timers will get lost while the user is
 // scrolling. This problem does not impact ASAP because Safari 6.0 supports
 // mutation observers, so that implementation is used instead.
 // However, if we ever elect to use timers in Safari, the prevalent work-around
 // is to add a scroll event listener that calls for a flush.
 // `setTimeout` does not call the passed callback if the delay is less than
 // approximately 7 in web workers in Firefox 8 through 18, and sometimes not
 // even then.
 // This is for `asap.js` only.
 // Its name will be periodically randomized to break any code that depends on
 // // its existence.
 // rawAsap.makeRequestCallFromTimer = makeRequestCallFromTimer
 // ASAP was originally a nextTick shim included in Q. This was factored out
 // into this ASAP package. It was later adapted to RSVP which made further
 // amendments. These decisions, particularly to marginalize MessageChannel and
 // to capture the MutationObserver implementation in a closure, were integrated
 // back into ASAP proper.
 // https://github.com/tildeio/rsvp.js/blob/cddf7232546a9cf858524b75cde6f9edf72620a7/lib/rsvp/asap.js
 //# sourceMappingURL=AsapQueue.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/RawTask.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// `call`, just like a function.
__turbopack_context__.s({
    "RawTask": ()=>RawTask
});
class RawTask {
    call() {
        try {
            this.task && this.task();
        } catch (error) {
            this.onError(error);
        } finally{
            this.task = null;
            this.release(this);
        }
    }
    constructor(onError, release){
        this.onError = onError;
        this.release = release;
        this.task = null;
    }
} //# sourceMappingURL=RawTask.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/TaskFactory.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "TaskFactory": ()=>TaskFactory
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$RawTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/RawTask.mjs [app-client] (ecmascript)");
;
class TaskFactory {
    create(task) {
        const tasks = this.freeTasks;
        const t1 = tasks.length ? tasks.pop() : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$RawTask$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RawTask"](this.onError, (t)=>tasks[tasks.length] = t);
        t1.task = task;
        return t1;
    }
    constructor(onError){
        this.onError = onError;
        this.freeTasks = [];
    }
} //# sourceMappingURL=TaskFactory.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/asap.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "asap": ()=>asap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$AsapQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/AsapQueue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$TaskFactory$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/TaskFactory.mjs [app-client] (ecmascript)");
;
;
const asapQueue = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$AsapQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AsapQueue"]();
const taskFactory = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$TaskFactory$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TaskFactory"](asapQueue.registerPendingError);
function asap(task) {
    asapQueue.enqueueTask(taskFactory.create(task));
} //# sourceMappingURL=asap.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/types.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({});
;
 //# sourceMappingURL=types.mjs.map
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/index.mjs [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$asap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/asap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$AsapQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/AsapQueue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$TaskFactory$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/TaskFactory.mjs [app-client] (ecmascript)"); //# sourceMappingURL=index.mjs.map
;
;
;
;
}),
"[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/index.mjs [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$asap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/asap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$types$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/types.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$AsapQueue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/AsapQueue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$TaskFactory$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/TaskFactory.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$asap$40$4$2e$0$2e$1$2f$node_modules$2f40$react$2d$dnd$2f$asap$2f$dist$2f$esm$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+asap@4.0.1/node_modules/@react-dnd/asap/dist/esm/index.mjs [app-client] (ecmascript) <locals>");
}),
"[project]/node_modules/.pnpm/use-resize-observer@9.1.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/use-resize-observer/dist/bundle.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>useResizeObserver
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
// This could've been more streamlined with internal state instead of abusing
// refs to such extent, but then composing hooks and components could not opt out of unnecessary renders.
function useResolvedElement(subscriber, refOrElement) {
    var lastReportRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    var refOrElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    refOrElementRef.current = refOrElement;
    var cbElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Calling re-evaluation after each render without using a dep array,
    // as the ref object's current value could've changed since the last render.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useResolvedElement.useEffect": function() {
            evaluateSubscription();
        }
    }["useResolvedElement.useEffect"]);
    var evaluateSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useResolvedElement.useCallback[evaluateSubscription]": function() {
            var cbElement = cbElementRef.current;
            var refOrElement = refOrElementRef.current; // Ugly ternary. But smaller than an if-else block.
            var element = cbElement ? cbElement : refOrElement ? refOrElement instanceof Element ? refOrElement : refOrElement.current : null;
            if (lastReportRef.current && lastReportRef.current.element === element && lastReportRef.current.subscriber === subscriber) {
                return;
            }
            if (lastReportRef.current && lastReportRef.current.cleanup) {
                lastReportRef.current.cleanup();
            }
            lastReportRef.current = {
                element: element,
                subscriber: subscriber,
                // Only calling the subscriber, if there's an actual element to report.
                // Setting cleanup to undefined unless a subscriber returns one, as an existing cleanup function would've been just called.
                cleanup: element ? subscriber(element) : undefined
            };
        }
    }["useResolvedElement.useCallback[evaluateSubscription]"], [
        subscriber
    ]); // making sure we call the cleanup function on unmount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useResolvedElement.useEffect": function() {
            return ({
                "useResolvedElement.useEffect": function() {
                    if (lastReportRef.current && lastReportRef.current.cleanup) {
                        lastReportRef.current.cleanup();
                        lastReportRef.current = null;
                    }
                }
            })["useResolvedElement.useEffect"];
        }
    }["useResolvedElement.useEffect"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useResolvedElement.useCallback": function(element) {
            cbElementRef.current = element;
            evaluateSubscription();
        }
    }["useResolvedElement.useCallback"], [
        evaluateSubscription
    ]);
}
// We're only using the first element of the size sequences, until future versions of the spec solidify on how
// exactly it'll be used for fragments in multi-column scenarios:
// From the spec:
// > The box size properties are exposed as FrozenArray in order to support elements that have multiple fragments,
// > which occur in multi-column scenarios. However the current definitions of content rect and border box do not
// > mention how those boxes are affected by multi-column layout. In this spec, there will only be a single
// > ResizeObserverSize returned in the FrozenArray, which will correspond to the dimensions of the first column.
// > A future version of this spec will extend the returned FrozenArray to contain the per-fragment size information.
// (https://drafts.csswg.org/resize-observer/#resize-observer-entry-interface)
//
// Also, testing these new box options revealed that in both Chrome and FF everything is returned in the callback,
// regardless of the "box" option.
// The spec states the following on this:
// > This does not have any impact on which box dimensions are returned to the defined callback when the event
// > is fired, it solely defines which box the author wishes to observe layout changes on.
// (https://drafts.csswg.org/resize-observer/#resize-observer-interface)
// I'm not exactly clear on what this means, especially when you consider a later section stating the following:
// > This section is non-normative. An author may desire to observe more than one CSS box.
// > In this case, author will need to use multiple ResizeObservers.
// (https://drafts.csswg.org/resize-observer/#resize-observer-interface)
// Which is clearly not how current browser implementations behave, and seems to contradict the previous quote.
// For this reason I decided to only return the requested size,
// even though it seems we have access to results for all box types.
// This also means that we get to keep the current api, being able to return a simple { width, height } pair,
// regardless of box option.
function extractSize(entry, boxProp, sizeType) {
    if (!entry[boxProp]) {
        if (boxProp === "contentBoxSize") {
            // The dimensions in `contentBoxSize` and `contentRect` are equivalent according to the spec.
            // See the 6th step in the description for the RO algorithm:
            // https://drafts.csswg.org/resize-observer/#create-and-populate-resizeobserverentry-h
            // > Set this.contentRect to logical this.contentBoxSize given target and observedBox of "content-box".
            // In real browser implementations of course these objects differ, but the width/height values should be equivalent.
            return entry.contentRect[sizeType === "inlineSize" ? "width" : "height"];
        }
        return undefined;
    } // A couple bytes smaller than calling Array.isArray() and just as effective here.
    return entry[boxProp][0] ? entry[boxProp][0][sizeType] : // behaviour of returning objects instead of arrays for `borderBoxSize` and `contentBoxSize`.
    // @ts-ignore
    entry[boxProp][sizeType];
}
function useResizeObserver(opts) {
    if (opts === void 0) {
        opts = {};
    }
    // Saving the callback as a ref. With this, I don't need to put onResize in the
    // effect dep array, and just passing in an anonymous function without memoising
    // will not reinstantiate the hook's ResizeObserver.
    var onResize = opts.onResize;
    var onResizeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(undefined);
    onResizeRef.current = onResize;
    var round = opts.round || Math.round; // Using a single instance throughout the hook's lifetime
    var resizeObserverRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    var _useState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: undefined,
        height: undefined
    }), size = _useState[0], setSize = _useState[1]; // In certain edge cases the RO might want to report a size change just after
    // the component unmounted.
    var didUnmount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useResizeObserver.useEffect": function() {
            didUnmount.current = false;
            return ({
                "useResizeObserver.useEffect": function() {
                    didUnmount.current = true;
                }
            })["useResizeObserver.useEffect"];
        }
    }["useResizeObserver.useEffect"], []); // Using a ref to track the previous width / height to avoid unnecessary renders.
    var previous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        width: undefined,
        height: undefined
    }); // This block is kinda like a useEffect, only it's called whenever a new
    // element could be resolved based on the ref option. It also has a cleanup
    // function.
    var refCallback = useResolvedElement((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useResizeObserver.useResolvedElement[refCallback]": function(element) {
            // We only use a single Resize Observer instance, and we're instantiating it on demand, only once there's something to observe.
            // This instance is also recreated when the `box` option changes, so that a new observation is fired if there was a previously observed element with a different box option.
            if (!resizeObserverRef.current || resizeObserverRef.current.box !== opts.box || resizeObserverRef.current.round !== round) {
                resizeObserverRef.current = {
                    box: opts.box,
                    round: round,
                    instance: new ResizeObserver({
                        "useResizeObserver.useResolvedElement[refCallback]": function(entries) {
                            var entry = entries[0];
                            var boxProp = opts.box === "border-box" ? "borderBoxSize" : opts.box === "device-pixel-content-box" ? "devicePixelContentBoxSize" : "contentBoxSize";
                            var reportedWidth = extractSize(entry, boxProp, "inlineSize");
                            var reportedHeight = extractSize(entry, boxProp, "blockSize");
                            var newWidth = reportedWidth ? round(reportedWidth) : undefined;
                            var newHeight = reportedHeight ? round(reportedHeight) : undefined;
                            if (previous.current.width !== newWidth || previous.current.height !== newHeight) {
                                var newSize = {
                                    width: newWidth,
                                    height: newHeight
                                };
                                previous.current.width = newWidth;
                                previous.current.height = newHeight;
                                if (onResizeRef.current) {
                                    onResizeRef.current(newSize);
                                } else {
                                    if (!didUnmount.current) {
                                        setSize(newSize);
                                    }
                                }
                            }
                        }
                    }["useResizeObserver.useResolvedElement[refCallback]"])
                };
            }
            resizeObserverRef.current.instance.observe(element, {
                box: opts.box
            });
            return ({
                "useResizeObserver.useResolvedElement[refCallback]": function() {
                    if (resizeObserverRef.current) {
                        resizeObserverRef.current.instance.unobserve(element);
                    }
                }
            })["useResizeObserver.useResolvedElement[refCallback]"];
        }
    }["useResizeObserver.useResolvedElement[refCallback]"], [
        opts.box,
        round
    ]), opts.ref);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useResizeObserver.useMemo": function() {
            return {
                ref: refCallback,
                width: size.width,
                height: size.height
            };
        }
    }["useResizeObserver.useMemo"], [
        refCallback,
        size.width,
        size.height
    ]);
}
;
}),
}]);

//# sourceMappingURL=node_modules__pnpm_e11ea7fa._.js.map