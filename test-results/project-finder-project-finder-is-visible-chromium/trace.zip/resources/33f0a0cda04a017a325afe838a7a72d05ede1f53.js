(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DataUpdatesContext": ()=>DataUpdatesContext,
    "DndContext": ()=>DndContext,
    "NodesContext": ()=>NodesContext,
    "TreeApiContext": ()=>TreeApiContext,
    "useDataUpdates": ()=>useDataUpdates,
    "useDndContext": ()=>useDndContext,
    "useNodesContext": ()=>useNodesContext,
    "useTreeApi": ()=>useTreeApi
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const TreeApiContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useTreeApi() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TreeApiContext);
    if (value === null) throw new Error("No Tree Api Provided");
    return value;
}
const NodesContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useNodesContext() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(NodesContext);
    if (value === null) throw new Error("Provide a NodesContext");
    return value;
}
const DndContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useDndContext() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DndContext);
    if (value === null) throw new Error("Provide a DnDContext");
    return value;
}
const DataUpdatesContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(0);
function useDataUpdates() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DataUpdatesContext);
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "access": ()=>access,
    "bound": ()=>bound,
    "dfs": ()=>dfs,
    "focusNextElement": ()=>focusNextElement,
    "focusPrevElement": ()=>focusPrevElement,
    "getInsertIndex": ()=>getInsertIndex,
    "getInsertParentId": ()=>getInsertParentId,
    "identify": ()=>identify,
    "identifyNull": ()=>identifyNull,
    "indexOf": ()=>indexOf,
    "isClosed": ()=>isClosed,
    "isDescendant": ()=>isDescendant,
    "isItem": ()=>isItem,
    "isOpenWithEmptyChildren": ()=>isOpenWithEmptyChildren,
    "mergeRefs": ()=>mergeRefs,
    "noop": ()=>noop,
    "safeRun": ()=>safeRun,
    "waitFor": ()=>waitFor,
    "walk": ()=>walk
});
function bound(n, min, max) {
    return Math.max(Math.min(n, max), min);
}
function isItem(node) {
    return node && node.isLeaf;
}
function isClosed(node) {
    return node && node.isInternal && !node.isOpen;
}
function isOpenWithEmptyChildren(node) {
    var _a;
    return node && node.isOpen && !((_a = node.children) === null || _a === void 0 ? void 0 : _a.length);
}
const isDescendant = (a, b)=>{
    let n = a;
    while(n){
        if (n.id === b.id) return true;
        n = n.parent;
    }
    return false;
};
const indexOf = (node)=>{
    if (!node.parent) throw Error("Node does not have a parent");
    return node.parent.children.findIndex((c)=>c.id === node.id);
};
function noop() {}
function dfs(node, id) {
    if (!node) return null;
    if (node.id === id) return node;
    if (node.children) {
        for (let child of node.children){
            const result = dfs(child, id);
            if (result) return result;
        }
    }
    return null;
}
function walk(node, fn) {
    fn(node);
    if (node.children) {
        for (let child of node.children){
            walk(child, fn);
        }
    }
}
function focusNextElement(target) {
    const elements = getFocusable(target);
    let next;
    for(let i = 0; i < elements.length; ++i){
        const item = elements[i];
        if (item === target) {
            next = nextItem(elements, i);
            break;
        }
    }
    // @ts-ignore ??
    next === null || next === void 0 ? void 0 : next.focus();
}
function focusPrevElement(target) {
    const elements = getFocusable(target);
    let next;
    for(let i = 0; i < elements.length; ++i){
        const item = elements[i];
        if (item === target) {
            next = prevItem(elements, i);
            break;
        }
    }
    // @ts-ignore
    next === null || next === void 0 ? void 0 : next.focus();
}
function nextItem(list, index) {
    if (index + 1 < list.length) {
        return list[index + 1];
    } else {
        return list[0];
    }
}
function prevItem(list, index) {
    if (index - 1 >= 0) {
        return list[index - 1];
    } else {
        return list[list.length - 1];
    }
}
function getFocusable(target) {
    return Array.from(document.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]):not([disabled]), details:not([disabled]), summary:not(:disabled)')).filter((e)=>e === target || !target.contains(e));
}
function access(obj, accessor) {
    if (typeof accessor === "boolean") return accessor;
    if (typeof accessor === "string") return obj[accessor];
    return accessor(obj);
}
function identifyNull(obj) {
    if (obj === null) return null;
    else return identify(obj);
}
function identify(obj) {
    return typeof obj === "string" ? obj : obj.id;
}
function mergeRefs() {
    for(var _len = arguments.length, refs = new Array(_len), _key = 0; _key < _len; _key++){
        refs[_key] = arguments[_key];
    }
    return (instance)=>{
        refs.forEach((ref)=>{
            if (typeof ref === "function") {
                ref(instance);
            } else if (ref != null) {
                ref.current = instance;
            }
        });
    };
}
function safeRun(fn) {
    for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        args[_key - 1] = arguments[_key];
    }
    if (fn) return fn(...args);
}
function waitFor(fn) {
    return new Promise((resolve, reject)=>{
        let tries = 0;
        function check() {
            tries += 1;
            if (tries === 100) reject();
            if (fn()) resolve();
            else setTimeout(check, 10);
        }
        check();
    });
}
function getInsertIndex(tree) {
    var _a, _b;
    const focus = tree.focusedNode;
    if (!focus) return (_b = (_a = tree.root.children) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0;
    if (focus.isOpen) return 0;
    if (focus.parent) return focus.childIndex + 1;
    return 0;
}
function getInsertParentId(tree) {
    const focus = tree.focusedNode;
    if (!focus) return null;
    if (focus.isOpen) return focus.id;
    if (focus.parent && !focus.parent.isRoot) return focus.parent.id;
    return null;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-cursor.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DefaultCursor": ()=>DefaultCursor
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const placeholderStyle = {
    display: "flex",
    alignItems: "center",
    zIndex: 1
};
const lineStyle = {
    flex: 1,
    height: "2px",
    background: "#4B91E2",
    borderRadius: "1px"
};
const circleStyle = {
    width: "4px",
    height: "4px",
    boxShadow: "0 0 0 3px #4B91E2",
    borderRadius: "50%"
};
const DefaultCursor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(function DefaultCursor(param) {
    let { top, left, indent } = param;
    const style = {
        position: "absolute",
        pointerEvents: "none",
        top: top - 2 + "px",
        left: left + "px",
        right: indent + "px"
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        style: Object.assign(Object.assign({}, placeholderStyle), style),
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                style: Object.assign({}, circleStyle)
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                style: Object.assign({}, lineStyle)
            })
        ]
    });
});
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-row.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DefaultRow": ()=>DefaultRow
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
function DefaultRow(param) {
    let { node, attrs, innerRef, children } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", Object.assign({}, attrs, {
        ref: innerRef,
        onFocus: (e)=>e.stopPropagation(),
        onClick: node.handleClick,
        children: children
    }));
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-node.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DefaultNode": ()=>DefaultNode
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function DefaultNode(props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        ref: props.dragHandle,
        style: props.style,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                onClick: (e)=>{
                    e.stopPropagation();
                    props.node.toggle();
                },
                children: props.node.isLeaf ? "🌳" : props.node.isOpen ? "🗁" : "🗀"
            }),
            " ",
            props.node.isEditing ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Edit, Object.assign({}, props)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Show, Object.assign({}, props))
        ]
    });
}
function Show(props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            children: props.node.data.name
        })
    });
}
function Edit(param) {
    let { node } = param;
    const input = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Edit.useEffect": ()=>{
            var _a, _b;
            (_a = input.current) === null || _a === void 0 ? void 0 : _a.focus();
            (_b = input.current) === null || _b === void 0 ? void 0 : _b.select();
        }
    }["Edit.useEffect"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("input", {
        ref: input,
        // @ts-ignore
        defaultValue: node.data.name,
        onBlur: ()=>node.reset(),
        onKeyDown: (e)=>{
            var _a;
            if (e.key === "Escape") node.reset();
            if (e.key === "Enter") node.submit(((_a = input.current) === null || _a === void 0 ? void 0 : _a.value) || "");
        }
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/edit-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

/* Actions */ __turbopack_context__.s({
    "edit": ()=>edit,
    "reducer": ()=>reducer
});
function edit(id) {
    return {
        type: "EDIT",
        id
    };
}
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
        id: null
    }, action = arguments.length > 1 ? arguments[1] : void 0;
    if (action.type === "EDIT") {
        return Object.assign(Object.assign({}, state), {
            id: action.id
        });
    } else {
        return state;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/focus-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

/* Types */ /* Actions */ __turbopack_context__.s({
    "focus": ()=>focus,
    "reducer": ()=>reducer,
    "treeBlur": ()=>treeBlur
});
function focus(id) {
    return {
        type: "FOCUS",
        id
    };
}
function treeBlur() {
    return {
        type: "TREE_BLUR"
    };
}
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
        id: null,
        treeFocused: false
    }, action = arguments.length > 1 ? arguments[1] : void 0;
    if (action.type === "FOCUS") {
        return Object.assign(Object.assign({}, state), {
            id: action.id,
            treeFocused: true
        });
    } else if (action.type === "TREE_BLUR") {
        return Object.assign(Object.assign({}, state), {
            treeFocused: false
        });
    } else {
        return state;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/interfaces/node-api.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "NodeApi": ()=>NodeApi
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-root.js [app-client] (ecmascript)");
;
class NodeApi {
    get isRoot() {
        return this.id === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROOT_ID"];
    }
    get isLeaf() {
        return !Array.isArray(this.children);
    }
    get isInternal() {
        return !this.isLeaf;
    }
    get isOpen() {
        return this.isLeaf ? false : this.tree.isOpen(this.id);
    }
    get isClosed() {
        return this.isLeaf ? false : !this.tree.isOpen(this.id);
    }
    get isEditable() {
        return this.tree.isEditable(this.data);
    }
    get isEditing() {
        return this.tree.editingId === this.id;
    }
    get isSelected() {
        return this.tree.isSelected(this.id);
    }
    get isOnlySelection() {
        return this.isSelected && this.tree.hasOneSelection;
    }
    get isSelectedStart() {
        var _a;
        return this.isSelected && !((_a = this.prev) === null || _a === void 0 ? void 0 : _a.isSelected);
    }
    get isSelectedEnd() {
        var _a;
        return this.isSelected && !((_a = this.next) === null || _a === void 0 ? void 0 : _a.isSelected);
    }
    get isFocused() {
        return this.tree.isFocused(this.id);
    }
    get isDragging() {
        return this.tree.isDragging(this.id);
    }
    get willReceiveDrop() {
        return this.tree.willReceiveDrop(this.id);
    }
    get state() {
        return {
            isClosed: this.isClosed,
            isDragging: this.isDragging,
            isEditing: this.isEditing,
            isFocused: this.isFocused,
            isInternal: this.isInternal,
            isLeaf: this.isLeaf,
            isOpen: this.isOpen,
            isSelected: this.isSelected,
            isSelectedEnd: this.isSelectedEnd,
            isSelectedStart: this.isSelectedStart,
            willReceiveDrop: this.willReceiveDrop
        };
    }
    get childIndex() {
        if (this.parent && this.parent.children) {
            return this.parent.children.findIndex((child)=>child.id === this.id);
        } else {
            return -1;
        }
    }
    get next() {
        if (this.rowIndex === null) return null;
        return this.tree.at(this.rowIndex + 1);
    }
    get prev() {
        if (this.rowIndex === null) return null;
        return this.tree.at(this.rowIndex - 1);
    }
    get nextSibling() {
        var _a, _b;
        const i = this.childIndex;
        return (_b = (_a = this.parent) === null || _a === void 0 ? void 0 : _a.children[i + 1]) !== null && _b !== void 0 ? _b : null;
    }
    isAncestorOf(node) {
        if (!node) return false;
        let ancestor = node;
        while(ancestor){
            if (ancestor.id === this.id) return true;
            ancestor = ancestor.parent;
        }
        return false;
    }
    select() {
        this.tree.select(this);
    }
    deselect() {
        this.tree.deselect(this);
    }
    selectMulti() {
        this.tree.selectMulti(this);
    }
    selectContiguous() {
        this.tree.selectContiguous(this);
    }
    activate() {
        this.tree.activate(this);
    }
    focus() {
        this.tree.focus(this);
    }
    toggle() {
        this.tree.toggle(this);
    }
    open() {
        this.tree.open(this);
    }
    openParents() {
        this.tree.openParents(this);
    }
    close() {
        this.tree.close(this);
    }
    submit(value) {
        this.tree.submit(this, value);
    }
    reset() {
        this.tree.reset();
    }
    clone() {
        return new NodeApi(Object.assign({}, this));
    }
    edit() {
        return this.tree.edit(this);
    }
    constructor(params){
        this.handleClick = (e)=>{
            if (e.metaKey && !this.tree.props.disableMultiSelection) {
                this.isSelected ? this.deselect() : this.selectMulti();
            } else if (e.shiftKey && !this.tree.props.disableMultiSelection) {
                this.selectContiguous();
            } else {
                this.select();
                this.activate();
            }
        };
        this.tree = params.tree;
        this.id = params.id;
        this.data = params.data;
        this.level = params.level;
        this.children = params.children;
        this.parent = params.parent;
        this.isDraggable = params.isDraggable;
        this.rowIndex = params.rowIndex;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-root.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "ROOT_ID": ()=>ROOT_ID,
    "createRoot": ()=>createRoot
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$interfaces$2f$node$2d$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/interfaces/node-api.js [app-client] (ecmascript)");
;
const ROOT_ID = "__REACT_ARBORIST_INTERNAL_ROOT__";
function createRoot(tree) {
    var _a;
    function visitSelfAndChildren(data, level, parent) {
        const id = tree.accessId(data);
        const node = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$interfaces$2f$node$2d$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NodeApi"]({
            tree,
            data,
            level,
            parent,
            id,
            children: null,
            isDraggable: tree.isDraggable(data),
            rowIndex: null
        });
        const children = tree.accessChildren(data);
        if (children) {
            node.children = children.map((child)=>visitSelfAndChildren(child, level + 1, node));
        }
        return node;
    }
    const root = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$interfaces$2f$node$2d$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NodeApi"]({
        tree,
        id: ROOT_ID,
        // @ts-ignore
        data: {
            id: ROOT_ID
        },
        level: -1,
        parent: null,
        children: null,
        isDraggable: true,
        rowIndex: null
    });
    const data = (_a = tree.props.data) !== null && _a !== void 0 ? _a : [];
    root.children = data.map((child)=>{
        return visitSelfAndChildren(child, 0, root);
    });
    return root;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/open-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

/* Actions */ __turbopack_context__.s({
    "actions": ()=>actions,
    "reducer": ()=>reducer
});
const actions = {
    open (id, filtered) {
        return {
            type: "VISIBILITY_OPEN",
            id,
            filtered
        };
    },
    close (id, filtered) {
        return {
            type: "VISIBILITY_CLOSE",
            id,
            filtered
        };
    },
    toggle (id, filtered) {
        return {
            type: "VISIBILITY_TOGGLE",
            id,
            filtered
        };
    },
    clear (filtered) {
        return {
            type: "VISIBILITY_CLEAR",
            filtered
        };
    }
};
/* Reducer */ function openMapReducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, action = arguments.length > 1 ? arguments[1] : void 0;
    if (action.type === "VISIBILITY_OPEN") {
        return Object.assign(Object.assign({}, state), {
            [action.id]: true
        });
    } else if (action.type === "VISIBILITY_CLOSE") {
        return Object.assign(Object.assign({}, state), {
            [action.id]: false
        });
    } else if (action.type === "VISIBILITY_TOGGLE") {
        const prev = state[action.id];
        return Object.assign(Object.assign({}, state), {
            [action.id]: !prev
        });
    } else if (action.type === "VISIBILITY_CLEAR") {
        return {};
    } else {
        return state;
    }
}
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
        filtered: {},
        unfiltered: {}
    }, action = arguments.length > 1 ? arguments[1] : void 0;
    if (!action.type.startsWith("VISIBILITY")) return state;
    if (action.filtered) {
        return Object.assign(Object.assign({}, state), {
            filtered: openMapReducer(state.filtered, action)
        });
    } else {
        return Object.assign(Object.assign({}, state), {
            unfiltered: openMapReducer(state.unfiltered, action)
        });
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/initial.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "initialState": ()=>initialState
});
const initialState = (props)=>{
    var _a;
    return {
        nodes: {
            // Changes together
            open: {
                filtered: {},
                unfiltered: (_a = props === null || props === void 0 ? void 0 : props.initialOpenState) !== null && _a !== void 0 ? _a : {}
            },
            focus: {
                id: null,
                treeFocused: false
            },
            edit: {
                id: null
            },
            drag: {
                id: null,
                selectedIds: [],
                destinationParentId: null,
                destinationIndex: null
            },
            selection: {
                ids: new Set(),
                anchor: null,
                mostRecent: null
            }
        },
        dnd: {
            cursor: {
                type: "none"
            },
            dragId: null,
            dragIds: [],
            parentId: null,
            index: -1
        }
    };
};
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/selection-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "actions": ()=>actions,
    "reducer": ()=>reducer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/initial.js [app-client] (ecmascript)");
;
;
const actions = {
    clear: ()=>({
            type: "SELECTION_CLEAR"
        }),
    only: (id)=>({
            type: "SELECTION_ONLY",
            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identify"])(id)
        }),
    add: (id)=>({
            type: "SELECTION_ADD",
            ids: (Array.isArray(id) ? id : [
                id
            ]).map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identify"])
        }),
    remove: (id)=>({
            type: "SELECTION_REMOVE",
            ids: (Array.isArray(id) ? id : [
                id
            ]).map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identify"])
        }),
    set: (args)=>Object.assign({
            type: "SELECTION_SET"
        }, args),
    mostRecent: (id)=>({
            type: "SELECTION_MOST_RECENT",
            id: id === null ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identify"])(id)
        }),
    anchor: (id)=>({
            type: "SELECTION_ANCHOR",
            id: id === null ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identify"])(id)
        })
};
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])()["nodes"]["selection"], action = arguments.length > 1 ? arguments[1] : void 0;
    const ids = state.ids;
    switch(action.type){
        case "SELECTION_CLEAR":
            return Object.assign(Object.assign({}, state), {
                ids: new Set()
            });
        case "SELECTION_ONLY":
            return Object.assign(Object.assign({}, state), {
                ids: new Set([
                    action.id
                ])
            });
        case "SELECTION_ADD":
            if (action.ids.length === 0) return state;
            action.ids.forEach((id)=>ids.add(id));
            return Object.assign(Object.assign({}, state), {
                ids: new Set(ids)
            });
        case "SELECTION_REMOVE":
            if (action.ids.length === 0) return state;
            action.ids.forEach((id)=>ids.delete(id));
            return Object.assign(Object.assign({}, state), {
                ids: new Set(ids)
            });
        case "SELECTION_SET":
            return Object.assign(Object.assign({}, state), {
                ids: action.ids,
                mostRecent: action.mostRecent,
                anchor: action.anchor
            });
        case "SELECTION_MOST_RECENT":
            return Object.assign(Object.assign({}, state), {
                mostRecent: action.id
            });
        case "SELECTION_ANCHOR":
            return Object.assign(Object.assign({}, state), {
                anchor: action.id
            });
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "actions": ()=>actions,
    "reducer": ()=>reducer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/initial.js [app-client] (ecmascript)");
;
const actions = {
    cursor (cursor) {
        return {
            type: "DND_CURSOR",
            cursor
        };
    },
    dragStart (id, dragIds) {
        return {
            type: "DND_DRAG_START",
            id,
            dragIds
        };
    },
    dragEnd () {
        return {
            type: "DND_DRAG_END"
        };
    },
    hovering (parentId, index) {
        return {
            type: "DND_HOVERING",
            parentId,
            index
        };
    }
};
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])()["dnd"], action = arguments.length > 1 ? arguments[1] : void 0;
    switch(action.type){
        case "DND_CURSOR":
            return Object.assign(Object.assign({}, state), {
                cursor: action.cursor
            });
        case "DND_DRAG_START":
            return Object.assign(Object.assign({}, state), {
                dragId: action.id,
                dragIds: action.dragIds
            });
        case "DND_DRAG_END":
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])()["dnd"];
        case "DND_HOVERING":
            return Object.assign(Object.assign({}, state), {
                parentId: action.parentId,
                index: action.index
            });
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-drag-preview.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DefaultDragPreview": ()=>DefaultDragPreview
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
;
;
;
const layerStyles = {
    position: "fixed",
    pointerEvents: "none",
    zIndex: 100,
    left: 0,
    top: 0,
    width: "100%",
    height: "100%"
};
const getStyle = (offset)=>{
    if (!offset) return {
        display: "none"
    };
    const { x, y } = offset;
    return {
        transform: "translate(".concat(x, "px, ").concat(y, "px)")
    };
};
const getCountStyle = (offset)=>{
    if (!offset) return {
        display: "none"
    };
    const { x, y } = offset;
    return {
        transform: "translate(".concat(x + 10, "px, ").concat(y + 10, "px)")
    };
};
function DefaultDragPreview(param) {
    let { offset, mouse, id, dragIds, isDragging } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Overlay, {
        isDragging: isDragging,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Position, {
                offset: offset,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PreviewNode, {
                    id: id,
                    dragIds: dragIds
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Count, {
                mouse: mouse,
                count: dragIds.length
            })
        ]
    });
}
const Overlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function Overlay(props) {
    if (!props.isDragging) return null;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        style: layerStyles,
        children: props.children
    });
});
function Position(props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "row preview",
        style: getStyle(props.offset),
        children: props.children
    });
}
function Count(props) {
    const { count, mouse } = props;
    if (count > 1) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "selected-count",
        style: getCountStyle(mouse),
        children: count
    });
    else return null;
}
const PreviewNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function PreviewNode(props) {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const node = tree.get(props.id);
    if (!node) return null;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(tree.renderNode, {
        preview: true,
        node: node,
        style: {
            paddingLeft: node.level * tree.indent,
            opacity: 0.2,
            background: "transparent"
        },
        tree: tree
    });
});
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/cursor.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "Cursor": ()=>Cursor
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
;
;
function Cursor() {
    var _a, _b;
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDndContext"])();
    const cursor = state.cursor;
    if (!cursor || cursor.type !== "line") return null;
    const indent = tree.indent;
    const top = tree.rowHeight * cursor.index + ((_b = (_a = tree.props.padding) !== null && _a !== void 0 ? _a : tree.props.paddingTop) !== null && _b !== void 0 ? _b : 0);
    const left = indent * cursor.level;
    const Cursor = tree.renderCursor;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Cursor, {
        top,
        left,
        indent
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/list-outer-element.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "ListOuterElement": ()=>ListOuterElement
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/cursor.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
;
const ListOuterElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function Outer(props, ref) {
    const { children } = props, rest = __rest(props, [
        "children"
    ]);
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", Object.assign({
        // @ts-ignore
        ref: ref
    }, rest, {
        onClick: (e)=>{
            if (e.currentTarget === e.target) tree.deselectAll();
        },
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DropContainer, {}),
            children
        ]
    }));
});
const DropContainer = ()=>{
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        style: {
            height: tree.visibleNodes.length * tree.rowHeight,
            width: "100%",
            position: "absolute",
            left: "0",
            right: "0"
        },
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cursor"], {})
    });
};
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/list-inner-element.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "ListInnerElement": ()=>ListInnerElement
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __rest = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
;
;
;
const ListInnerElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function InnerElement(_a, ref) {
    var _b, _c, _d, _e;
    var { style } = _a, rest = __rest(_a, [
        "style"
    ]);
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const paddingTop = (_c = (_b = tree.props.padding) !== null && _b !== void 0 ? _b : tree.props.paddingTop) !== null && _c !== void 0 ? _c : 0;
    const paddingBottom = (_e = (_d = tree.props.padding) !== null && _d !== void 0 ? _d : tree.props.paddingBottom) !== null && _e !== void 0 ? _e : 0;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", Object.assign({
        ref: ref,
        style: Object.assign(Object.assign({}, style), {
            height: "".concat(parseFloat(style.height) + paddingTop + paddingBottom, "px")
        })
    }, rest));
});
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/drag-hook.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragHook": ()=>useDragHook
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDrag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$getEmptyImage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/getEmptyImage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)");
;
;
;
;
;
function useDragHook(node) {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const ids = tree.selectedIds;
    const [_, ref, preview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDrag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrag"])({
        "useDragHook.useDrag": ()=>({
                canDrag: ({
                    "useDragHook.useDrag": ()=>node.isDraggable
                })["useDragHook.useDrag"],
                type: "NODE",
                item: ({
                    "useDragHook.useDrag": ()=>{
                        // This is fired once at the begging of a drag operation
                        const dragIds = tree.isSelected(node.id) ? Array.from(ids) : [
                            node.id
                        ];
                        tree.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].dragStart(node.id, dragIds));
                        return {
                            id: node.id,
                            dragIds
                        };
                    }
                })["useDragHook.useDrag"],
                end: ({
                    "useDragHook.useDrag": ()=>{
                        tree.hideCursor();
                        tree.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].dragEnd());
                    }
                })["useDragHook.useDrag"]
            })
    }["useDragHook.useDrag"], [
        ids,
        node
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDragHook.useEffect": ()=>{
            preview((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$getEmptyImage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEmptyImage"])());
        }
    }["useDragHook.useEffect"], [
        preview
    ]);
    return ref;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/compute-drop.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "computeDrop": ()=>computeDrop
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)");
;
function measureHover(el, offset) {
    const rect = el.getBoundingClientRect();
    const x = offset.x - Math.round(rect.x);
    const y = offset.y - Math.round(rect.y);
    const height = rect.height;
    const inTopHalf = y < height / 2;
    const inBottomHalf = !inTopHalf;
    const pad = height / 4;
    const inMiddle = y > pad && y < height - pad;
    const atTop = !inMiddle && inTopHalf;
    const atBottom = !inMiddle && inBottomHalf;
    return {
        x,
        inTopHalf,
        inBottomHalf,
        inMiddle,
        atTop,
        atBottom
    };
}
function getNodesAroundCursor(node, prev, next, hover) {
    if (!node) {
        // We're hovering over the empty part of the list, not over an item,
        // Put the cursor below the last item which is "prev"
        return [
            prev,
            null
        ];
    }
    if (node.isInternal) {
        if (hover.atTop) {
            return [
                prev,
                node
            ];
        } else if (hover.inMiddle) {
            return [
                node,
                node
            ];
        } else {
            return [
                node,
                next
            ];
        }
    } else {
        if (hover.inTopHalf) {
            return [
                prev,
                node
            ];
        } else {
            return [
                node,
                next
            ];
        }
    }
}
function dropAt(parentId, index) {
    return {
        parentId: parentId || null,
        index
    };
}
function lineCursor(index, level) {
    return {
        type: "line",
        index,
        level
    };
}
function noCursor() {
    return {
        type: "none"
    };
}
function highlightCursor(id) {
    return {
        type: "highlight",
        id
    };
}
function walkUpFrom(node, level) {
    var _a;
    let drop = node;
    while(drop.parent && drop.level > level){
        drop = drop.parent;
    }
    const parentId = ((_a = drop.parent) === null || _a === void 0 ? void 0 : _a.id) || null;
    const index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indexOf"])(drop) + 1;
    return {
        parentId,
        index
    };
}
function computeDrop(args) {
    var _a;
    const hover = measureHover(args.element, args.offset);
    const indent = args.indent;
    const hoverLevel = Math.round(Math.max(0, hover.x - indent) / indent);
    const { node, nextNode, prevNode } = args;
    const [above, below] = getNodesAroundCursor(node, prevNode, nextNode, hover);
    /* Hovering over the middle of a folder */ if (node && node.isInternal && hover.inMiddle) {
        return {
            drop: dropAt(node.id, null),
            cursor: highlightCursor(node.id)
        };
    }
    /*
     * Now we only need to care about the node above the cursor
     * -----------                            -------
     */ /* There is no node above the cursor line */ if (!above) {
        return {
            drop: dropAt((_a = below === null || below === void 0 ? void 0 : below.parent) === null || _a === void 0 ? void 0 : _a.id, 0),
            cursor: lineCursor(0, 0)
        };
    }
    /* The node above the cursor line is an item */ if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isItem"])(above)) {
        const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bound"])(hoverLevel, (below === null || below === void 0 ? void 0 : below.level) || 0, above.level);
        return {
            drop: walkUpFrom(above, level),
            cursor: lineCursor(above.rowIndex + 1, level)
        };
    }
    /* The node above the cursor line is a closed folder */ if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isClosed"])(above)) {
        const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bound"])(hoverLevel, (below === null || below === void 0 ? void 0 : below.level) || 0, above.level);
        return {
            drop: walkUpFrom(above, level),
            cursor: lineCursor(above.rowIndex + 1, level)
        };
    }
    /* The node above the cursor line is an open folder with no children */ if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOpenWithEmptyChildren"])(above)) {
        const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bound"])(hoverLevel, 0, above.level + 1);
        if (level > above.level) {
            /* Will be the first child of the empty folder */ return {
                drop: dropAt(above.id, 0),
                cursor: lineCursor(above.rowIndex + 1, level)
            };
        } else {
            /* Will be a sibling or grandsibling of the empty folder */ return {
                drop: walkUpFrom(above, level),
                cursor: lineCursor(above.rowIndex + 1, level)
            };
        }
    }
    /* The node above the cursor is a an open folder with children */ return {
        drop: dropAt(above === null || above === void 0 ? void 0 : above.id, 0),
        cursor: lineCursor(above.rowIndex + 1, above.level + 1)
    };
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/drop-hook.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDropHook": ()=>useDropHook
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDrop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$compute$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/compute-drop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-root.js [app-client] (ecmascript)");
;
;
;
;
;
;
function useDropHook(el, node) {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const [_, dropRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"])({
        "useDropHook.useDrop": ()=>({
                accept: "NODE",
                canDrop: ({
                    "useDropHook.useDrop": ()=>tree.canDrop()
                })["useDropHook.useDrop"],
                hover: ({
                    "useDropHook.useDrop": (_item, m)=>{
                        const offset = m.getClientOffset();
                        if (!el.current || !offset) return;
                        const { cursor, drop } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$compute$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeDrop"])({
                            element: el.current,
                            offset: offset,
                            indent: tree.indent,
                            node: node,
                            prevNode: node.prev,
                            nextNode: node.next
                        });
                        if (drop) tree.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].hovering(drop.parentId, drop.index));
                        if (m.canDrop()) {
                            if (cursor) tree.showCursor(cursor);
                        } else {
                            tree.hideCursor();
                        }
                    }
                })["useDropHook.useDrop"],
                drop: ({
                    "useDropHook.useDrop": (_, m)=>{
                        if (!m.canDrop()) return null;
                        let { parentId, index, dragIds } = tree.state.dnd;
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeRun"])(tree.props.onMove, {
                            dragIds,
                            parentId: parentId === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROOT_ID"] ? null : parentId,
                            index: index === null ? 0 : index,
                            dragNodes: tree.dragNodes,
                            parentNode: tree.get(parentId)
                        });
                        tree.open(parentId);
                    }
                })["useDropHook.useDrop"]
            })
    }["useDropHook.useDrop"], [
        node,
        el.current,
        tree.props
    ]);
    return dropRef;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-fresh-node.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useFreshNode": ()=>useFreshNode
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
;
;
function useFreshNode(index) {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const original = tree.at(index);
    if (!original) throw new Error("Could not find node for index: ".concat(index));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useFreshNode.useMemo": ()=>{
            const fresh = original.clone();
            tree.visibleNodes[index] = fresh; // sneaky
            return fresh;
        // Return a fresh instance if the state values change
        }
    }["useFreshNode.useMemo"], [
        ...Object.values(original.state),
        original
    ]);
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/row-container.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "RowContainer": ()=>RowContainer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$drag$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/drag-hook.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$drop$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/drop-hook.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$fresh$2d$node$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-fresh-node.js [app-client] (ecmascript)");
;
;
;
;
;
;
const RowContainer = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(function RowContainer(param) {
    let { index, style } = param;
    /* When will the <Row> will re-render.
     *
     * The row component is memo'd so it will only render
     * when a new instance of the NodeApi class is passed
     * to it.
     *
     * The TreeApi instance is stable. It does not
     * change when the internal state changes.
     *
     * The TreeApi has all the references to the nodes.
     * We need to clone the nodes when their state
     * changes. The node class contains no state itself,
     * It always checks the tree for state. The tree's
     * state will always be up to date.
     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDataUpdates"])(); // Re-render when tree props or visability changes
    const _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNodesContext"])(); // So that we re-render appropriately
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])(); // Tree already has the fresh state
    const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$fresh$2d$node$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFreshNode"])(index);
    const el = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const dragRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$drag$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragHook"])(node);
    const dropRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$drop$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropHook"])(el, node);
    const innerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "RowContainer.RowContainer.useCallback[innerRef]": (n)=>{
            el.current = n;
            dropRef(n);
        }
    }["RowContainer.RowContainer.useCallback[innerRef]"], [
        dropRef
    ]);
    const indent = tree.indent * node.level;
    const nodeStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RowContainer.RowContainer.useMemo[nodeStyle]": ()=>({
                paddingLeft: indent
            })
    }["RowContainer.RowContainer.useMemo[nodeStyle]"], [
        indent
    ]);
    const rowStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RowContainer.RowContainer.useMemo[rowStyle]": ()=>{
            var _a, _b;
            return Object.assign(Object.assign({}, style), {
                top: parseFloat(style.top) + ((_b = (_a = tree.props.padding) !== null && _a !== void 0 ? _a : tree.props.paddingTop) !== null && _b !== void 0 ? _b : 0)
            });
        }
    }["RowContainer.RowContainer.useMemo[rowStyle]"], [
        style,
        tree.props.padding,
        tree.props.paddingTop
    ]);
    const rowAttrs = {
        role: "treeitem",
        "aria-level": node.level + 1,
        "aria-selected": node.isSelected,
        "aria-expanded": node.isOpen,
        style: rowStyle,
        tabIndex: -1,
        className: tree.props.rowClassName
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RowContainer.RowContainer.useEffect": ()=>{
            var _a;
            if (!node.isEditing && node.isFocused) {
                (_a = el.current) === null || _a === void 0 ? void 0 : _a.focus({
                    preventScroll: true
                });
            }
        }
    }["RowContainer.RowContainer.useEffect"], [
        node.isEditing,
        node.isFocused,
        el.current
    ]);
    const Node = tree.renderNode;
    const Row = tree.renderRow;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Row, {
        node: node,
        innerRef: innerRef,
        attrs: rowAttrs,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Node, {
            node: node,
            tree: tree,
            style: nodeStyle,
            dragHandle: dragRef
        })
    });
});
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-container.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DefaultContainer": ()=>DefaultContainer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$window$40$1$2e$8$2e$11_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$window$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-window@1.8.11_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-window/dist/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$list$2d$outer$2d$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/list-outer-element.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$list$2d$inner$2d$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/list-inner-element.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$row$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/row-container.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
let focusSearchTerm = "";
let timeoutId = null;
function DefaultContainer() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDataUpdates"])();
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        role: "tree",
        style: {
            height: tree.height,
            width: tree.width,
            minHeight: 0,
            minWidth: 0
        },
        onContextMenu: tree.props.onContextMenu,
        onClick: tree.props.onClick,
        tabIndex: 0,
        onFocus: (e)=>{
            if (!e.currentTarget.contains(e.relatedTarget)) {
                tree.onFocus();
            }
        },
        onBlur: (e)=>{
            if (!e.currentTarget.contains(e.relatedTarget)) {
                tree.onBlur();
            }
        },
        onKeyDown: (e)=>{
            var _a;
            if (tree.isEditing) {
                return;
            }
            if (e.key === "Backspace") {
                if (!tree.props.onDelete) return;
                const ids = Array.from(tree.selectedIds);
                if (ids.length > 1) {
                    let nextFocus = tree.mostRecentNode;
                    while(nextFocus && nextFocus.isSelected){
                        nextFocus = nextFocus.nextSibling;
                    }
                    if (!nextFocus) nextFocus = tree.lastNode;
                    tree.focus(nextFocus, {
                        scroll: false
                    });
                    tree.delete(Array.from(ids));
                } else {
                    const node = tree.focusedNode;
                    if (node) {
                        const sib = node.nextSibling;
                        const parent = node.parent;
                        tree.focus(sib || parent, {
                            scroll: false
                        });
                        tree.delete(node);
                    }
                }
                return;
            }
            if (e.key === "Tab" && !e.shiftKey) {
                e.preventDefault();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusNextElement"])(e.currentTarget);
                return;
            }
            if (e.key === "Tab" && e.shiftKey) {
                e.preventDefault();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusPrevElement"])(e.currentTarget);
                return;
            }
            if (e.key === "ArrowDown") {
                e.preventDefault();
                const next = tree.nextNode;
                if (e.metaKey) {
                    tree.select(tree.focusedNode);
                    tree.activate(tree.focusedNode);
                    return;
                } else if (!e.shiftKey || tree.props.disableMultiSelection) {
                    tree.focus(next);
                    return;
                } else {
                    if (!next) return;
                    const current = tree.focusedNode;
                    if (!current) {
                        tree.focus(tree.firstNode);
                    } else if (current.isSelected) {
                        tree.selectContiguous(next);
                    } else {
                        tree.selectMulti(next);
                    }
                    return;
                }
            }
            if (e.key === "ArrowUp") {
                e.preventDefault();
                const prev = tree.prevNode;
                if (!e.shiftKey || tree.props.disableMultiSelection) {
                    tree.focus(prev);
                    return;
                } else {
                    if (!prev) return;
                    const current = tree.focusedNode;
                    if (!current) {
                        tree.focus(tree.lastNode); // ?
                    } else if (current.isSelected) {
                        tree.selectContiguous(prev);
                    } else {
                        tree.selectMulti(prev);
                    }
                    return;
                }
            }
            if (e.key === "ArrowRight") {
                const node = tree.focusedNode;
                if (!node) return;
                if (node.isInternal && node.isOpen) {
                    tree.focus(tree.nextNode);
                } else if (node.isInternal) tree.open(node.id);
                return;
            }
            if (e.key === "ArrowLeft") {
                const node = tree.focusedNode;
                if (!node || node.isRoot) return;
                if (node.isInternal && node.isOpen) tree.close(node.id);
                else if (!((_a = node.parent) === null || _a === void 0 ? void 0 : _a.isRoot)) {
                    tree.focus(node.parent);
                }
                return;
            }
            if (e.key === "a" && e.metaKey && !tree.props.disableMultiSelection) {
                e.preventDefault();
                tree.selectAll();
                return;
            }
            if (e.key === "a" && !e.metaKey && tree.props.onCreate) {
                tree.createLeaf();
                return;
            }
            if (e.key === "A" && !e.metaKey) {
                if (!tree.props.onCreate) return;
                tree.createInternal();
                return;
            }
            if (e.key === "Home") {
                // add shift keys
                e.preventDefault();
                tree.focus(tree.firstNode);
                return;
            }
            if (e.key === "End") {
                // add shift keys
                e.preventDefault();
                tree.focus(tree.lastNode);
                return;
            }
            if (e.key === "Enter") {
                const node = tree.focusedNode;
                if (!node) return;
                if (!node.isEditable || !tree.props.onRename) return;
                setTimeout(()=>{
                    if (node) tree.edit(node);
                });
                return;
            }
            if (e.key === " ") {
                e.preventDefault();
                const node = tree.focusedNode;
                if (!node) return;
                if (node.isLeaf) {
                    node.select();
                    node.activate();
                } else {
                    node.toggle();
                }
                return;
            }
            if (e.key === "*") {
                const node = tree.focusedNode;
                if (!node) return;
                tree.openSiblings(node);
                return;
            }
            if (e.key === "PageUp") {
                e.preventDefault();
                tree.pageUp();
                return;
            }
            if (e.key === "PageDown") {
                e.preventDefault();
                tree.pageDown();
            }
            // If they type a sequence of characters
            // collect them. Reset them after a timeout.
            // Use it to search the tree for a node, then focus it.
            // Clean this up a bit later
            clearTimeout(timeoutId);
            focusSearchTerm += e.key;
            timeoutId = setTimeout(()=>{
                focusSearchTerm = "";
            }, 600);
            const node = tree.visibleNodes.find((n)=>{
                // @ts-ignore
                const name = n.data.name;
                if (typeof name === "string") {
                    return name.toLowerCase().startsWith(focusSearchTerm);
                } else return false;
            });
            if (node) tree.focus(node.id);
        },
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$window$40$1$2e$8$2e$11_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$window$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FixedSizeList"], {
            className: tree.props.className,
            outerRef: tree.listEl,
            itemCount: tree.visibleNodes.length,
            height: tree.height,
            width: tree.width,
            itemSize: tree.rowHeight,
            overscanCount: tree.overscanCount,
            itemKey: (index)=>{
                var _a;
                return ((_a = tree.visibleNodes[index]) === null || _a === void 0 ? void 0 : _a.id) || index;
            },
            outerElementType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$list$2d$outer$2d$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListOuterElement"],
            innerElementType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$list$2d$inner$2d$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListInnerElement"],
            onScroll: tree.props.onScroll,
            onItemsRendered: tree.onItemsRendered.bind(tree),
            ref: tree.list,
            children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$row$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RowContainer"]
        })
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createList": ()=>createList
});
function createList(tree) {
    if (tree.isFiltered) {
        return flattenAndFilterTree(tree.root, tree.isMatch.bind(tree));
    } else {
        return flattenTree(tree.root);
    }
}
function flattenTree(root) {
    const list = [];
    function collect(node) {
        var _a;
        if (node.level >= 0) {
            list.push(node);
        }
        if (node.isOpen) {
            (_a = node.children) === null || _a === void 0 ? void 0 : _a.forEach(collect);
        }
    }
    collect(root);
    list.forEach(assignRowIndex);
    return list;
}
function flattenAndFilterTree(root, isMatch) {
    const matches = {};
    const list = [];
    function markMatch(node) {
        const yes = !node.isRoot && isMatch(node);
        if (yes) {
            matches[node.id] = true;
            let parent = node.parent;
            while(parent){
                matches[parent.id] = true;
                parent = parent.parent;
            }
        }
        if (node.children) {
            for (let child of node.children)markMatch(child);
        }
    }
    function collect(node) {
        var _a;
        if (node.level >= 0 && matches[node.id]) {
            list.push(node);
        }
        if (node.isOpen) {
            (_a = node.children) === null || _a === void 0 ? void 0 : _a.forEach(collect);
        }
    }
    markMatch(root);
    collect(root);
    list.forEach(assignRowIndex);
    return list;
}
function assignRowIndex(node, index) {
    node.rowIndex = index;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "createIndex": ()=>createIndex
});
const createIndex = (nodes)=>{
    return nodes.reduce((map, node, index)=>{
        map[node.id] = index;
        return map;
    }, {});
};
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/interfaces/tree-api.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "TreeApi": ()=>TreeApi
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-cursor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-row.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$node$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-node.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/edit-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/focus-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-root.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/open-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/selection-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$drag$2d$preview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-drag-preview.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-container.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/create-index.js [app-client] (ecmascript)");
var __awaiter = ("TURBOPACK compile-time value", void 0) && ("TURBOPACK compile-time value", void 0).__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const { safeRun, identify, identifyNull } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__;
class TreeApi {
    /* Changes here must also be made in constructor() */ update(props) {
        this.props = props;
        this.root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRoot"])(this);
        this.visibleNodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createList"])(this);
        this.idToIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIndex"])(this.visibleNodes);
    }
    /* Store helpers */ dispatch(action) {
        return this.store.dispatch(action);
    }
    get state() {
        return this.store.getState();
    }
    get openState() {
        return this.state.nodes.open.unfiltered;
    }
    /* Tree Props */ get width() {
        var _a;
        return (_a = this.props.width) !== null && _a !== void 0 ? _a : 300;
    }
    get height() {
        var _a;
        return (_a = this.props.height) !== null && _a !== void 0 ? _a : 500;
    }
    get indent() {
        var _a;
        return (_a = this.props.indent) !== null && _a !== void 0 ? _a : 24;
    }
    get rowHeight() {
        var _a;
        return (_a = this.props.rowHeight) !== null && _a !== void 0 ? _a : 24;
    }
    get overscanCount() {
        var _a;
        return (_a = this.props.overscanCount) !== null && _a !== void 0 ? _a : 1;
    }
    get searchTerm() {
        return (this.props.searchTerm || "").trim();
    }
    get matchFn() {
        var _a;
        const match = (_a = this.props.searchMatch) !== null && _a !== void 0 ? _a : (node, term)=>{
            const string = JSON.stringify(Object.values(node.data));
            return string.toLocaleLowerCase().includes(term.toLocaleLowerCase());
        };
        return (node)=>match(node, this.searchTerm);
    }
    accessChildren(data) {
        var _a;
        const get = this.props.childrenAccessor || "children";
        return (_a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.access(data, get)) !== null && _a !== void 0 ? _a : null;
    }
    accessId(data) {
        const get = this.props.idAccessor || "id";
        const id = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.access(data, get);
        if (!id) throw new Error("Data must contain an 'id' property or props.idAccessor must return a string");
        return id;
    }
    /* Node Access */ get firstNode() {
        var _a;
        return (_a = this.visibleNodes[0]) !== null && _a !== void 0 ? _a : null;
    }
    get lastNode() {
        var _a;
        return (_a = this.visibleNodes[this.visibleNodes.length - 1]) !== null && _a !== void 0 ? _a : null;
    }
    get focusedNode() {
        var _a;
        return (_a = this.get(this.state.nodes.focus.id)) !== null && _a !== void 0 ? _a : null;
    }
    get mostRecentNode() {
        var _a;
        return (_a = this.get(this.state.nodes.selection.mostRecent)) !== null && _a !== void 0 ? _a : null;
    }
    get nextNode() {
        const index = this.indexOf(this.focusedNode);
        if (index === null) return null;
        else return this.at(index + 1);
    }
    get prevNode() {
        const index = this.indexOf(this.focusedNode);
        if (index === null) return null;
        else return this.at(index - 1);
    }
    get(id) {
        if (!id) return null;
        if (id in this.idToIndex) return this.visibleNodes[this.idToIndex[id]] || null;
        else return null;
    }
    at(index) {
        return this.visibleNodes[index] || null;
    }
    nodesBetween(startId, endId) {
        var _a;
        if (startId === null || endId === null) return [];
        const index1 = (_a = this.indexOf(startId)) !== null && _a !== void 0 ? _a : 0;
        const index2 = this.indexOf(endId);
        if (index2 === null) return [];
        const start = Math.min(index1, index2);
        const end = Math.max(index1, index2);
        return this.visibleNodes.slice(start, end + 1);
    }
    indexOf(id) {
        const key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.identifyNull(id);
        if (!key) return null;
        return this.idToIndex[key];
    }
    /* Data Operations */ get editingId() {
        return this.state.nodes.edit.id;
    }
    createInternal() {
        return this.create({
            type: "internal"
        });
    }
    createLeaf() {
        return this.create({
            type: "leaf"
        });
    }
    create() {
        return __awaiter(this, arguments, void 0, function*() {
            let opts = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
            var _a, _b;
            const parentId = opts.parentId === undefined ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getInsertParentId(this) : opts.parentId;
            const index = (_a = opts.index) !== null && _a !== void 0 ? _a : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getInsertIndex(this);
            const type = (_b = opts.type) !== null && _b !== void 0 ? _b : "leaf";
            const data = yield safeRun(this.props.onCreate, {
                type,
                parentId,
                index,
                parentNode: this.get(parentId)
            });
            if (data) {
                this.focus(data);
                setTimeout(()=>{
                    this.edit(data).then(()=>{
                        this.select(data);
                        this.activate(data);
                    });
                });
            }
        });
    }
    delete(node) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!node) return;
            const idents = Array.isArray(node) ? node : [
                node
            ];
            const ids = idents.map(identify);
            const nodes = ids.map((id)=>this.get(id)).filter((n)=>!!n);
            yield safeRun(this.props.onDelete, {
                nodes,
                ids
            });
        });
    }
    edit(node) {
        const id = identify(node);
        this.resolveEdit({
            cancelled: true
        });
        this.scrollTo(id);
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["edit"])(id));
        return new Promise((resolve)=>{
            TreeApi.editPromise = resolve;
        });
    }
    submit(identity, value) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!identity) return;
            const id = identify(identity);
            yield safeRun(this.props.onRename, {
                id,
                name: value,
                node: this.get(id)
            });
            this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["edit"])(null));
            this.resolveEdit({
                cancelled: false,
                value
            });
            setTimeout(()=>this.onFocus()); // Return focus to element;
        });
    }
    reset() {
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["edit"])(null));
        this.resolveEdit({
            cancelled: true
        });
        setTimeout(()=>this.onFocus()); // Return focus to element;
    }
    activate(id) {
        const node = this.get(identifyNull(id));
        if (!node) return;
        safeRun(this.props.onActivate, node);
    }
    resolveEdit(value) {
        const resolve = TreeApi.editPromise;
        if (resolve) resolve(value);
        TreeApi.editPromise = null;
    }
    /* Focus and Selection */ get selectedIds() {
        return this.state.nodes.selection.ids;
    }
    get selectedNodes() {
        let nodes = [];
        for (let id of Array.from(this.selectedIds)){
            const node = this.get(id);
            if (node) nodes.push(node);
        }
        return nodes;
    }
    focus(node) {
        let opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        if (!node) return;
        /* Focus is responsible for scrolling, while selection is
         * responsible for focus. If selectionFollowsFocus, then
         * just select it. */ if (this.props.selectionFollowsFocus) {
            this.select(node);
        } else {
            this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])(identify(node)));
            if (opts.scroll !== false) this.scrollTo(node);
            if (this.focusedNode) safeRun(this.props.onFocus, this.focusedNode);
        }
    }
    pageUp() {
        var _a, _b;
        const start = this.visibleStartIndex;
        const stop = this.visibleStopIndex;
        const page = stop - start;
        let index = (_b = (_a = this.focusedNode) === null || _a === void 0 ? void 0 : _a.rowIndex) !== null && _b !== void 0 ? _b : 0;
        if (index > start) {
            index = start;
        } else {
            index = Math.max(start - page, 0);
        }
        this.focus(this.at(index));
    }
    pageDown() {
        var _a, _b;
        const start = this.visibleStartIndex;
        const stop = this.visibleStopIndex;
        const page = stop - start;
        let index = (_b = (_a = this.focusedNode) === null || _a === void 0 ? void 0 : _a.rowIndex) !== null && _b !== void 0 ? _b : 0;
        if (index < stop) {
            index = stop;
        } else {
            index = Math.min(index + page, this.visibleNodes.length - 1);
        }
        this.focus(this.at(index));
    }
    select(node) {
        let opts = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        if (!node) return;
        const changeFocus = opts.focus !== false;
        const id = identify(node);
        if (changeFocus) this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])(id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].only(id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].anchor(id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].mostRecent(id));
        this.scrollTo(id, opts.align);
        if (this.focusedNode && changeFocus) {
            safeRun(this.props.onFocus, this.focusedNode);
        }
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    deselect(node) {
        if (!node) return;
        const id = identify(node);
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].remove(id));
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    selectMulti(identity) {
        const node = this.get(identifyNull(identity));
        if (!node) return;
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])(node.id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].add(node.id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].anchor(node.id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].mostRecent(node.id));
        this.scrollTo(node);
        if (this.focusedNode) safeRun(this.props.onFocus, this.focusedNode);
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    selectContiguous(identity) {
        if (!identity) return;
        const id = identify(identity);
        const { anchor, mostRecent } = this.state.nodes.selection;
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])(id));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].remove(this.nodesBetween(anchor, mostRecent)));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].add(this.nodesBetween(anchor, identifyNull(id))));
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].mostRecent(id));
        this.scrollTo(id);
        if (this.focusedNode) safeRun(this.props.onFocus, this.focusedNode);
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    deselectAll() {
        this.setSelection({
            ids: [],
            anchor: null,
            mostRecent: null
        });
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    selectAll() {
        var _a;
        this.setSelection({
            ids: Object.keys(this.idToIndex),
            anchor: this.firstNode,
            mostRecent: this.lastNode
        });
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])((_a = this.lastNode) === null || _a === void 0 ? void 0 : _a.id));
        if (this.focusedNode) safeRun(this.props.onFocus, this.focusedNode);
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    setSelection(args) {
        var _a;
        const ids = new Set((_a = args.ids) === null || _a === void 0 ? void 0 : _a.map(identify));
        const anchor = identifyNull(args.anchor);
        const mostRecent = identifyNull(args.mostRecent);
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].set({
            ids,
            anchor,
            mostRecent
        }));
        safeRun(this.props.onSelect, this.selectedNodes);
    }
    /* Drag and Drop */ get cursorParentId() {
        const { cursor } = this.state.dnd;
        switch(cursor.type){
            case "highlight":
                return cursor.id;
            default:
                return null;
        }
    }
    get cursorOverFolder() {
        return this.state.dnd.cursor.type === "highlight";
    }
    get dragNodes() {
        return this.state.dnd.dragIds.map((id)=>this.get(id)).filter((n)=>!!n);
    }
    get dragNode() {
        return this.get(this.state.nodes.drag.id);
    }
    get dragDestinationParent() {
        return this.get(this.state.nodes.drag.destinationParentId);
    }
    get dragDestinationIndex() {
        return this.state.nodes.drag.destinationIndex;
    }
    canDrop() {
        var _a;
        if (this.isFiltered) return false;
        const parentNode = (_a = this.get(this.state.dnd.parentId)) !== null && _a !== void 0 ? _a : this.root;
        const dragNodes = this.dragNodes;
        const isDisabled = this.props.disableDrop;
        for (const drag of dragNodes){
            if (!drag) return false;
            if (!parentNode) return false;
            if (drag.isInternal && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.isDescendant(parentNode, drag)) return false;
        }
        // Allow the user to insert their own logic
        if (typeof isDisabled == "function") {
            return !isDisabled({
                parentNode,
                dragNodes: this.dragNodes,
                index: this.state.dnd.index || 0
            });
        } else if (typeof isDisabled == "string") {
            // @ts-ignore
            return !parentNode.data[isDisabled];
        } else if (typeof isDisabled === "boolean") {
            return !isDisabled;
        } else {
            return true;
        }
    }
    hideCursor() {
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].cursor({
            type: "none"
        }));
    }
    showCursor(cursor) {
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].cursor(cursor));
    }
    /* Visibility */ open(identity) {
        const id = identifyNull(identity);
        if (!id) return;
        if (this.isOpen(id)) return;
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].open(id, this.isFiltered));
        safeRun(this.props.onToggle, id);
    }
    close(identity) {
        const id = identifyNull(identity);
        if (!id) return;
        if (!this.isOpen(id)) return;
        this.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].close(id, this.isFiltered));
        safeRun(this.props.onToggle, id);
    }
    toggle(identity) {
        const id = identifyNull(identity);
        if (!id) return;
        return this.isOpen(id) ? this.close(id) : this.open(id);
    }
    openParents(identity) {
        const id = identifyNull(identity);
        if (!id) return;
        const node = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.dfs(this.root, id);
        let parent = node === null || node === void 0 ? void 0 : node.parent;
        while(parent){
            this.open(parent.id);
            parent = parent.parent;
        }
    }
    openSiblings(node) {
        const parent = node.parent;
        if (!parent) {
            this.toggle(node.id);
        } else if (parent.children) {
            const isOpen = node.isOpen;
            for (let sibling of parent.children){
                if (sibling.isInternal) {
                    isOpen ? this.close(sibling.id) : this.open(sibling.id);
                }
            }
            this.scrollTo(this.focusedNode);
        }
    }
    openAll() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.walk(this.root, (node)=>{
            if (node.isInternal) node.open();
        });
    }
    closeAll() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.walk(this.root, (node)=>{
            if (node.isInternal) node.close();
        });
    }
    /* Scrolling */ scrollTo(identity) {
        let align = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "smart";
        if (!identity) return;
        const id = identify(identity);
        this.openParents(id);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.waitFor(()=>id in this.idToIndex).then(()=>{
            var _a;
            const index = this.idToIndex[id];
            if (index === undefined) return;
            (_a = this.list.current) === null || _a === void 0 ? void 0 : _a.scrollToItem(index, align);
        }).catch(()=>{
        // Id: ${id} never appeared in the list.
        });
    }
    /* State Checks */ get isEditing() {
        return this.state.nodes.edit.id !== null;
    }
    get isFiltered() {
        var _a;
        return !!((_a = this.props.searchTerm) === null || _a === void 0 ? void 0 : _a.trim());
    }
    get hasFocus() {
        return this.state.nodes.focus.treeFocused;
    }
    get hasNoSelection() {
        return this.state.nodes.selection.ids.size === 0;
    }
    get hasOneSelection() {
        return this.state.nodes.selection.ids.size === 1;
    }
    get hasMultipleSelections() {
        return this.state.nodes.selection.ids.size > 1;
    }
    isSelected(id) {
        if (!id) return false;
        return this.state.nodes.selection.ids.has(id);
    }
    isOpen(id) {
        var _a, _b, _c;
        if (!id) return false;
        if (id === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROOT_ID"]) return true;
        const def = (_a = this.props.openByDefault) !== null && _a !== void 0 ? _a : true;
        if (this.isFiltered) {
            return (_b = this.state.nodes.open.filtered[id]) !== null && _b !== void 0 ? _b : true; // Filtered folders are always opened by default
        } else {
            return (_c = this.state.nodes.open.unfiltered[id]) !== null && _c !== void 0 ? _c : def;
        }
    }
    isEditable(data) {
        const check = this.props.disableEdit || (()=>false);
        return !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.access(data, check);
    }
    isDraggable(data) {
        const check = this.props.disableDrag || (()=>false);
        return !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.access(data, check);
    }
    isDragging(node) {
        const id = identifyNull(node);
        if (!id) return false;
        return this.state.nodes.drag.id === id;
    }
    isFocused(id) {
        return this.hasFocus && this.state.nodes.focus.id === id;
    }
    isMatch(node) {
        return this.matchFn(node);
    }
    willReceiveDrop(node) {
        const id = identifyNull(node);
        if (!id) return false;
        const { destinationParentId, destinationIndex } = this.state.nodes.drag;
        return id === destinationParentId && destinationIndex === null;
    }
    /* Tree Event Handlers */ onFocus() {
        const node = this.focusedNode || this.firstNode;
        if (node) this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focus"])(node.id));
    }
    onBlur() {
        this.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["treeBlur"])());
    }
    onItemsRendered(args) {
        this.visibleStartIndex = args.visibleStartIndex;
        this.visibleStopIndex = args.visibleStopIndex;
    }
    /* Get Renderers */ get renderContainer() {
        return this.props.renderContainer || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultContainer"];
    }
    get renderRow() {
        return this.props.renderRow || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$row$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRow"];
    }
    get renderNode() {
        return this.props.children || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$node$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultNode"];
    }
    get renderDragPreview() {
        return this.props.renderDragPreview || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$drag$2d$preview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDragPreview"];
    }
    get renderCursor() {
        return this.props.renderCursor || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultCursor"];
    }
    constructor(store, props, list, listEl){
        this.store = store;
        this.props = props;
        this.list = list;
        this.listEl = listEl;
        this.visibleStartIndex = 0;
        this.visibleStopIndex = 0;
        /* Changes here must also be made in update() */ this.root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRoot"])(this);
        this.visibleNodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createList"])(this);
        this.idToIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$create$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIndex"])(this.visibleNodes);
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/drag-slice.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "reducer": ()=>reducer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/initial.js [app-client] (ecmascript)");
;
function reducer() {
    let state = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])().nodes.drag, action = arguments.length > 1 ? arguments[1] : void 0;
    switch(action.type){
        case "DND_DRAG_START":
            return Object.assign(Object.assign({}, state), {
                id: action.id,
                selectedIds: action.dragIds
            });
        case "DND_DRAG_END":
            return Object.assign(Object.assign({}, state), {
                id: null,
                destinationParentId: null,
                destinationIndex: null,
                selectedIds: []
            });
        case "DND_HOVERING":
            if (action.parentId !== state.destinationParentId || action.index != state.destinationIndex) {
                return Object.assign(Object.assign({}, state), {
                    destinationParentId: action.parentId,
                    destinationIndex: action.index
                });
            } else {
                return state;
            }
        default:
            return state;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/root-reducer.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "rootReducer": ()=>rootReducer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$5$2e$0$2e$1$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/redux@5.0.1/node_modules/redux/dist/redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/focus-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/edit-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/selection-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/open-slice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$drag$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/drag-slice.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
const rootReducer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$5$2e$0$2e$1$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineReducers"])({
    nodes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$5$2e$0$2e$1$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineReducers"])({
        focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$focus$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"],
        edit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$edit$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"],
        open: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"],
        selection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$selection$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"],
        drag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$drag$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"]
    }),
    dnd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reducer"]
});
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/provider.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "TreeProvider": ()=>TreeProvider
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$use$2d$sync$2d$external$2d$store$40$1$2e$5$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/use-sync-external-store@1.5.0_react@19.1.0/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$interfaces$2f$tree$2d$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/interfaces/tree-api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/initial.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$root$2d$reducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/root-reducer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd-html5-backend@14.1.0/node_modules/react-dnd-html5-backend/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/core/DndProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$5$2e$0$2e$1$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/redux@5.0.1/node_modules/redux/dist/redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/open-slice.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const SERVER_STATE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])();
function TreeProvider(param) {
    let { treeProps, imperativeHandle, children } = param;
    const list = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const listEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(// @ts-ignore
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$redux$40$5$2e$0$2e$1$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$root$2d$reducer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootReducer"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$initial$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialState"])(treeProps)));
    const state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$use$2d$sync$2d$external$2d$store$40$1$2e$5$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(store.current.subscribe, store.current.getState, {
        "TreeProvider.useSyncExternalStore[state]": ()=>SERVER_STATE
    }["TreeProvider.useSyncExternalStore[state]"]);
    /* The tree api object is stable. */ const api = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TreeProvider.useMemo[api]": ()=>{
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$interfaces$2f$tree$2d$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TreeApi"](store.current, treeProps, list, listEl);
        }
    }["TreeProvider.useMemo[api]"], []);
    /* Make sure the tree instance stays in sync */ const updateCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TreeProvider.useMemo": ()=>{
            updateCount.current += 1;
            api.update(treeProps);
        }
    }["TreeProvider.useMemo"], [
        ...Object.values(treeProps),
        state.nodes.open
    ]);
    /* Expose the tree api */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(imperativeHandle, {
        "TreeProvider.useImperativeHandle": ()=>api
    }["TreeProvider.useImperativeHandle"]);
    /* Change selection based on props */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TreeProvider.useEffect": ()=>{
            if (api.props.selection) {
                api.select(api.props.selection, {
                    focus: false
                });
            } else {
                api.deselectAll();
            }
        }
    }["TreeProvider.useEffect"], [
        api.props.selection
    ]);
    /* Clear visability for filtered nodes */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TreeProvider.useEffect": ()=>{
            if (!api.props.searchTerm) {
                store.current.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$open$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].clear(true));
            }
        }
    }["TreeProvider.useEffect"], [
        api.props.searchTerm
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TreeApiContext"].Provider, {
        value: api,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataUpdatesContext"].Provider, {
            value: updateCount.current,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NodesContext"].Provider, {
                value: state.nodes,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"].Provider, {
                    value: state.dnd,
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndProvider"], Object.assign({
                        backend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$2d$html5$2d$backend$40$14$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2d$html5$2d$backend$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HTML5Backend"],
                        options: {
                            rootElement: api.props.dndRootElement || undefined
                        }
                    }, treeProps.dndManager && {
                        manager: treeProps.dndManager
                    }, {
                        children: children
                    }))
                })
            })
        })
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/outer-drop-hook.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useOuterDrop": ()=>useOuterDrop
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDrop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$compute$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/compute-drop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/state/dnd-slice.js [app-client] (ecmascript)");
;
;
;
;
function useOuterDrop() {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    // In case we drop an item at the bottom of the list
    const [, drop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDrop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDrop"])({
        "useOuterDrop.useDrop": ()=>({
                accept: "NODE",
                canDrop: ({
                    "useOuterDrop.useDrop": (_item, m)=>{
                        if (!m.isOver({
                            shallow: true
                        })) return false;
                        return tree.canDrop();
                    }
                })["useOuterDrop.useDrop"],
                hover: ({
                    "useOuterDrop.useDrop": (_item, m)=>{
                        if (!m.isOver({
                            shallow: true
                        })) return;
                        const offset = m.getClientOffset();
                        if (!tree.listEl.current || !offset) return;
                        const { cursor, drop } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$compute$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeDrop"])({
                            element: tree.listEl.current,
                            offset: offset,
                            indent: tree.indent,
                            node: null,
                            prevNode: tree.visibleNodes[tree.visibleNodes.length - 1],
                            nextNode: null
                        });
                        if (drop) tree.dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$state$2f$dnd$2d$slice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["actions"].hovering(drop.parentId, drop.index));
                        if (m.canDrop()) {
                            if (cursor) tree.showCursor(cursor);
                        } else {
                            tree.hideCursor();
                        }
                    }
                })["useOuterDrop.useDrop"]
            })
    }["useOuterDrop.useDrop"], [
        tree
    ]);
    drop(tree.listEl);
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/outer-drop.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "OuterDrop": ()=>OuterDrop
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$outer$2d$drop$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/dnd/outer-drop-hook.js [app-client] (ecmascript)");
;
function OuterDrop(props) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$dnd$2f$outer$2d$drop$2d$hook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOuterDrop"])();
    return props.children;
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/tree-container.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "TreeContainer": ()=>TreeContainer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-container.js [app-client] (ecmascript)");
;
;
;
function TreeContainer() {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const Container = tree.props.renderContainer || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultContainer"];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Container, {})
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/drag-preview-container.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DragPreviewContainer": ()=>DragPreviewContainer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragLayer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$drag$2d$preview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/default-drag-preview.js [app-client] (ecmascript)");
;
;
;
;
function DragPreviewContainer() {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeApi"])();
    const { offset, mouse, item, isDragging } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragLayer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragLayer"])({
        "DragPreviewContainer.useDragLayer": (m)=>{
            return {
                offset: m.getSourceClientOffset(),
                mouse: m.getClientOffset(),
                item: m.getItem(),
                isDragging: m.isDragging()
            };
        }
    }["DragPreviewContainer.useDragLayer"]);
    const DragPreview = tree.props.renderDragPreview || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$default$2d$drag$2d$preview$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultDragPreview"];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DragPreview, {
        offset: offset,
        mouse: mouse,
        id: (item === null || item === void 0 ? void 0 : item.id) || null,
        dragIds: (item === null || item === void 0 ? void 0 : item.dragIds) || [],
        isDragging: isDragging
    });
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/simple-tree.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "SimpleTree": ()=>SimpleTree
});
class SimpleTree {
    get data() {
        var _a, _b;
        return (_b = (_a = this.root.children) === null || _a === void 0 ? void 0 : _a.map((node)=>node.data)) !== null && _b !== void 0 ? _b : [];
    }
    create(args) {
        const parent = args.parentId ? this.find(args.parentId) : this.root;
        if (!parent) return null;
        parent.addChild(args.data, args.index);
    }
    move(args) {
        const src = this.find(args.id);
        const parent = args.parentId ? this.find(args.parentId) : this.root;
        if (!src || !parent) return;
        parent.addChild(src.data, args.index);
        src.drop();
    }
    update(args) {
        const node = this.find(args.id);
        if (node) node.update(args.changes);
    }
    drop(args) {
        const node = this.find(args.id);
        if (node) node.drop();
    }
    find(id) {
        let node = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.root;
        if (!node) return null;
        if (node.id === id) return node;
        if (node.children) {
            for (let child of node.children){
                const found = this.find(id, child);
                if (found) return found;
            }
            return null;
        }
        return null;
    }
    constructor(data){
        this.root = createRoot(data);
    }
}
function createRoot(data) {
    const root = new SimpleNode({
        id: "ROOT"
    }, null);
    root.children = data.map((d)=>createNode(d, root));
    return root;
}
function createNode(data, parent) {
    const node = new SimpleNode(data, parent);
    if (data.children) node.children = data.children.map((d)=>createNode(d, node));
    return node;
}
class SimpleNode {
    hasParent() {
        return !!this.parent;
    }
    get childIndex() {
        return this.hasParent() ? this.parent.children.indexOf(this) : -1;
    }
    addChild(data, index) {
        var _a, _b;
        const node = createNode(data, this);
        this.children = (_a = this.children) !== null && _a !== void 0 ? _a : [];
        this.children.splice(index, 0, node);
        this.data.children = (_b = this.data.children) !== null && _b !== void 0 ? _b : [];
        this.data.children.splice(index, 0, data);
    }
    removeChild(index) {
        var _a, _b;
        (_a = this.children) === null || _a === void 0 ? void 0 : _a.splice(index, 1);
        (_b = this.data.children) === null || _b === void 0 ? void 0 : _b.splice(index, 1);
    }
    update(changes) {
        if (this.hasParent()) {
            const i = this.childIndex;
            this.parent.addChild(Object.assign(Object.assign({}, this.data), changes), i);
            this.drop();
        }
    }
    drop() {
        if (this.hasParent()) this.parent.removeChild(this.childIndex);
    }
    constructor(data, parent){
        this.data = data;
        this.parent = parent;
        this.id = data.id;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-simple-tree.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useSimpleTree": ()=>useSimpleTree
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$simple$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/data/simple-tree.js [app-client] (ecmascript)");
;
;
let nextId = 0;
function useSimpleTree(initialData) {
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialData);
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useSimpleTree.useMemo[tree]": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$data$2f$simple$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SimpleTree"](data)
    }["useSimpleTree.useMemo[tree]"], [
        data
    ]);
    const onMove = (args)=>{
        for (const id of args.dragIds){
            tree.move({
                id,
                parentId: args.parentId,
                index: args.index
            });
        }
        setData(tree.data);
    };
    const onRename = (param)=>{
        let { name, id } = param;
        tree.update({
            id,
            changes: {
                name
            }
        });
        setData(tree.data);
    };
    const onCreate = (param)=>{
        let { parentId, index, type } = param;
        const data = {
            id: "simple-tree-id-".concat(nextId++),
            name: ""
        };
        if (type === "internal") data.children = [];
        tree.create({
            parentId,
            index,
            data
        });
        setData(tree.data);
        return data;
    };
    const onDelete = (args)=>{
        args.ids.forEach((id)=>tree.drop({
                id
            }));
        setData(tree.data);
    };
    const controller = {
        onMove,
        onRename,
        onCreate,
        onDelete
    };
    return [
        data,
        controller
    ];
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-validated-props.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useValidatedProps": ()=>useValidatedProps
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$simple$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-simple-tree.js [app-client] (ecmascript)");
;
function useValidatedProps(props) {
    if (props.initialData && props.data) {
        throw new Error("React Arborist Tree => Provide either a data or initialData prop, but not both.");
    }
    if (props.initialData && (props.onCreate || props.onDelete || props.onMove || props.onRename)) {
        throw new Error("React Arborist Tree => You passed the initialData prop along with a data handler.\nUse the data prop if you want to provide your own handlers.");
    }
    if (props.initialData) {
        /**
         * Let's break the rules of hooks here. If the initialData prop
         * is provided, we will assume it will not change for the life of
         * the component.
         *
         * We will provide the real data and the handlers to update it.
         *   */ const [data, controller] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$simple$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSimpleTree"])(props.initialData);
        return Object.assign(Object.assign(Object.assign({}, props), controller), {
            data
        });
    } else {
        return props;
    }
}
}),
"[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/tree.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "Tree": ()=>Tree
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$outer$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/outer-drop.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$tree$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/tree-container.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$drag$2d$preview$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/components/drag-preview-container.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$validated$2d$props$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-arborist@3.4.3_@types+node@20.19.9_@types+react@19.1.9_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-arborist/dist/module/hooks/use-validated-props.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function TreeComponent(props, ref) {
    const treeProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$hooks$2f$use$2d$validated$2d$props$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValidatedProps"])(props);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TreeProvider"], {
        treeProps: treeProps,
        imperativeHandle: ref,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$outer$2d$drop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OuterDrop"], {
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$tree$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TreeContainer"], {})
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$arborist$40$3$2e$4$2e$3_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$arborist$2f$dist$2f$module$2f$components$2f$drag$2d$preview$2d$container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragPreviewContainer"], {})
        ]
    });
}
const Tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(TreeComponent);
}),
}]);

//# sourceMappingURL=0d8a1_react-arborist_dist_module_d495e52d._.js.map