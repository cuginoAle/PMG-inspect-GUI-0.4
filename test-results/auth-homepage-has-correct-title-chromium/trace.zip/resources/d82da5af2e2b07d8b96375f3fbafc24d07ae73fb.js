(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5a130abd._.js",
  "static/chunks/4b681_next_dist_compiled_react-dom_3ecc5c4c._.js",
  "static/chunks/4b681_next_dist_compiled_next-devtools_index_ce08d094.js",
  "static/chunks/4b681_next_dist_compiled_d72b0be6._.js",
  "static/chunks/4b681_next_dist_client_0703432a._.js",
  "static/chunks/4b681_next_dist_fcc89b2c._.js",
  "static/chunks/61dca_@swc_helpers_cjs_28edb73c._.js"
],
    source: "entry"
});
