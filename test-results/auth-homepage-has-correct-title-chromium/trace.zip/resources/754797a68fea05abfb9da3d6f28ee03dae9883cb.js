(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_greetings_style_module_48f451b1.css",
  "static/chunks/4b681_next_dist_2423a2bc._.js"
],
    source: "dynamic"
});
