(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/registration.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "registerSource": ()=>registerSource,
    "registerTarget": ()=>registerTarget
});
function registerTarget(type, target, manager) {
    var registry = manager.getRegistry();
    var targetId = registry.addTarget(type, target);
    return [
        targetId,
        function() {
            return registry.removeTarget(targetId);
        }
    ];
}
function registerSource(type, source, manager) {
    var registry = manager.getRegistry();
    var sourceId = registry.addSource(type, source);
    return [
        sourceId,
        function() {
            return registry.removeSource(sourceId);
        }
    ];
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useIsomorphicLayoutEffect": ()=>useIsomorphicLayoutEffect
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"); // suppress the useLayoutEffect warning on server side.
;
var useIsomorphicLayoutEffect = typeof window !== 'undefined' ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/DragSourceImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DragSourceImpl": ()=>DragSourceImpl
});
function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
var DragSourceImpl = /*#__PURE__*/ function() {
    function DragSourceImpl(spec, monitor, connector) {
        _classCallCheck(this, DragSourceImpl);
        _defineProperty(this, "spec", void 0);
        _defineProperty(this, "monitor", void 0);
        _defineProperty(this, "connector", void 0);
        this.spec = spec;
        this.monitor = monitor;
        this.connector = connector;
    }
    _createClass(DragSourceImpl, [
        {
            key: "beginDrag",
            value: function beginDrag() {
                var _result;
                var spec = this.spec;
                var monitor = this.monitor;
                var result = null;
                if (_typeof(spec.item) === 'object') {
                    result = spec.item;
                } else if (typeof spec.item === 'function') {
                    result = spec.item(monitor);
                } else {
                    result = {};
                }
                return (_result = result) !== null && _result !== void 0 ? _result : null;
            }
        },
        {
            key: "canDrag",
            value: function canDrag() {
                var spec = this.spec;
                var monitor = this.monitor;
                if (typeof spec.canDrag === 'boolean') {
                    return spec.canDrag;
                } else if (typeof spec.canDrag === 'function') {
                    return spec.canDrag(monitor);
                } else {
                    return true;
                }
            }
        },
        {
            key: "isDragging",
            value: function isDragging(globalMonitor, target) {
                var spec = this.spec;
                var monitor = this.monitor;
                var isDragging = spec.isDragging;
                return isDragging ? isDragging(monitor) : target === globalMonitor.getSourceId();
            }
        },
        {
            key: "endDrag",
            value: function endDrag() {
                var spec = this.spec;
                var monitor = this.monitor;
                var connector = this.connector;
                var end = spec.end;
                if (end) {
                    end(monitor.getItem(), monitor);
                }
                connector.reconnect();
            }
        }
    ]);
    return DragSourceImpl;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSource.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragSource": ()=>useDragSource
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$DragSourceImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/DragSourceImpl.js [app-client] (ecmascript)");
;
;
function useDragSource(spec, monitor, connector) {
    var handler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDragSource.useMemo[handler]": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$DragSourceImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragSourceImpl"](spec, monitor, connector);
        }
    }["useDragSource.useMemo[handler]"], [
        monitor,
        connector
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDragSource.useEffect": function() {
            handler.spec = spec;
        }
    }["useDragSource.useEffect"], [
        spec
    ]);
    return handler;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/core/DndContext.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DndContext": ()=>DndContext
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var DndContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    dragDropManager: undefined
});
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragDropManager": ()=>useDragDropManager
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/core/DndContext.js [app-client] (ecmascript)");
;
;
;
function useDragDropManager() {
    var _useContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"]), dragDropManager = _useContext.dragDropManager;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(dragDropManager != null, 'Expected drag drop context');
    return dragDropManager;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragType.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragType": ()=>useDragType
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function useDragType(spec) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDragType.useMemo": function() {
            var result = spec.type;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(result != null, 'spec.type must be defined');
            return result;
        }
    }["useDragType.useMemo"], [
        spec
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useRegisteredDragSource.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useRegisteredDragSource": ()=>useRegisteredDragSource
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$registration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/registration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSource.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragType.js [app-client] (ecmascript)");
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
;
;
;
function useRegisteredDragSource(spec, monitor, connector) {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    var handler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragSource"])(spec, monitor, connector);
    var itemType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragType"])(spec);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])(function registerDragSource() {
        if (itemType != null) {
            var _registerSource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$registration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerSource"])(itemType, handler, manager), _registerSource2 = _slicedToArray(_registerSource, 2), handlerId = _registerSource2[0], unregister = _registerSource2[1];
            monitor.receiveHandlerId(handlerId);
            connector.receiveHandlerId(handlerId);
            return unregister;
        }
    }, [
        manager,
        monitor,
        connector,
        handler,
        itemType
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useOptionalFactory.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useOptionalFactory": ()=>useOptionalFactory
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
;
function useOptionalFactory(arg, deps) {
    var memoDeps = _toConsumableArray(deps || []);
    if (deps == null && typeof arg !== 'function') {
        memoDeps.push(arg);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useOptionalFactory.useMemo": function() {
            return typeof arg === 'function' ? arg() : arg;
        }
    }["useOptionalFactory.useMemo"], memoDeps);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/DragSourceMonitorImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DragSourceMonitorImpl": ()=>DragSourceMonitorImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
var isCallingCanDrag = false;
var isCallingIsDragging = false;
var DragSourceMonitorImpl = /*#__PURE__*/ function() {
    function DragSourceMonitorImpl(manager) {
        _classCallCheck(this, DragSourceMonitorImpl);
        _defineProperty(this, "internalMonitor", void 0);
        _defineProperty(this, "sourceId", null);
        this.internalMonitor = manager.getMonitor();
    }
    _createClass(DragSourceMonitorImpl, [
        {
            key: "receiveHandlerId",
            value: function receiveHandlerId(sourceId) {
                this.sourceId = sourceId;
            }
        },
        {
            key: "getHandlerId",
            value: function getHandlerId() {
                return this.sourceId;
            }
        },
        {
            key: "canDrag",
            value: function canDrag() {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!isCallingCanDrag, 'You may not call monitor.canDrag() inside your canDrag() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor');
                try {
                    isCallingCanDrag = true;
                    return this.internalMonitor.canDragSource(this.sourceId);
                } finally{
                    isCallingCanDrag = false;
                }
            }
        },
        {
            key: "isDragging",
            value: function isDragging() {
                if (!this.sourceId) {
                    return false;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!isCallingIsDragging, 'You may not call monitor.isDragging() inside your isDragging() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor');
                try {
                    isCallingIsDragging = true;
                    return this.internalMonitor.isDraggingSource(this.sourceId);
                } finally{
                    isCallingIsDragging = false;
                }
            }
        },
        {
            key: "subscribeToStateChange",
            value: function subscribeToStateChange(listener, options) {
                return this.internalMonitor.subscribeToStateChange(listener, options);
            }
        },
        {
            key: "isDraggingSource",
            value: function isDraggingSource(sourceId) {
                return this.internalMonitor.isDraggingSource(sourceId);
            }
        },
        {
            key: "isOverTarget",
            value: function isOverTarget(targetId, options) {
                return this.internalMonitor.isOverTarget(targetId, options);
            }
        },
        {
            key: "getTargetIds",
            value: function getTargetIds() {
                return this.internalMonitor.getTargetIds();
            }
        },
        {
            key: "isSourcePublic",
            value: function isSourcePublic() {
                return this.internalMonitor.isSourcePublic();
            }
        },
        {
            key: "getSourceId",
            value: function getSourceId() {
                return this.internalMonitor.getSourceId();
            }
        },
        {
            key: "subscribeToOffsetChange",
            value: function subscribeToOffsetChange(listener) {
                return this.internalMonitor.subscribeToOffsetChange(listener);
            }
        },
        {
            key: "canDragSource",
            value: function canDragSource(sourceId) {
                return this.internalMonitor.canDragSource(sourceId);
            }
        },
        {
            key: "canDropOnTarget",
            value: function canDropOnTarget(targetId) {
                return this.internalMonitor.canDropOnTarget(targetId);
            }
        },
        {
            key: "getItemType",
            value: function getItemType() {
                return this.internalMonitor.getItemType();
            }
        },
        {
            key: "getItem",
            value: function getItem() {
                return this.internalMonitor.getItem();
            }
        },
        {
            key: "getDropResult",
            value: function getDropResult() {
                return this.internalMonitor.getDropResult();
            }
        },
        {
            key: "didDrop",
            value: function didDrop() {
                return this.internalMonitor.didDrop();
            }
        },
        {
            key: "getInitialClientOffset",
            value: function getInitialClientOffset() {
                return this.internalMonitor.getInitialClientOffset();
            }
        },
        {
            key: "getInitialSourceClientOffset",
            value: function getInitialSourceClientOffset() {
                return this.internalMonitor.getInitialSourceClientOffset();
            }
        },
        {
            key: "getSourceClientOffset",
            value: function getSourceClientOffset() {
                return this.internalMonitor.getSourceClientOffset();
            }
        },
        {
            key: "getClientOffset",
            value: function getClientOffset() {
                return this.internalMonitor.getClientOffset();
            }
        },
        {
            key: "getDifferenceFromInitialOffset",
            value: function getDifferenceFromInitialOffset() {
                return this.internalMonitor.getDifferenceFromInitialOffset();
            }
        }
    ]);
    return DragSourceMonitorImpl;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSourceMonitor.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragSourceMonitor": ()=>useDragSourceMonitor
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$DragSourceMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/DragSourceMonitorImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
;
;
;
function useDragSourceMonitor() {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDragSourceMonitor.useMemo": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$DragSourceMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragSourceMonitorImpl"](manager);
        }
    }["useDragSourceMonitor.useMemo"], [
        manager
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/wrapConnectorHooks.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "wrapConnectorHooks": ()=>wrapConnectorHooks
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function throwIfCompositeComponentElement(element) {
    // Custom components can no longer be wrapped directly in React DnD 2.0
    // so that we don't need to depend on findDOMNode() from react-dom.
    if (typeof element.type === 'string') {
        return;
    }
    var displayName = element.type.displayName || element.type.name || 'the component';
    throw new Error('Only native element nodes can now be passed to React DnD connectors.' + "You can either wrap ".concat(displayName, " into a <div>, or turn it into a ") + 'drag source or a drop target itself.');
}
function wrapHookToRecognizeElement(hook) {
    return function() {
        var elementOrNode = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
        // When passed a node, call the hook straight away.
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(elementOrNode)) {
            var node = elementOrNode;
            hook(node, options); // return the node so it can be chained (e.g. when within callback refs
            // <div ref={node => connectDragSource(connectDropTarget(node))}/>
            return node;
        } // If passed a ReactElement, clone it and attach this function as a ref.
        // This helps us achieve a neat API where user doesn't even know that refs
        // are being used under the hood.
        var element = elementOrNode;
        throwIfCompositeComponentElement(element); // When no options are passed, use the hook directly
        var ref = options ? function(node) {
            return hook(node, options);
        } : hook;
        return cloneWithRef(element, ref);
    };
}
function wrapConnectorHooks(hooks) {
    var wrappedHooks = {};
    Object.keys(hooks).forEach(function(key) {
        var hook = hooks[key]; // ref objects should be passed straight through without wrapping
        if (key.endsWith('Ref')) {
            wrappedHooks[key] = hooks[key];
        } else {
            var wrappedHook = wrapHookToRecognizeElement(hook);
            wrappedHooks[key] = function() {
                return wrappedHook;
            };
        }
    });
    return wrappedHooks;
}
function setRef(ref, node) {
    if (typeof ref === 'function') {
        ref(node);
    } else {
        ref.current = node;
    }
}
function cloneWithRef(element, newRef) {
    var previousRef = element.ref;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(typeof previousRef !== 'string', 'Cannot connect React DnD to an element with an existing string ref. ' + 'Please convert it to use a callback ref instead, or wrap it into a <span> or <div>. ' + 'Read more: https://reactjs.org/docs/refs-and-the-dom.html#callback-refs');
    if (!previousRef) {
        // When there is no ref on the element, use the new ref directly
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(element, {
            ref: newRef
        });
    } else {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(element, {
            ref: function ref(node) {
                setRef(previousRef, node);
                setRef(newRef, node);
            }
        });
    }
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/isRef.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "isRef": ()=>isRef
});
function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}
function isRef(obj) {
    return obj !== null && _typeof(obj) === 'object' && Object.prototype.hasOwnProperty.call(obj, 'current');
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/SourceConnector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "SourceConnector": ()=>SourceConnector
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$wrapConnectorHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/wrapConnectorHooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$isRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/isRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$shallowequal$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$shallowequal$2f$dist$2f$shallowequal$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+shallowequal@2.0.0/node_modules/@react-dnd/shallowequal/dist/shallowequal.esm.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
var SourceConnector = /*#__PURE__*/ function() {
    // The drop target may either be attached via ref or connect function
    // The drag preview may either be attached via ref or connect function
    function SourceConnector(backend) {
        var _this = this;
        _classCallCheck(this, SourceConnector);
        _defineProperty(this, "hooks", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$wrapConnectorHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapConnectorHooks"])({
            dragSource: function dragSource(node, options) {
                _this.clearDragSource();
                _this.dragSourceOptions = options || null;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$isRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRef"])(node)) {
                    _this.dragSourceRef = node;
                } else {
                    _this.dragSourceNode = node;
                }
                _this.reconnectDragSource();
            },
            dragPreview: function dragPreview(node, options) {
                _this.clearDragPreview();
                _this.dragPreviewOptions = options || null;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$isRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRef"])(node)) {
                    _this.dragPreviewRef = node;
                } else {
                    _this.dragPreviewNode = node;
                }
                _this.reconnectDragPreview();
            }
        }));
        _defineProperty(this, "handlerId", null);
        _defineProperty(this, "dragSourceRef", null);
        _defineProperty(this, "dragSourceNode", void 0);
        _defineProperty(this, "dragSourceOptionsInternal", null);
        _defineProperty(this, "dragSourceUnsubscribe", void 0);
        _defineProperty(this, "dragPreviewRef", null);
        _defineProperty(this, "dragPreviewNode", void 0);
        _defineProperty(this, "dragPreviewOptionsInternal", null);
        _defineProperty(this, "dragPreviewUnsubscribe", void 0);
        _defineProperty(this, "lastConnectedHandlerId", null);
        _defineProperty(this, "lastConnectedDragSource", null);
        _defineProperty(this, "lastConnectedDragSourceOptions", null);
        _defineProperty(this, "lastConnectedDragPreview", null);
        _defineProperty(this, "lastConnectedDragPreviewOptions", null);
        _defineProperty(this, "backend", void 0);
        this.backend = backend;
    }
    _createClass(SourceConnector, [
        {
            key: "receiveHandlerId",
            value: function receiveHandlerId(newHandlerId) {
                if (this.handlerId === newHandlerId) {
                    return;
                }
                this.handlerId = newHandlerId;
                this.reconnect();
            }
        },
        {
            key: "connectTarget",
            get: function get() {
                return this.dragSource;
            }
        },
        {
            key: "dragSourceOptions",
            get: function get() {
                return this.dragSourceOptionsInternal;
            },
            set: function set(options) {
                this.dragSourceOptionsInternal = options;
            }
        },
        {
            key: "dragPreviewOptions",
            get: function get() {
                return this.dragPreviewOptionsInternal;
            },
            set: function set(options) {
                this.dragPreviewOptionsInternal = options;
            }
        },
        {
            key: "reconnect",
            value: function reconnect() {
                this.reconnectDragSource();
                this.reconnectDragPreview();
            }
        },
        {
            key: "reconnectDragSource",
            value: function reconnectDragSource() {
                var dragSource = this.dragSource; // if nothing has changed then don't resubscribe
                var didChange = this.didHandlerIdChange() || this.didConnectedDragSourceChange() || this.didDragSourceOptionsChange();
                if (didChange) {
                    this.disconnectDragSource();
                }
                if (!this.handlerId) {
                    return;
                }
                if (!dragSource) {
                    this.lastConnectedDragSource = dragSource;
                    return;
                }
                if (didChange) {
                    this.lastConnectedHandlerId = this.handlerId;
                    this.lastConnectedDragSource = dragSource;
                    this.lastConnectedDragSourceOptions = this.dragSourceOptions;
                    this.dragSourceUnsubscribe = this.backend.connectDragSource(this.handlerId, dragSource, this.dragSourceOptions);
                }
            }
        },
        {
            key: "reconnectDragPreview",
            value: function reconnectDragPreview() {
                var dragPreview = this.dragPreview; // if nothing has changed then don't resubscribe
                var didChange = this.didHandlerIdChange() || this.didConnectedDragPreviewChange() || this.didDragPreviewOptionsChange();
                if (didChange) {
                    this.disconnectDragPreview();
                }
                if (!this.handlerId) {
                    return;
                }
                if (!dragPreview) {
                    this.lastConnectedDragPreview = dragPreview;
                    return;
                }
                if (didChange) {
                    this.lastConnectedHandlerId = this.handlerId;
                    this.lastConnectedDragPreview = dragPreview;
                    this.lastConnectedDragPreviewOptions = this.dragPreviewOptions;
                    this.dragPreviewUnsubscribe = this.backend.connectDragPreview(this.handlerId, dragPreview, this.dragPreviewOptions);
                }
            }
        },
        {
            key: "didHandlerIdChange",
            value: function didHandlerIdChange() {
                return this.lastConnectedHandlerId !== this.handlerId;
            }
        },
        {
            key: "didConnectedDragSourceChange",
            value: function didConnectedDragSourceChange() {
                return this.lastConnectedDragSource !== this.dragSource;
            }
        },
        {
            key: "didConnectedDragPreviewChange",
            value: function didConnectedDragPreviewChange() {
                return this.lastConnectedDragPreview !== this.dragPreview;
            }
        },
        {
            key: "didDragSourceOptionsChange",
            value: function didDragSourceOptionsChange() {
                return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$shallowequal$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$shallowequal$2f$dist$2f$shallowequal$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqual"])(this.lastConnectedDragSourceOptions, this.dragSourceOptions);
            }
        },
        {
            key: "didDragPreviewOptionsChange",
            value: function didDragPreviewOptionsChange() {
                return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$shallowequal$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$shallowequal$2f$dist$2f$shallowequal$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqual"])(this.lastConnectedDragPreviewOptions, this.dragPreviewOptions);
            }
        },
        {
            key: "disconnectDragSource",
            value: function disconnectDragSource() {
                if (this.dragSourceUnsubscribe) {
                    this.dragSourceUnsubscribe();
                    this.dragSourceUnsubscribe = undefined;
                }
            }
        },
        {
            key: "disconnectDragPreview",
            value: function disconnectDragPreview() {
                if (this.dragPreviewUnsubscribe) {
                    this.dragPreviewUnsubscribe();
                    this.dragPreviewUnsubscribe = undefined;
                    this.dragPreviewNode = null;
                    this.dragPreviewRef = null;
                }
            }
        },
        {
            key: "dragSource",
            get: function get() {
                return this.dragSourceNode || this.dragSourceRef && this.dragSourceRef.current;
            }
        },
        {
            key: "dragPreview",
            get: function get() {
                return this.dragPreviewNode || this.dragPreviewRef && this.dragPreviewRef.current;
            }
        },
        {
            key: "clearDragSource",
            value: function clearDragSource() {
                this.dragSourceNode = null;
                this.dragSourceRef = null;
            }
        },
        {
            key: "clearDragPreview",
            value: function clearDragPreview() {
                this.dragPreviewNode = null;
                this.dragPreviewRef = null;
            }
        }
    ]);
    return SourceConnector;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSourceConnector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragSourceConnector": ()=>useDragSourceConnector
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$SourceConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/SourceConnector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
;
;
;
;
function useDragSourceConnector(dragSourceOptions, dragPreviewOptions) {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    var connector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDragSourceConnector.useMemo[connector]": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$SourceConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SourceConnector"](manager.getBackend());
        }
    }["useDragSourceConnector.useMemo[connector]"], [
        manager
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])({
        "useDragSourceConnector.useIsomorphicLayoutEffect": function() {
            connector.dragSourceOptions = dragSourceOptions || null;
            connector.reconnect();
            return ({
                "useDragSourceConnector.useIsomorphicLayoutEffect": function() {
                    return connector.disconnectDragSource();
                }
            })["useDragSourceConnector.useIsomorphicLayoutEffect"];
        }
    }["useDragSourceConnector.useIsomorphicLayoutEffect"], [
        connector,
        dragSourceOptions
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])({
        "useDragSourceConnector.useIsomorphicLayoutEffect": function() {
            connector.dragPreviewOptions = dragPreviewOptions || null;
            connector.reconnect();
            return ({
                "useDragSourceConnector.useIsomorphicLayoutEffect": function() {
                    return connector.disconnectDragPreview();
                }
            })["useDragSourceConnector.useIsomorphicLayoutEffect"];
        }
    }["useDragSourceConnector.useIsomorphicLayoutEffect"], [
        connector,
        dragPreviewOptions
    ]);
    return connector;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useCollector": ()=>useCollector
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$fast$2d$deep$2d$equal$40$3$2e$1$2e$3$2f$node_modules$2f$fast$2d$deep$2d$equal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
;
function useCollector(monitor, collect, onUpdate) {
    var _useState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useCollector.useState[_useState]": function() {
            return collect(monitor);
        }
    }["useCollector.useState[_useState]"]), _useState2 = _slicedToArray(_useState, 2), collected = _useState2[0], setCollected = _useState2[1];
    var updateCollected = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useCollector.useCallback[updateCollected]": function() {
            var nextValue = collect(monitor); // This needs to be a deep-equality check because some monitor-collected values
            // include XYCoord objects that may be equivalent, but do not have instance equality.
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$fast$2d$deep$2d$equal$40$3$2e$1$2e$3$2f$node_modules$2f$fast$2d$deep$2d$equal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(collected, nextValue)) {
                setCollected(nextValue);
                if (onUpdate) {
                    onUpdate();
                }
            }
        }
    }["useCollector.useCallback[updateCollected]"], [
        collected,
        monitor,
        onUpdate
    ]); // update the collected properties after react renders.
    // Note that the "Dustbin Stress Test" fails if this is not
    // done when the component updates
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])(updateCollected);
    return [
        collected,
        updateCollected
    ];
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useMonitorOutput.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useMonitorOutput": ()=>useMonitorOutput
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollector.js [app-client] (ecmascript)");
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
function useMonitorOutput(monitor, collect, onCollect) {
    var _useCollector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollector"])(monitor, collect, onCollect), _useCollector2 = _slicedToArray(_useCollector, 2), collected = _useCollector2[0], updateCollected = _useCollector2[1];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])(function subscribeToMonitorStateChange() {
        var handlerId = monitor.getHandlerId();
        if (handlerId == null) {
            return;
        }
        return monitor.subscribeToStateChange(updateCollected, {
            handlerIds: [
                handlerId
            ]
        });
    }, [
        monitor,
        updateCollected
    ]);
    return collected;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollectedProps.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useCollectedProps": ()=>useCollectedProps
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useMonitorOutput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useMonitorOutput.js [app-client] (ecmascript)");
;
function useCollectedProps(collector, monitor, connector) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useMonitorOutput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMonitorOutput"])(monitor, collector || ({
        "useCollectedProps.useMonitorOutput": function() {
            return {};
        }
    })["useCollectedProps.useMonitorOutput"], {
        "useCollectedProps.useMonitorOutput": function() {
            return connector.reconnect();
        }
    }["useCollectedProps.useMonitorOutput"]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/connectors.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useConnectDragPreview": ()=>useConnectDragPreview,
    "useConnectDragSource": ()=>useConnectDragSource
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useConnectDragSource(connector) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConnectDragSource.useMemo": function() {
            return connector.hooks.dragSource();
        }
    }["useConnectDragSource.useMemo"], [
        connector
    ]);
}
function useConnectDragPreview(connector) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConnectDragPreview.useMemo": function() {
            return connector.hooks.dragPreview();
        }
    }["useConnectDragPreview.useMemo"], [
        connector
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDrag.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDrag": ()=>useDrag
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useRegisteredDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useRegisteredDragSource.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useOptionalFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useOptionalFactory.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSourceMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSourceMonitor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSourceConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/useDragSourceConnector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollectedProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollectedProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$connectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrag/connectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function useDrag(specArg, deps) {
    var spec = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useOptionalFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOptionalFactory"])(specArg, deps);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!spec.begin, "useDrag::spec.begin was deprecated in v14. Replace spec.begin() with spec.item(). (see more here - https://react-dnd.github.io/react-dnd/docs/api/use-drag)");
    var monitor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSourceMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragSourceMonitor"])();
    var connector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useDragSourceConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragSourceConnector"])(spec.options, spec.previewOptions);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$useRegisteredDragSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegisteredDragSource"])(spec, monitor, connector);
    return [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollectedProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollectedProps"])(spec.collect, monitor, connector),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$connectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectDragSource"])(connector),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrag$2f$connectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectDragPreview"])(connector)
    ];
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useAccept.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useAccept": ()=>useAccept
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
function useAccept(spec) {
    var accept = spec.accept;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useAccept.useMemo": function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(spec.accept != null, 'accept must be defined');
            return Array.isArray(accept) ? accept : [
                accept
            ];
        }
    }["useAccept.useMemo"], [
        accept
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/DropTargetImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DropTargetImpl": ()=>DropTargetImpl
});
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
var DropTargetImpl = /*#__PURE__*/ function() {
    function DropTargetImpl(spec, monitor) {
        _classCallCheck(this, DropTargetImpl);
        _defineProperty(this, "spec", void 0);
        _defineProperty(this, "monitor", void 0);
        this.spec = spec;
        this.monitor = monitor;
    }
    _createClass(DropTargetImpl, [
        {
            key: "canDrop",
            value: function canDrop() {
                var spec = this.spec;
                var monitor = this.monitor;
                return spec.canDrop ? spec.canDrop(monitor.getItem(), monitor) : true;
            }
        },
        {
            key: "hover",
            value: function hover() {
                var spec = this.spec;
                var monitor = this.monitor;
                if (spec.hover) {
                    spec.hover(monitor.getItem(), monitor);
                }
            }
        },
        {
            key: "drop",
            value: function drop() {
                var spec = this.spec;
                var monitor = this.monitor;
                if (spec.drop) {
                    return spec.drop(monitor.getItem(), monitor);
                }
            }
        }
    ]);
    return DropTargetImpl;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTarget.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDropTarget": ()=>useDropTarget
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$DropTargetImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/DropTargetImpl.js [app-client] (ecmascript)");
;
;
function useDropTarget(spec, monitor) {
    var dropTarget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDropTarget.useMemo[dropTarget]": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$DropTargetImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropTargetImpl"](spec, monitor);
        }
    }["useDropTarget.useMemo[dropTarget]"], [
        monitor
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDropTarget.useEffect": function() {
            dropTarget.spec = spec;
        }
    }["useDropTarget.useEffect"], [
        spec
    ]);
    return dropTarget;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useRegisteredDropTarget.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useRegisteredDropTarget": ()=>useRegisteredDropTarget
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$registration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/registration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useAccept$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useAccept.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTarget$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTarget.js [app-client] (ecmascript)");
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
;
;
;
function useRegisteredDropTarget(spec, monitor, connector) {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    var dropTarget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTarget$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropTarget"])(spec, monitor);
    var accept = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useAccept$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccept"])(spec);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])(function registerDropTarget() {
        var _registerTarget = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$registration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerTarget"])(accept, dropTarget, manager), _registerTarget2 = _slicedToArray(_registerTarget, 2), handlerId = _registerTarget2[0], unregister = _registerTarget2[1];
        monitor.receiveHandlerId(handlerId);
        connector.receiveHandlerId(handlerId);
        return unregister;
    }, [
        manager,
        monitor,
        dropTarget,
        connector,
        accept.map({
            "useRegisteredDropTarget.useIsomorphicLayoutEffect": function(a) {
                return a.toString();
            }
        }["useRegisteredDropTarget.useIsomorphicLayoutEffect"]).join('|')
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/DropTargetMonitorImpl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DropTargetMonitorImpl": ()=>DropTargetMonitorImpl
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+invariant@2.0.0/node_modules/@react-dnd/invariant/dist/invariant.esm.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
var isCallingCanDrop = false;
var DropTargetMonitorImpl = /*#__PURE__*/ function() {
    function DropTargetMonitorImpl(manager) {
        _classCallCheck(this, DropTargetMonitorImpl);
        _defineProperty(this, "internalMonitor", void 0);
        _defineProperty(this, "targetId", null);
        this.internalMonitor = manager.getMonitor();
    }
    _createClass(DropTargetMonitorImpl, [
        {
            key: "receiveHandlerId",
            value: function receiveHandlerId(targetId) {
                this.targetId = targetId;
            }
        },
        {
            key: "getHandlerId",
            value: function getHandlerId() {
                return this.targetId;
            }
        },
        {
            key: "subscribeToStateChange",
            value: function subscribeToStateChange(listener, options) {
                return this.internalMonitor.subscribeToStateChange(listener, options);
            }
        },
        {
            key: "canDrop",
            value: function canDrop() {
                // Cut out early if the target id has not been set. This should prevent errors
                // where the user has an older version of dnd-core like in
                // https://github.com/react-dnd/react-dnd/issues/1310
                if (!this.targetId) {
                    return false;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$invariant$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$invariant$2f$dist$2f$invariant$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(!isCallingCanDrop, 'You may not call monitor.canDrop() inside your canDrop() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs/api/drop-target-monitor');
                try {
                    isCallingCanDrop = true;
                    return this.internalMonitor.canDropOnTarget(this.targetId);
                } finally{
                    isCallingCanDrop = false;
                }
            }
        },
        {
            key: "isOver",
            value: function isOver(options) {
                if (!this.targetId) {
                    return false;
                }
                return this.internalMonitor.isOverTarget(this.targetId, options);
            }
        },
        {
            key: "getItemType",
            value: function getItemType() {
                return this.internalMonitor.getItemType();
            }
        },
        {
            key: "getItem",
            value: function getItem() {
                return this.internalMonitor.getItem();
            }
        },
        {
            key: "getDropResult",
            value: function getDropResult() {
                return this.internalMonitor.getDropResult();
            }
        },
        {
            key: "didDrop",
            value: function didDrop() {
                return this.internalMonitor.didDrop();
            }
        },
        {
            key: "getInitialClientOffset",
            value: function getInitialClientOffset() {
                return this.internalMonitor.getInitialClientOffset();
            }
        },
        {
            key: "getInitialSourceClientOffset",
            value: function getInitialSourceClientOffset() {
                return this.internalMonitor.getInitialSourceClientOffset();
            }
        },
        {
            key: "getSourceClientOffset",
            value: function getSourceClientOffset() {
                return this.internalMonitor.getSourceClientOffset();
            }
        },
        {
            key: "getClientOffset",
            value: function getClientOffset() {
                return this.internalMonitor.getClientOffset();
            }
        },
        {
            key: "getDifferenceFromInitialOffset",
            value: function getDifferenceFromInitialOffset() {
                return this.internalMonitor.getDifferenceFromInitialOffset();
            }
        }
    ]);
    return DropTargetMonitorImpl;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTargetMonitor.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDropTargetMonitor": ()=>useDropTargetMonitor
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$DropTargetMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/DropTargetMonitorImpl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
;
;
;
function useDropTargetMonitor() {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDropTargetMonitor.useMemo": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$DropTargetMonitorImpl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropTargetMonitorImpl"](manager);
        }
    }["useDropTargetMonitor.useMemo"], [
        manager
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/TargetConnector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "TargetConnector": ()=>TargetConnector
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$shallowequal$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$shallowequal$2f$dist$2f$shallowequal$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@react-dnd+shallowequal@2.0.0/node_modules/@react-dnd/shallowequal/dist/shallowequal.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$wrapConnectorHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/wrapConnectorHooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$isRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/isRef.js [app-client] (ecmascript)");
function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
;
;
;
var TargetConnector = /*#__PURE__*/ function() {
    // The drop target may either be attached via ref or connect function
    function TargetConnector(backend) {
        var _this = this;
        _classCallCheck(this, TargetConnector);
        _defineProperty(this, "hooks", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$wrapConnectorHooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapConnectorHooks"])({
            dropTarget: function dropTarget(node, options) {
                _this.clearDropTarget();
                _this.dropTargetOptions = options;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$isRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRef"])(node)) {
                    _this.dropTargetRef = node;
                } else {
                    _this.dropTargetNode = node;
                }
                _this.reconnect();
            }
        }));
        _defineProperty(this, "handlerId", null);
        _defineProperty(this, "dropTargetRef", null);
        _defineProperty(this, "dropTargetNode", void 0);
        _defineProperty(this, "dropTargetOptionsInternal", null);
        _defineProperty(this, "unsubscribeDropTarget", void 0);
        _defineProperty(this, "lastConnectedHandlerId", null);
        _defineProperty(this, "lastConnectedDropTarget", null);
        _defineProperty(this, "lastConnectedDropTargetOptions", null);
        _defineProperty(this, "backend", void 0);
        this.backend = backend;
    }
    _createClass(TargetConnector, [
        {
            key: "connectTarget",
            get: function get() {
                return this.dropTarget;
            }
        },
        {
            key: "reconnect",
            value: function reconnect() {
                // if nothing has changed then don't resubscribe
                var didChange = this.didHandlerIdChange() || this.didDropTargetChange() || this.didOptionsChange();
                if (didChange) {
                    this.disconnectDropTarget();
                }
                var dropTarget = this.dropTarget;
                if (!this.handlerId) {
                    return;
                }
                if (!dropTarget) {
                    this.lastConnectedDropTarget = dropTarget;
                    return;
                }
                if (didChange) {
                    this.lastConnectedHandlerId = this.handlerId;
                    this.lastConnectedDropTarget = dropTarget;
                    this.lastConnectedDropTargetOptions = this.dropTargetOptions;
                    this.unsubscribeDropTarget = this.backend.connectDropTarget(this.handlerId, dropTarget, this.dropTargetOptions);
                }
            }
        },
        {
            key: "receiveHandlerId",
            value: function receiveHandlerId(newHandlerId) {
                if (newHandlerId === this.handlerId) {
                    return;
                }
                this.handlerId = newHandlerId;
                this.reconnect();
            }
        },
        {
            key: "dropTargetOptions",
            get: function get() {
                return this.dropTargetOptionsInternal;
            },
            set: function set(options) {
                this.dropTargetOptionsInternal = options;
            }
        },
        {
            key: "didHandlerIdChange",
            value: function didHandlerIdChange() {
                return this.lastConnectedHandlerId !== this.handlerId;
            }
        },
        {
            key: "didDropTargetChange",
            value: function didDropTargetChange() {
                return this.lastConnectedDropTarget !== this.dropTarget;
            }
        },
        {
            key: "didOptionsChange",
            value: function didOptionsChange() {
                return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$react$2d$dnd$2b$shallowequal$40$2$2e$0$2e$0$2f$node_modules$2f40$react$2d$dnd$2f$shallowequal$2f$dist$2f$shallowequal$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqual"])(this.lastConnectedDropTargetOptions, this.dropTargetOptions);
            }
        },
        {
            key: "disconnectDropTarget",
            value: function disconnectDropTarget() {
                if (this.unsubscribeDropTarget) {
                    this.unsubscribeDropTarget();
                    this.unsubscribeDropTarget = undefined;
                }
            }
        },
        {
            key: "dropTarget",
            get: function get() {
                return this.dropTargetNode || this.dropTargetRef && this.dropTargetRef.current;
            }
        },
        {
            key: "clearDropTarget",
            value: function clearDropTarget() {
                this.dropTargetRef = null;
                this.dropTargetNode = null;
            }
        }
    ]);
    return TargetConnector;
}();
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTargetConnector.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDropTargetConnector": ()=>useDropTargetConnector
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$TargetConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/internals/TargetConnector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useIsomorphicLayoutEffect.js [app-client] (ecmascript)");
;
;
;
;
function useDropTargetConnector(options) {
    var manager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    var connector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDropTargetConnector.useMemo[connector]": function() {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$internals$2f$TargetConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TargetConnector"](manager.getBackend());
        }
    }["useDropTargetConnector.useMemo[connector]"], [
        manager
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useIsomorphicLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])({
        "useDropTargetConnector.useIsomorphicLayoutEffect": function() {
            connector.dropTargetOptions = options || null;
            connector.reconnect();
            return ({
                "useDropTargetConnector.useIsomorphicLayoutEffect": function() {
                    return connector.disconnectDropTarget();
                }
            })["useDropTargetConnector.useIsomorphicLayoutEffect"];
        }
    }["useDropTargetConnector.useIsomorphicLayoutEffect"], [
        options
    ]);
    return connector;
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/connectors.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useConnectDropTarget": ()=>useConnectDropTarget
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useConnectDropTarget(connector) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConnectDropTarget.useMemo": function() {
            return connector.hooks.dropTarget();
        }
    }["useConnectDropTarget.useMemo"], [
        connector
    ]);
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDrop.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDrop": ()=>useDrop
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useRegisteredDropTarget$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useRegisteredDropTarget.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useOptionalFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useOptionalFactory.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTargetMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTargetMonitor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTargetConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/useDropTargetConnector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollectedProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollectedProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$connectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDrop/connectors.js [app-client] (ecmascript)");
;
;
;
;
;
;
function useDrop(specArg, deps) {
    var spec = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useOptionalFactory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOptionalFactory"])(specArg, deps);
    var monitor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTargetMonitor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropTargetMonitor"])();
    var connector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useDropTargetConnector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDropTargetConnector"])(spec.options);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$useRegisteredDropTarget$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegisteredDropTarget"])(spec, monitor, connector);
    return [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollectedProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollectedProps"])(spec.collect, monitor, connector),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDrop$2f$connectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectDropTarget"])(connector)
    ];
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/core/DndProvider.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "DndProvider": ()=>DndProvider
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$createDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/dnd-core@14.0.1/node_modules/dnd-core/dist/esm/createDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/core/DndContext.js [app-client] (ecmascript)");
var _excluded = [
    "children"
];
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
;
;
;
;
var refCount = 0;
var INSTANCE_SYM = Symbol.for('__REACT_DND_CONTEXT_INSTANCE__');
var DndProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(function DndProvider(_ref) {
    var children = _ref.children, props = _objectWithoutProperties(_ref, _excluded);
    var _getDndContextValue = getDndContextValue(props), _getDndContextValue2 = _slicedToArray(_getDndContextValue, 2), manager = _getDndContextValue2[0], isGlobalInstance = _getDndContextValue2[1]; // memoized from props
    /**
   * If the global context was used to store the DND context
   * then where theres no more references to it we should
   * clean it up to avoid memory leaks
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DndProvider.DndProvider.useEffect": function() {
            if (isGlobalInstance) {
                var context = getGlobalContext();
                ++refCount;
                return ({
                    "DndProvider.DndProvider.useEffect": function() {
                        if (--refCount === 0) {
                            context[INSTANCE_SYM] = null;
                        }
                    }
                })["DndProvider.DndProvider.useEffect"];
            }
        }
    }["DndProvider.DndProvider.useEffect"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$core$2f$DndContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"].Provider, Object.assign({
        value: manager
    }, {
        children: children
    }), void 0);
});
function getDndContextValue(props) {
    if ('manager' in props) {
        var _manager = {
            dragDropManager: props.manager
        };
        return [
            _manager,
            false
        ];
    }
    var manager = createSingletonDndContext(props.backend, props.context, props.options, props.debugMode);
    var isGlobalInstance = !props.context;
    return [
        manager,
        isGlobalInstance
    ];
}
function createSingletonDndContext(backend) {
    var context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : getGlobalContext();
    var options = arguments.length > 2 ? arguments[2] : undefined;
    var debugMode = arguments.length > 3 ? arguments[3] : undefined;
    var ctx = context;
    if (!ctx[INSTANCE_SYM]) {
        ctx[INSTANCE_SYM] = {
            dragDropManager: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$dnd$2d$core$40$14$2e$0$2e$1$2f$node_modules$2f$dnd$2d$core$2f$dist$2f$esm$2f$createDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDragDropManager"])(backend, context, options, debugMode)
        };
    }
    return ctx[INSTANCE_SYM];
}
function getGlobalContext() {
    return ("TURBOPACK compile-time truthy", 1) ? ("TURBOPACK ident replacement", globalThis) : "TURBOPACK unreachable";
}
}),
"[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragLayer.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useDragLayer": ()=>useDragLayer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.5_@babel+core@7.28.0_@playwright+test@1.55.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useDragDropManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-dnd@14.0.5_@types+node@20.19.9_@types+react@19.1.9_react@19.1.0/node_modules/react-dnd/dist/esm/hooks/useCollector.js [app-client] (ecmascript)");
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
;
;
;
function useDragLayer(collect) {
    var dragDropManager = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useDragDropManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDragDropManager"])();
    var monitor = dragDropManager.getMonitor();
    var _useCollector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$dnd$40$14$2e$0$2e$5_$40$types$2b$node$40$20$2e$19$2e$9_$40$types$2b$react$40$19$2e$1$2e$9_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$dnd$2f$dist$2f$esm$2f$hooks$2f$useCollector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollector"])(monitor, collect), _useCollector2 = _slicedToArray(_useCollector, 2), collected = _useCollector2[0], updateCollected = _useCollector2[1];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDragLayer.useEffect": function() {
            return monitor.subscribeToOffsetChange(updateCollected);
        }
    }["useDragLayer.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$5_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$55$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDragLayer.useEffect": function() {
            return monitor.subscribeToStateChange(updateCollected);
        }
    }["useDragLayer.useEffect"]);
    return collected;
}
}),
}]);

//# sourceMappingURL=069a8_react-dnd_dist_esm_93d6bfdb._.js.map