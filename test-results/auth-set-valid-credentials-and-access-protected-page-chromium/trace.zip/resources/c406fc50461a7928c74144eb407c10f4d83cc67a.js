(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f36a8ff5._.css",
  "static/chunks/node_modules__pnpm_3d69ab19._.js"
],
    source: "dynamic"
});
